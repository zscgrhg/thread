(function(){
var s = "<"+"iframe src=\"https://pastebin.com/adserver/160x600_criteo_pb_safe.php\" id=\"bbf\" marginwidth=\"0\" align=\"center\" marginheight=\"0\" hspace=\"0\" vspace=\"0\" frameborder=\"0\" scrolling=\"no\" allowtransparency=\"true\" width=\"160\" height=\"600\" style=\"width: 160px; height: 600px;\"><"+"/iframe>\n";
s += "<"+"div id=\'beacon_33fab1db0e\' style=\'position: absolute; left: 0px; top: 0px; visibility: hidden;\'>\n";
s += "<"+"img width=\"0\" height=\"0\" src=\"https://cat.sh.cn.criteo.com/delivery/lg.php?cppv=1&cpp=XeTUm3xyMEhtTFVXYlZnazA0TDV1bEVpOGhZZWEycmVsQUVqVVp4eVl1M25GZ3o2RDVxamxqQ2pOUkdOeGxXQWQ4NGt5VkxoV04zTFdHUm1lUVJzeW1yL1BiTHMxY2c0L20yQ01HaVIya3EwYWl1bWtYNWw4aXdYTWZ0WlNuU1BONFZLVTdvMnJFYTByWWRhY3JKK25RTEdtRkc5RGRWU1ZCM0xKSEdSVDdxVWcvT3F2RkxlamVvK1ZvT3lDNU5Yem5wdGVnd0dxVVNSbUdZczQwelAvKzRBM2lNcU9meVBwZEdNWTY5VGxqTHljUjYrUDAvWFhhQXFNNW9TdDBoNVJORC9mfA%3D%3D\"/>\n";
s += "<"+"img width=\"0\" height=\"0\" src=\"https://ssum-sec.casalemedia.com/usermatchredir?s=183697&cb=https%3a%2f%2fdis.criteo.com%2frex%2fmatch.aspx%3fc%3d25%26uid%3d%25%25USER_ID%25%25\"/>\n";
s += "<"+"/div>\n";
s += "\n";
document.write(s);})();
