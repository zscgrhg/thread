/* 2011-2014 iPerceptions, Inc. All rights reserved. Do not distribute.iPerceptions provides this code 'as is' without warranty of any kind, either express or implied. */
window.iperceptionskey = '9AF84A3D-BB1E-4688-B83F-2FFD57725918';
(function() {
  var a = document.createElement('script'),
      b = document.getElementsByTagName('body')[0];
  a.type = 'text/javascript';
  a.async = true;
  a.src = '//universal.iperceptions.com/wrapper.js';
  b.appendChild(a);
})();
