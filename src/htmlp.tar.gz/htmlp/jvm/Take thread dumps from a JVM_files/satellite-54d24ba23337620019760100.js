_satellite.pushAsyncScript(function(event, target, $variables){
  (function(win, doc) {
    var scriptElement,
        scrSrc = false,
        hostname = window.location.hostname,
        pathname = window.location.pathname,
        photouse = '/photoshop/using',
        indexOf = function(string, substring) {
            return string.indexOf(substring) !== -1;
        };

    if (typeof(win.ClickTaleCreateDOMElement) != "function") {
        win.ClickTaleCreateDOMElement = function(tagName) {
            if (doc.createElementNS) {
                return doc.createElementNS('http://www.w3.org/1999/xhtml', tagName);
            }
            return doc.createElement(tagName);
        }
    }
    win.WRInitTime = (new Date()).getTime();

    if ((hostname === 'helpx.adobe.com' || hostname === 'helpx.stage.adobe.com') && (pathname === '/search.html' ||
            pathname === '/photoshop/user-guide.html' ||
            pathname === '/dreamweaver/user-guide.html' ||
            pathname === '/indesign/user-guide.html' ||
            pathname === '/illustrator/user-guide.html' ||
            pathname === '/acrobat/11/user-guide.html' ||
            pathname === '/flash-player/kb/flash-player-google-chrome.html' ||
            pathname === '/photoshop/get-started.html' ||
            pathname === '/photoshop/get-started-a.html' ||
            pathname === '/reader/11/using/reader-xi-topics.html' ||
            pathname === '/photoshop/topics.html' ||
            pathname === '/photoshop/tutorials.html' ||
            pathname === '/support.html' ||
            pathname === '/flash-player.html' ||
            pathname === '/support/reader.html' ||
            pathname === '/support/photoshop.html' ||
            pathname === '/photoshop/kb/photoshop-cc-gpu-card-faq.html' ||
            pathname === '/acrobat/using/flash-player-needed-acrobat-reader.html' ||
            pathname === '/illustrator/tutorials.html' ||
            pathname === '/premiere-pro/tutorials.html' ||
            pathname === '/support/illustrator.html' ||
            pathname === '/photoshop.html' ||
            pathname === '/lightroom/tutorials.html' ||
            pathname === '/acrobat/topics.html' ||
            pathname === '/indesign/tutorials.html' ||
            pathname === '/support/premiere-pro.html' ||
            pathname === '/camera-raw/kb/camera-raw-plug-supported-cameras.html' ||
            pathname === '/illustrator/topics.html' ||
            pathname === '/photoshop-elements/using/topics.html' ||
            pathname === '/support/lightroom.html' ||
            pathname === '/creative-cloud/help/download-install-app.html' ||
            pathname === '/creative-cloud/help/manage-apps-services-desktop.html' ||
            pathname === '/camera-raw/using/supported-cameras.html' ||
            pathname === '/creative-cloud/kb/cc-cleaner-tool-installation-problems.html' ||
            pathname === '/download-install.html' ||
            pathname === '/support/indesign.html' ||
            pathname === '/after-effects/tutorials.html' ||
            pathname === '/dreamweaver/tutorials.html' ||
            pathname === '/x-productkb/global/find-your-serial-number.html' ||
            pathname === '/x-productkb/global/account-password-sign-help.html' ||
            pathname === '/reader/system-requirements.html' ||
            pathname === '/x-productkb/global/redemption-code-purchase-help.html' ||
            pathname === '/premiere-pro.html' ||
            pathname === '/lightroom/topics.html' ||
            pathname === '/creative-cloud/tutorials-photography-jumpstart.html' ||
            pathname === '/x-productkb/policy-pricing/activate-deactivate-products.html' ||
            pathname === '/premiere-pro/topics.html' ||
            pathname === '/support/acrobat.html' ||
            pathname === '/x-productkb/policy-pricing/adobe-stores-online-order-payment-faq.html' ||
            pathname === '/support/creative-cloud.html' ||
            pathname === '/creative-cloud/kb/troubleshoot-download-install.html' ||
            pathname === '/muse/tutorials.html' ||
            pathname === '/lightroom.html' ||
            pathname === '/x-productkb/global/adobe-id-account-change.html' ||
            pathname === '/indesign/topics.html' ||
            pathname === '/illustrator.html' ||
            pathname === '/acrobat/using/removing-sensitive-content-pdfs.html' ||
            pathname === '/acrobat/kb/fix-install-download-reader.html' ||
            pathname === '/creative-cloud/help/download-install-single-app-Lightroom-6.html' ||
            pathname === '/creative-cloud/help/sign-in-out-activate-apps.html' ||
            pathname === '/acrobat/using/basic-pdf-printing-tasks.html' ||
            pathname === '/creative-cloud/help/cancel-membership.html' ||
            pathname === '/indesign.html' ||
            pathname === '/creative-cloud/tutorials-explore.html' ||
            pathname === '/acrobat/kb/pdf-browser-plugin-configuration.html' ||
            pathname === '/support/after-effects.html' ||
            pathname === '/acrobat/using/edit-text-pdfs.html' ||
            pathname === '/creative-cloud/help/download-install-trial.html' ||
            pathname === '/acrobat/kb/cant-open-pdf.html' ||
            pathname === '/creative-cloud/help/manage-cc-individual-membership.html' ||
            pathname === '/acrobat/kb/cant-view-pdf-web.html' ||
            pathname === '/photoshop/kb/plug-ins-extensions-photoshop-cc.html' ||
            pathname === '/acrobat/kb/troubleshoot-pdf-printing-acrobat-reader.html' ||
            pathname === '/premiere-pro/kb/no-sound-playback-premiere-pro.html' ||
            pathname === '/acrobat/faq.html' ||
            pathname === '/creative-cloud/help/uninstall-remove-app.html' ||
            pathname === '/creative-cloud/help/download-install-Photoshop-cc.html' ||
            pathname === '/premiere-pro/kb/error-compiling-movie-rendering-or.html' ||
            pathname === '/flash-player/kb/common-problems-flash-player.html' ||
            pathname === '/after-effects/topics.html' ||
            pathname === photouse + '/editing-text.html' ||
            pathname === '/x-productkb/policy-pricing/activation-network-issues.html' ||
            pathname === '/photoshop/kb/optimize-photoshop-cc-performance.html' ||
            pathname === '/premiere-elements/using/topics.html' ||
            pathname === '/lightroom/kb/optimize-performance-lightroom.html' ||
            pathname === photouse + '/creating-opening-importing-images.html' ||
            pathname === '/lightroom/help/exporting-photos-basic-workflow.html' ||
            pathname === '/creative-cloud/help/renew-restart-extend-membership.html' ||
            pathname === '/support/dreamweaver.html' ||
            pathname === '/photoshop/kb/troubleshoot-gpu-graphics-card.html' ||
            pathname === '/creative-cloud/help/upgrade-change-plan.html' ||
            pathname === '/dreamweaver/topics.html' ||
            pathname === '/creative-cloud/kb/download-update-errors.html' ||
            pathname === '/support/photoshop-elements.html' ||
            pathname === '/creative-cloud/help/change-install-language.html' ||
            pathname === '/creative-cloud/help/print-receipt.html' ||
            pathname === '/x-productkb/policy-pricing/error-activation-limit-reached-sign.html' ||
            pathname === '/photoshop-elements/kb/troubleshoot-installation-photoshop-elements-premiere.html' ||
            pathname === '/support/audition.html' ||
            pathname === '/creative-cloud/kb/signed-out-sign-in-required-error-248.html' ||
            pathname === '/support/animate.html' ||
            pathname === '/x-productkb/global/troubleshoot-download-problems.html' ||
            pathname === '/illustrator/kb/gpu-performance-preview-improvements.html' ||
            pathname === '/creative-cloud/kb/activation-connectivity-errors-creative-cloud.html' ||
            pathname === '/x-productkb/global/student-teacher-serial-product-code.html' ||
            pathname === '/x-productkb/policy-pricing/activation-deactivation-help.html' ||
            pathname === '/creative-cloud/help/download-install-lightroom-cc.html' ||
            pathname === '/support/character-animator.html' ||
            pathname === '/creative-cloud/help/manage-teams-membership.html' ||
            pathname === '/x-productkb/global/find-downloaded-file-app.html' ||
            pathname === '/support/bridge.html' ||
            pathname === '/creative-cloud/kb/asks-serial-number-error.html' ||
            pathname === '/premiere-pro/kb/features-presets-missing-premiere-pro.html' ||
            pathname === '/creative-cloud/creative-cloud-teams.html' ||
            pathname === '/premiere-pro/kb/error---preludevideo-play-modules.html' ||
            pathname === '/creative-cloud/help/update-app.html' ||
            pathname === '/indesign/kb/save-indesign-files-previous-versions.html' ||
            pathname === '/muse/topics.html' ||
            pathname === '/photoshop-elements/kb/crop-resize-resample-photoshop-elements.html' ||
            pathname === '/illustrator/kb/pantone-plus.html' ||
            pathname === '/photoshop/kb/plug-ins-photoshop-troubleshooting.html' ||
            pathname === '/acrobat/kb/install-prompt-close-safarinotificati.html' ||
            pathname === '/creative-cloud/packager.html' ||
            pathname === '/indesign/kb/indesign-document-recovery.html' ||
            pathname === '/indesign/kb/troubleshoot-damaged-indesign-documents.html' ||
            pathname === '/contact/what-contact-options.html' ||
            pathname === '/illustrator/kb/optimize-illustrator-performance-windows.html' ||
            pathname === '/creative-cloud/kb/acrobat-dc-uninstalls-acrobat-11.html' ||
            pathname === '/illustrator/kb/optimize-illustrator-performance-mac-os.html' ||
            pathname === '/support/media-encoder.html' ||
            pathname === '/indesign/kb/indesign-cc-crashing-launch.html' ||
            pathname === '/creative-cloud/help/launch-start-app.html' ||
            pathname === '/indesign/kb/troubleshoot-printing-pdf-export-indesign.html' ||
            pathname === '/support/muse.html' ||
            pathname === '/x-productkb/policy-pricing/exchange-product-language-os.html' ||
            pathname === '/support/captivate.html' ||
            pathname === '/animate/tutorials.html' ||
            pathname === '/creative-cloud/kb/change-account-payment.html' ||
            pathname === '/support/premiere-elements.html' ||
            pathname === '/creative-cloud/help/convert-trial-to-membership.html' ||
            pathname === '/stock/kb/cancel-membership-subscription-stock.html' ||
            pathname === '/after-effects/kb/effects-launch-mac-os-109.html' ||
            pathname === '/support/stock.html' ||
            pathname === '/photoshop/kb/graphics-hardware-error-512-vram.html' ||
            pathname === '/creative-suite/kb/aam-troubleshoot-download-install.html' ||
            pathname === '/photoshop/kb/photoshop-crash-with-faulty-module-photoshop-exe.html' ||
            pathname === '/creative-cloud/kb/accept-invitation-team-enterprise.html' ||
            pathname === '/creative-cloud/student-tutorials.html' ||
            pathname === '/support/experience-design.html' ||
            pathname === '/after-effects/kb/troubleshooting-quicktime-errors-in-after-effects.html' ||
            pathname === '/stock/kb/unable-to-download-adobe-stock-images.html' ||
            pathname === '/illustrator/kb/copy-paste-artwork-slow-or.html' ||
            pathname === '/x-productkb/global/didn-t-receive-expected-email.html' ||
            pathname === '/photoshop-elements/kb/backup-restore-move-catalog-photoshop.html' ||
            pathname === '/support/connect.html' ||
            pathname === '/dreamweaver/kb/troubleshoot-javascript-errors-dreamweaver-cs6-cc.html' ||
            pathname === '/x-productkb/global/windows-8-1-compatability.html' ||
            pathname === '/support/prelude.html' ||
            pathname === '/dreamweaver/kb/troubleshoot-ftp-issues-dreamweaver-cs6-cc.html' ||
            pathname === '/support/incopy.html' ||
            pathname === '/dreamweaver/kb/restore-preferences-dreamweaver.html' ||
            pathname === '/support/document-cloud.html' ||
            pathname === '/lightroom/kb/lightroom-not-launching-after-splash-screen.html' ||
            pathname === '/contact/support.html' ||
            pathname === '/creative-cloud/kb/aam-error-update-cc-desktop-app.html' ||
            pathname === '/support/air.html' ||
            pathname === '/animate/using/working-with-camera-in-animate-cc.html' ||
            pathname === '/after-effects/kb/using-adobe-media-encoder-h264-mpeg2-wmv.html' ||
            pathname === '/support/coldfusion.html' ||
            pathname === '/stock/kb/manage-stock-membership.html' ||
            pathname === '/dreamweaver/kb/commontroubleshooting.html' ||
            pathname === '/after-effects/kb/fixing-startup-permissions-problem.html' ||
            pathname === '/support/contribute.html' ||
            pathname === '/x-productkb/global/trial-software-expired-early.html' ||
            pathname === '/creative-cloud/creative-cloud-teams/users.html' ||
            pathname === '/support/adobe-media-server.html' ||
            pathname === '/support/fuse.html' ||
            pathname === '/muse/kb/uninstall-muse.html' ||
            pathname === '/creative-cloud/help/download-install-app.typekit-no.html' ||
            pathname === '/stock/kb/adobe-stock-known-issues.html' ||
            pathname === '/creative-cloud/help/download-install-app.dtm-no.html' ||
            pathname === '/enterprise/help/expert-services.html' ||
            pathname === '/x-productkb/policy-pricing/account-password-sign-faq.html' ||
            pathname === '/search.html' ||
            pathname === '/muse/kb/unexpected-error-occurred-i-200.html' ||
            pathname === '/premiere-pro/how-to/edit-videos.html' ||
            pathname === '/premiere-pro/how-to/what-is-premiere-pro-cc.html' ||
            pathname === '/photoshop/how-to/photoshop-cc.html' ||
            pathname === '/illustrator/how-to/what-is-illustrator.html' ||
            pathname === '/indesign/how-to/what-is-indesign.html' ||
            pathname === '/after-effects/how-to/add-video-special-effects.html' ||
            pathname === '/photoshop/how-to/remove-object-content-aware.html' ||
            pathname === '/creative-cloud/how-to/creative-cloud-libraries.html' ||
            pathname === '/lightroom/how-to/what-is-lightroom.html' ||
            pathname === '/photoshop/how-to/resize-image.html' ||
            pathname === '/muse/how-to/what-is-muse.html' ||
            pathname === '/dreamweaver/how-to/what-is-dreamweaver.html' ||
            pathname === '/lightroom/how-to/lightroom-mobile.html' ||
            pathname === '/photoshop/how-to/blur-background-for-focal-point.html' ||
            pathname === '/photoshop/how-to/turn-photo-into-painting.html' ||
            pathname === '/after-effects/how-to/what-is-after-effects-cc.html' ||
            pathname === '/muse/how-to/create-website.html' ||
            pathname === '/illustrator/how-to/draw-edit-curves.html' ||
            pathname === '/photoshop/how-to/add-motion-blur-effects.html' ||
            pathname === '/indesign/how-to/new-document-in-indesign.html' ||
            pathname === '/illustrator/how-to/design-a-tshirt.html' ||
            pathname === '/muse/how-to/set-up-a-site.html' ||
            pathname === '/illustrator/how-to/create-apply-patterns.html' ||
            pathname === '/illustrator/how-to/recover-files.html' ||
            pathname === '/indesign/how-to/make-brochure.html' ||
            pathname === '/creative-cloud/how-to/creative-cloud-overview.html' ||
            pathname === '/illustrator/how-to/join-trim-paths-lines.html' ||
            pathname === '/indesign/how-to/indesign-add-text-to-frames.html' ||
            pathname === '/lightroom/how-to/sharpen-blurry-photo.html' ||
            pathname === '/illustrator/how-to/brush-strokes.html' ||
            pathname === '/premiere-pro/how-to/create-video-story.html' ||
            pathname === '/lightroom/how-to/remove-haze-dehaze.html' ||
            pathname === '/premiere-pro/how-to/edit-correct-gopro-video.html' ||
            pathname === '/lightroom/how-to/customize-filter-presets.html' ||
            pathname === '/after-effects/how-to/insert-objects-after-effects.html' ||
            pathname === '/speedgrade/how-to/film-look-speedgrade.html' ||
            pathname === '/illustrator/how-to/illustrator-live-corners.html' ||
            pathname === '/lightroom/how-to/lightroom-healing-brush-visualization.html' ||
            pathname === '/photoshop/how-to/make-creative-facebook-cover-photo.html' ||
            pathname === '/after-effects/how-to/stabilize-footage.html' ||
            pathname === '/illustrator/how-to/illustrator-creating-basic-clipping-mask.html' ||
            pathname === '/photoshop/how-to/photoshop-perspective-warp.html' ||
            pathname === '/indesign/how-to/ebook-fixed-layout.html' ||
            pathname === '/illustrator/how-to/design-logo.html' ||
            pathname === '/illustrator/how-to/create-new-document.html' ||
            pathname === '/indesign/how-to/create-print-business-cards.html' ||
            pathname === '/dreamweaver/how-to/extract-photoshop-design-code.html' ||
            pathname === '/lightroom/how-to/merge-photos-for-panorama.html' ||
            pathname === '/lightroom/how-to/beginning-photography-workflow.html' ||
            pathname === '/premiere-pro/how-to/blur-face-masking-tracking.html' ||
            pathname === '/premiere-pro/how-to/importing-media-premierepro-cc.html' ||
            pathname === '/photoshop/how-to/export-image-web.html' ||
            pathname === '/lightroom/how-to/lightroom-correct-perspective-upright.html' ||
            pathname === '/illustrator/how-to/work-with-artboards.html' ||
            pathname === '/muse/how-to/muse-mobile-site.html' ||
            pathname === '/lightroom/how-to/share-photo-gallery.html' ||
            pathname === '/lightroom/how-to/lightroom-general-workflow.html' ||
            pathname === '/dreamweaver/how-to/make-style-web-page.html' ||
            pathname === '/illustrator/how-to/draw-touch-environment.html' ||
            pathname === '/premiere-pro/how-to/film-look-speedgrade.html' ||
            pathname === '/adobe-connect/topics/connect-how-to.html' ||
            pathname === '/sign/help/how-to-sign-agreements.html' ||
            pathname === photouse + '/image-size-resolution.html' ||
            pathname === photouse + '/default-keyboard-shortcuts.html' ||
            pathname === photouse + '/whats-new.html' ||
            pathname === photouse + '/export-artboards-layers.html' ||
            pathname === photouse + '/resizing-image.html' )) {
        scrSrc = true;
    } else if (!SL.getVar("isSite_AdobeHelpX")) {
        scrSrc = true;
    }
    if (scrSrc) {
        scriptElement = ClickTaleCreateDOMElement('script');
        scriptElement.type = "text/javascript";
        scriptElement.src = "//cdnssl.clicktale.net/www20/ptc/544fc825-311a-44c5-86f0-70581a36c216.js";
        doc.getElementsByTagName('body')[0].appendChild(scriptElement);
    }

})(window, document);

});
