/*! jQuery v1.11.2 | (c) 2005, 2014 jQuery Foundation, Inc. | jquery.org/license */
;
!function(e,d){"object"==typeof module&&"object"==typeof module.exports?module.exports=e.document?d(e,!0):function(b){if(!b.document){throw new Error("jQuery requires a window with a document")
}return d(b)
}:d(e)
}("undefined"!=typeof window?window:this,function(a,b){var c=[],d=c.slice,e=c.concat,f=c.push,g=c.indexOf,h={},i=h.toString,j=h.hasOwnProperty,k={},l="1.11.2",m=function(a,b){return new m.fn.init(a,b)
},n=/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,o=/^-ms-/,p=/-([\da-z])/gi,q=function(a,b){return b.toUpperCase()
};
m.fn=m.prototype={jquery:l,constructor:m,selector:"",length:0,toArray:function(){return d.call(this)
},get:function(a){return null!=a?0>a?this[a+this.length]:this[a]:d.call(this)
},pushStack:function(a){var b=m.merge(this.constructor(),a);
return b.prevObject=this,b.context=this.context,b
},each:function(a,b){return m.each(this,a,b)
},map:function(a){return this.pushStack(m.map(this,function(b,c){return a.call(b,c,b)
}))
},slice:function(){return this.pushStack(d.apply(this,arguments))
},first:function(){return this.eq(0)
},last:function(){return this.eq(-1)
},eq:function(a){var b=this.length,c=+a+(0>a?b:0);
return this.pushStack(c>=0&&b>c?[this[c]]:[])
},end:function(){return this.prevObject||this.constructor(null)
},push:f,sort:c.sort,splice:c.splice},m.extend=m.fn.extend=function(){var a,b,c,d,e,f,g=arguments[0]||{},h=1,i=arguments.length,j=!1;
for("boolean"==typeof g&&(j=g,g=arguments[h]||{},h++),"object"==typeof g||m.isFunction(g)||(g={}),h===i&&(g=this,h--);
i>h;
h++){if(null!=(e=arguments[h])){for(d in e){a=g[d],c=e[d],g!==c&&(j&&c&&(m.isPlainObject(c)||(b=m.isArray(c)))?(b?(b=!1,f=a&&m.isArray(a)?a:[]):f=a&&m.isPlainObject(a)?a:{},g[d]=m.extend(j,f,c)):void 0!==c&&(g[d]=c))
}}}return g
},m.extend({expando:"jQuery"+(l+Math.random()).replace(/\D/g,""),isReady:!0,error:function(a){throw new Error(a)
},noop:function(){},isFunction:function(a){return"function"===m.type(a)
},isArray:Array.isArray||function(a){return"array"===m.type(a)
},isWindow:function(a){return null!=a&&a==a.window
},isNumeric:function(a){return !m.isArray(a)&&a-parseFloat(a)+1>=0
},isEmptyObject:function(a){var b;
for(b in a){return !1
}return !0
},isPlainObject:function(a){var b;
if(!a||"object"!==m.type(a)||a.nodeType||m.isWindow(a)){return !1
}try{if(a.constructor&&!j.call(a,"constructor")&&!j.call(a.constructor.prototype,"isPrototypeOf")){return !1
}}catch(c){return !1
}if(k.ownLast){for(b in a){return j.call(a,b)
}}for(b in a){}return void 0===b||j.call(a,b)
},type:function(a){return null==a?a+"":"object"==typeof a||"function"==typeof a?h[i.call(a)]||"object":typeof a
},globalEval:function(b){b&&m.trim(b)&&(a.execScript||function(b){a.eval.call(a,b)
})(b)
},camelCase:function(a){return a.replace(o,"ms-").replace(p,q)
},nodeName:function(a,b){return a.nodeName&&a.nodeName.toLowerCase()===b.toLowerCase()
},each:function(a,b,c){var d,e=0,f=a.length,g=r(a);
if(c){if(g){for(;
f>e;
e++){if(d=b.apply(a[e],c),d===!1){break
}}}else{for(e in a){if(d=b.apply(a[e],c),d===!1){break
}}}}else{if(g){for(;
f>e;
e++){if(d=b.call(a[e],e,a[e]),d===!1){break
}}}else{for(e in a){if(d=b.call(a[e],e,a[e]),d===!1){break
}}}}return a
},trim:function(a){return null==a?"":(a+"").replace(n,"")
},makeArray:function(a,b){var c=b||[];
return null!=a&&(r(Object(a))?m.merge(c,"string"==typeof a?[a]:a):f.call(c,a)),c
},inArray:function(a,b,c){var d;
if(b){if(g){return g.call(b,a,c)
}for(d=b.length,c=c?0>c?Math.max(0,d+c):c:0;
d>c;
c++){if(c in b&&b[c]===a){return c
}}}return -1
},merge:function(a,b){var c=+b.length,d=0,e=a.length;
while(c>d){a[e++]=b[d++]
}if(c!==c){while(void 0!==b[d]){a[e++]=b[d++]
}}return a.length=e,a
},grep:function(a,b,c){for(var d,e=[],f=0,g=a.length,h=!c;
g>f;
f++){d=!b(a[f],f),d!==h&&e.push(a[f])
}return e
},map:function(a,b,c){var d,f=0,g=a.length,h=r(a),i=[];
if(h){for(;
g>f;
f++){d=b(a[f],f,c),null!=d&&i.push(d)
}}else{for(f in a){d=b(a[f],f,c),null!=d&&i.push(d)
}}return e.apply([],i)
},guid:1,proxy:function(a,b){var c,e,f;
return"string"==typeof b&&(f=a[b],b=a,a=f),m.isFunction(a)?(c=d.call(arguments,2),e=function(){return a.apply(b||this,c.concat(d.call(arguments)))
},e.guid=a.guid=a.guid||m.guid++,e):void 0
},now:function(){return +new Date
},support:k}),m.each("Boolean Number String Function Array Date RegExp Object Error".split(" "),function(a,b){h["[object "+b+"]"]=b.toLowerCase()
});
function r(a){var b=a.length,c=m.type(a);
return"function"===c||m.isWindow(a)?!1:1===a.nodeType&&b?!0:"array"===c||0===b||"number"==typeof b&&b>0&&b-1 in a
}var s=function(a){var b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u="sizzle"+1*new Date,v=a.document,w=0,x=0,y=hb(),z=hb(),A=hb(),B=function(a,b){return a===b&&(l=!0),0
},C=1<<31,D={}.hasOwnProperty,E=[],F=E.pop,G=E.push,H=E.push,I=E.slice,J=function(a,b){for(var c=0,d=a.length;
d>c;
c++){if(a[c]===b){return c
}}return -1
},K="checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",L="[\\x20\\t\\r\\n\\f]",M="(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",N=M.replace("w","w#"),O="\\["+L+"*("+M+")(?:"+L+"*([*^$|!~]?=)"+L+"*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|("+N+"))|)"+L+"*\\]",P=":("+M+")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|"+O+")*)|.*)\\)|)",Q=new RegExp(L+"+","g"),R=new RegExp("^"+L+"+|((?:^|[^\\\\])(?:\\\\.)*)"+L+"+$","g"),S=new RegExp("^"+L+"*,"+L+"*"),T=new RegExp("^"+L+"*([>+~]|"+L+")"+L+"*"),U=new RegExp("="+L+"*([^\\]'\"]*?)"+L+"*\\]","g"),V=new RegExp(P),W=new RegExp("^"+N+"$"),X={ID:new RegExp("^#("+M+")"),CLASS:new RegExp("^\\.("+M+")"),TAG:new RegExp("^("+M.replace("w","w*")+")"),ATTR:new RegExp("^"+O),PSEUDO:new RegExp("^"+P),CHILD:new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\("+L+"*(even|odd|(([+-]|)(\\d*)n|)"+L+"*(?:([+-]|)"+L+"*(\\d+)|))"+L+"*\\)|)","i"),bool:new RegExp("^(?:"+K+")$","i"),needsContext:new RegExp("^"+L+"*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\("+L+"*((?:-\\d)?\\d*)"+L+"*\\)|)(?=[^-]|$)","i")},Y=/^(?:input|select|textarea|button)$/i,Z=/^h\d$/i,$=/^[^{]+\{\s*\[native \w/,_=/^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,ab=/[+~]/,bb=/'|\\/g,cb=new RegExp("\\\\([\\da-f]{1,6}"+L+"?|("+L+")|.)","ig"),db=function(a,b,c){var d="0x"+b-65536;
return d!==d||c?b:0>d?String.fromCharCode(d+65536):String.fromCharCode(d>>10|55296,1023&d|56320)
},eb=function(){m()
};
try{H.apply(E=I.call(v.childNodes),v.childNodes),E[v.childNodes.length].nodeType
}catch(fb){H={apply:E.length?function(a,b){G.apply(a,I.call(b))
}:function(a,b){var c=a.length,d=0;
while(a[c++]=b[d++]){}a.length=c-1
}}
}function gb(a,b,d,e){var f,h,j,k,l,o,r,s,w,x;
if((b?b.ownerDocument||b:v)!==n&&m(b),b=b||n,d=d||[],k=b.nodeType,"string"!=typeof a||!a||1!==k&&9!==k&&11!==k){return d
}if(!e&&p){if(11!==k&&(f=_.exec(a))){if(j=f[1]){if(9===k){if(h=b.getElementById(j),!h||!h.parentNode){return d
}if(h.id===j){return d.push(h),d
}}else{if(b.ownerDocument&&(h=b.ownerDocument.getElementById(j))&&t(b,h)&&h.id===j){return d.push(h),d
}}}else{if(f[2]){return H.apply(d,b.getElementsByTagName(a)),d
}if((j=f[3])&&c.getElementsByClassName){return H.apply(d,b.getElementsByClassName(j)),d
}}}if(c.qsa&&(!q||!q.test(a))){if(s=r=u,w=b,x=1!==k&&a,1===k&&"object"!==b.nodeName.toLowerCase()){o=g(a),(r=b.getAttribute("id"))?s=r.replace(bb,"\\$&"):b.setAttribute("id",s),s="[id='"+s+"'] ",l=o.length;
while(l--){o[l]=s+rb(o[l])
}w=ab.test(a)&&pb(b.parentNode)||b,x=o.join(",")
}if(x){try{return H.apply(d,w.querySelectorAll(x)),d
}catch(y){}finally{r||b.removeAttribute("id")
}}}}return i(a.replace(R,"$1"),b,d,e)
}function hb(){var a=[];
function b(c,e){return a.push(c+" ")>d.cacheLength&&delete b[a.shift()],b[c+" "]=e
}return b
}function ib(a){return a[u]=!0,a
}function jb(a){var b=n.createElement("div");
try{return !!a(b)
}catch(c){return !1
}finally{b.parentNode&&b.parentNode.removeChild(b),b=null
}}function kb(a,b){var c=a.split("|"),e=a.length;
while(e--){d.attrHandle[c[e]]=b
}}function lb(a,b){var c=b&&a,d=c&&1===a.nodeType&&1===b.nodeType&&(~b.sourceIndex||C)-(~a.sourceIndex||C);
if(d){return d
}if(c){while(c=c.nextSibling){if(c===b){return -1
}}}return a?1:-1
}function mb(a){return function(b){var c=b.nodeName.toLowerCase();
return"input"===c&&b.type===a
}
}function nb(a){return function(b){var c=b.nodeName.toLowerCase();
return("input"===c||"button"===c)&&b.type===a
}
}function ob(a){return ib(function(b){return b=+b,ib(function(c,d){var e,f=a([],c.length,b),g=f.length;
while(g--){c[e=f[g]]&&(c[e]=!(d[e]=c[e]))
}})
})
}function pb(a){return a&&"undefined"!=typeof a.getElementsByTagName&&a
}c=gb.support={},f=gb.isXML=function(a){var b=a&&(a.ownerDocument||a).documentElement;
return b?"HTML"!==b.nodeName:!1
},m=gb.setDocument=function(a){var b,e,g=a?a.ownerDocument||a:v;
return g!==n&&9===g.nodeType&&g.documentElement?(n=g,o=g.documentElement,e=g.defaultView,e&&e!==e.top&&(e.addEventListener?e.addEventListener("unload",eb,!1):e.attachEvent&&e.attachEvent("onunload",eb)),p=!f(g),c.attributes=jb(function(a){return a.className="i",!a.getAttribute("className")
}),c.getElementsByTagName=jb(function(a){return a.appendChild(g.createComment("")),!a.getElementsByTagName("*").length
}),c.getElementsByClassName=$.test(g.getElementsByClassName),c.getById=jb(function(a){return o.appendChild(a).id=u,!g.getElementsByName||!g.getElementsByName(u).length
}),c.getById?(d.find.ID=function(a,b){if("undefined"!=typeof b.getElementById&&p){var c=b.getElementById(a);
return c&&c.parentNode?[c]:[]
}},d.filter.ID=function(a){var b=a.replace(cb,db);
return function(a){return a.getAttribute("id")===b
}
}):(delete d.find.ID,d.filter.ID=function(a){var b=a.replace(cb,db);
return function(a){var c="undefined"!=typeof a.getAttributeNode&&a.getAttributeNode("id");
return c&&c.value===b
}
}),d.find.TAG=c.getElementsByTagName?function(a,b){return"undefined"!=typeof b.getElementsByTagName?b.getElementsByTagName(a):c.qsa?b.querySelectorAll(a):void 0
}:function(a,b){var c,d=[],e=0,f=b.getElementsByTagName(a);
if("*"===a){while(c=f[e++]){1===c.nodeType&&d.push(c)
}return d
}return f
},d.find.CLASS=c.getElementsByClassName&&function(a,b){return p?b.getElementsByClassName(a):void 0
},r=[],q=[],(c.qsa=$.test(g.querySelectorAll))&&(jb(function(a){o.appendChild(a).innerHTML="<a id='"+u+"'></a><select id='"+u+"-\f]' msallowcapture=''><option selected=''></option></select>",a.querySelectorAll("[msallowcapture^='']").length&&q.push("[*^$]="+L+"*(?:''|\"\")"),a.querySelectorAll("[selected]").length||q.push("\\["+L+"*(?:value|"+K+")"),a.querySelectorAll("[id~="+u+"-]").length||q.push("~="),a.querySelectorAll(":checked").length||q.push(":checked"),a.querySelectorAll("a#"+u+"+*").length||q.push(".#.+[+~]")
}),jb(function(a){var b=g.createElement("input");
b.setAttribute("type","hidden"),a.appendChild(b).setAttribute("name","D"),a.querySelectorAll("[name=d]").length&&q.push("name"+L+"*[*^$|!~]?="),a.querySelectorAll(":enabled").length||q.push(":enabled",":disabled"),a.querySelectorAll("*,:x"),q.push(",.*:")
})),(c.matchesSelector=$.test(s=o.matches||o.webkitMatchesSelector||o.mozMatchesSelector||o.oMatchesSelector||o.msMatchesSelector))&&jb(function(a){c.disconnectedMatch=s.call(a,"div"),s.call(a,"[s!='']:x"),r.push("!=",P)
}),q=q.length&&new RegExp(q.join("|")),r=r.length&&new RegExp(r.join("|")),b=$.test(o.compareDocumentPosition),t=b||$.test(o.contains)?function(a,b){var c=9===a.nodeType?a.documentElement:a,d=b&&b.parentNode;
return a===d||!(!d||1!==d.nodeType||!(c.contains?c.contains(d):a.compareDocumentPosition&&16&a.compareDocumentPosition(d)))
}:function(a,b){if(b){while(b=b.parentNode){if(b===a){return !0
}}}return !1
},B=b?function(a,b){if(a===b){return l=!0,0
}var d=!a.compareDocumentPosition-!b.compareDocumentPosition;
return d?d:(d=(a.ownerDocument||a)===(b.ownerDocument||b)?a.compareDocumentPosition(b):1,1&d||!c.sortDetached&&b.compareDocumentPosition(a)===d?a===g||a.ownerDocument===v&&t(v,a)?-1:b===g||b.ownerDocument===v&&t(v,b)?1:k?J(k,a)-J(k,b):0:4&d?-1:1)
}:function(a,b){if(a===b){return l=!0,0
}var c,d=0,e=a.parentNode,f=b.parentNode,h=[a],i=[b];
if(!e||!f){return a===g?-1:b===g?1:e?-1:f?1:k?J(k,a)-J(k,b):0
}if(e===f){return lb(a,b)
}c=a;
while(c=c.parentNode){h.unshift(c)
}c=b;
while(c=c.parentNode){i.unshift(c)
}while(h[d]===i[d]){d++
}return d?lb(h[d],i[d]):h[d]===v?-1:i[d]===v?1:0
},g):n
},gb.matches=function(a,b){return gb(a,null,null,b)
},gb.matchesSelector=function(a,b){if((a.ownerDocument||a)!==n&&m(a),b=b.replace(U,"='$1']"),!(!c.matchesSelector||!p||r&&r.test(b)||q&&q.test(b))){try{var d=s.call(a,b);
if(d||c.disconnectedMatch||a.document&&11!==a.document.nodeType){return d
}}catch(e){}}return gb(b,n,null,[a]).length>0
},gb.contains=function(a,b){return(a.ownerDocument||a)!==n&&m(a),t(a,b)
},gb.attr=function(a,b){(a.ownerDocument||a)!==n&&m(a);
var e=d.attrHandle[b.toLowerCase()],f=e&&D.call(d.attrHandle,b.toLowerCase())?e(a,b,!p):void 0;
return void 0!==f?f:c.attributes||!p?a.getAttribute(b):(f=a.getAttributeNode(b))&&f.specified?f.value:null
},gb.error=function(a){throw new Error("Syntax error, unrecognized expression: "+a)
},gb.uniqueSort=function(a){var b,d=[],e=0,f=0;
if(l=!c.detectDuplicates,k=!c.sortStable&&a.slice(0),a.sort(B),l){while(b=a[f++]){b===a[f]&&(e=d.push(f))
}while(e--){a.splice(d[e],1)
}}return k=null,a
},e=gb.getText=function(a){var b,c="",d=0,f=a.nodeType;
if(f){if(1===f||9===f||11===f){if("string"==typeof a.textContent){return a.textContent
}for(a=a.firstChild;
a;
a=a.nextSibling){c+=e(a)
}}else{if(3===f||4===f){return a.nodeValue
}}}else{while(b=a[d++]){c+=e(b)
}}return c
},d=gb.selectors={cacheLength:50,createPseudo:ib,match:X,attrHandle:{},find:{},relative:{">":{dir:"parentNode",first:!0}," ":{dir:"parentNode"},"+":{dir:"previousSibling",first:!0},"~":{dir:"previousSibling"}},preFilter:{ATTR:function(a){return a[1]=a[1].replace(cb,db),a[3]=(a[3]||a[4]||a[5]||"").replace(cb,db),"~="===a[2]&&(a[3]=" "+a[3]+" "),a.slice(0,4)
},CHILD:function(a){return a[1]=a[1].toLowerCase(),"nth"===a[1].slice(0,3)?(a[3]||gb.error(a[0]),a[4]=+(a[4]?a[5]+(a[6]||1):2*("even"===a[3]||"odd"===a[3])),a[5]=+(a[7]+a[8]||"odd"===a[3])):a[3]&&gb.error(a[0]),a
},PSEUDO:function(a){var b,c=!a[6]&&a[2];
return X.CHILD.test(a[0])?null:(a[3]?a[2]=a[4]||a[5]||"":c&&V.test(c)&&(b=g(c,!0))&&(b=c.indexOf(")",c.length-b)-c.length)&&(a[0]=a[0].slice(0,b),a[2]=c.slice(0,b)),a.slice(0,3))
}},filter:{TAG:function(a){var b=a.replace(cb,db).toLowerCase();
return"*"===a?function(){return !0
}:function(a){return a.nodeName&&a.nodeName.toLowerCase()===b
}
},CLASS:function(a){var b=y[a+" "];
return b||(b=new RegExp("(^|"+L+")"+a+"("+L+"|$)"))&&y(a,function(a){return b.test("string"==typeof a.className&&a.className||"undefined"!=typeof a.getAttribute&&a.getAttribute("class")||"")
})
},ATTR:function(a,b,c){return function(d){var e=gb.attr(d,a);
return null==e?"!="===b:b?(e+="","="===b?e===c:"!="===b?e!==c:"^="===b?c&&0===e.indexOf(c):"*="===b?c&&e.indexOf(c)>-1:"$="===b?c&&e.slice(-c.length)===c:"~="===b?(" "+e.replace(Q," ")+" ").indexOf(c)>-1:"|="===b?e===c||e.slice(0,c.length+1)===c+"-":!1):!0
}
},CHILD:function(a,b,c,d,e){var f="nth"!==a.slice(0,3),g="last"!==a.slice(-4),h="of-type"===b;
return 1===d&&0===e?function(a){return !!a.parentNode
}:function(b,c,i){var j,k,l,m,n,o,p=f!==g?"nextSibling":"previousSibling",q=b.parentNode,r=h&&b.nodeName.toLowerCase(),s=!i&&!h;
if(q){if(f){while(p){l=b;
while(l=l[p]){if(h?l.nodeName.toLowerCase()===r:1===l.nodeType){return !1
}}o=p="only"===a&&!o&&"nextSibling"
}return !0
}if(o=[g?q.firstChild:q.lastChild],g&&s){k=q[u]||(q[u]={}),j=k[a]||[],n=j[0]===w&&j[1],m=j[0]===w&&j[2],l=n&&q.childNodes[n];
while(l=++n&&l&&l[p]||(m=n=0)||o.pop()){if(1===l.nodeType&&++m&&l===b){k[a]=[w,n,m];
break
}}}else{if(s&&(j=(b[u]||(b[u]={}))[a])&&j[0]===w){m=j[1]
}else{while(l=++n&&l&&l[p]||(m=n=0)||o.pop()){if((h?l.nodeName.toLowerCase()===r:1===l.nodeType)&&++m&&(s&&((l[u]||(l[u]={}))[a]=[w,m]),l===b)){break
}}}}return m-=e,m===d||m%d===0&&m/d>=0
}}
},PSEUDO:function(a,b){var c,e=d.pseudos[a]||d.setFilters[a.toLowerCase()]||gb.error("unsupported pseudo: "+a);
return e[u]?e(b):e.length>1?(c=[a,a,"",b],d.setFilters.hasOwnProperty(a.toLowerCase())?ib(function(a,c){var d,f=e(a,b),g=f.length;
while(g--){d=J(a,f[g]),a[d]=!(c[d]=f[g])
}}):function(a){return e(a,0,c)
}):e
}},pseudos:{not:ib(function(a){var b=[],c=[],d=h(a.replace(R,"$1"));
return d[u]?ib(function(a,b,c,e){var f,g=d(a,null,e,[]),h=a.length;
while(h--){(f=g[h])&&(a[h]=!(b[h]=f))
}}):function(a,e,f){return b[0]=a,d(b,null,f,c),b[0]=null,!c.pop()
}
}),has:ib(function(a){return function(b){return gb(a,b).length>0
}
}),contains:ib(function(a){return a=a.replace(cb,db),function(b){return(b.textContent||b.innerText||e(b)).indexOf(a)>-1
}
}),lang:ib(function(a){return W.test(a||"")||gb.error("unsupported lang: "+a),a=a.replace(cb,db).toLowerCase(),function(b){var c;
do{if(c=p?b.lang:b.getAttribute("xml:lang")||b.getAttribute("lang")){return c=c.toLowerCase(),c===a||0===c.indexOf(a+"-")
}}while((b=b.parentNode)&&1===b.nodeType);
return !1
}
}),target:function(b){var c=a.location&&a.location.hash;
return c&&c.slice(1)===b.id
},root:function(a){return a===o
},focus:function(a){return a===n.activeElement&&(!n.hasFocus||n.hasFocus())&&!!(a.type||a.href||~a.tabIndex)
},enabled:function(a){return a.disabled===!1
},disabled:function(a){return a.disabled===!0
},checked:function(a){var b=a.nodeName.toLowerCase();
return"input"===b&&!!a.checked||"option"===b&&!!a.selected
},selected:function(a){return a.parentNode&&a.parentNode.selectedIndex,a.selected===!0
},empty:function(a){for(a=a.firstChild;
a;
a=a.nextSibling){if(a.nodeType<6){return !1
}}return !0
},parent:function(a){return !d.pseudos.empty(a)
},header:function(a){return Z.test(a.nodeName)
},input:function(a){return Y.test(a.nodeName)
},button:function(a){var b=a.nodeName.toLowerCase();
return"input"===b&&"button"===a.type||"button"===b
},text:function(a){var b;
return"input"===a.nodeName.toLowerCase()&&"text"===a.type&&(null==(b=a.getAttribute("type"))||"text"===b.toLowerCase())
},first:ob(function(){return[0]
}),last:ob(function(a,b){return[b-1]
}),eq:ob(function(a,b,c){return[0>c?c+b:c]
}),even:ob(function(a,b){for(var c=0;
b>c;
c+=2){a.push(c)
}return a
}),odd:ob(function(a,b){for(var c=1;
b>c;
c+=2){a.push(c)
}return a
}),lt:ob(function(a,b,c){for(var d=0>c?c+b:c;
--d>=0;
){a.push(d)
}return a
}),gt:ob(function(a,b,c){for(var d=0>c?c+b:c;
++d<b;
){a.push(d)
}return a
})}},d.pseudos.nth=d.pseudos.eq;
for(b in {radio:!0,checkbox:!0,file:!0,password:!0,image:!0}){d.pseudos[b]=mb(b)
}for(b in {submit:!0,reset:!0}){d.pseudos[b]=nb(b)
}function qb(){}qb.prototype=d.filters=d.pseudos,d.setFilters=new qb,g=gb.tokenize=function(a,b){var c,e,f,g,h,i,j,k=z[a+" "];
if(k){return b?0:k.slice(0)
}h=a,i=[],j=d.preFilter;
while(h){(!c||(e=S.exec(h)))&&(e&&(h=h.slice(e[0].length)||h),i.push(f=[])),c=!1,(e=T.exec(h))&&(c=e.shift(),f.push({value:c,type:e[0].replace(R," ")}),h=h.slice(c.length));
for(g in d.filter){!(e=X[g].exec(h))||j[g]&&!(e=j[g](e))||(c=e.shift(),f.push({value:c,type:g,matches:e}),h=h.slice(c.length))
}if(!c){break
}}return b?h.length:h?gb.error(a):z(a,i).slice(0)
};
function rb(a){for(var b=0,c=a.length,d="";
c>b;
b++){d+=a[b].value
}return d
}function sb(a,b,c){var d=b.dir,e=c&&"parentNode"===d,f=x++;
return b.first?function(b,c,f){while(b=b[d]){if(1===b.nodeType||e){return a(b,c,f)
}}}:function(b,c,g){var h,i,j=[w,f];
if(g){while(b=b[d]){if((1===b.nodeType||e)&&a(b,c,g)){return !0
}}}else{while(b=b[d]){if(1===b.nodeType||e){if(i=b[u]||(b[u]={}),(h=i[d])&&h[0]===w&&h[1]===f){return j[2]=h[2]
}if(i[d]=j,j[2]=a(b,c,g)){return !0
}}}}}
}function tb(a){return a.length>1?function(b,c,d){var e=a.length;
while(e--){if(!a[e](b,c,d)){return !1
}}return !0
}:a[0]
}function ub(a,b,c){for(var d=0,e=b.length;
e>d;
d++){gb(a,b[d],c)
}return c
}function vb(a,b,c,d,e){for(var f,g=[],h=0,i=a.length,j=null!=b;
i>h;
h++){(f=a[h])&&(!c||c(f,d,e))&&(g.push(f),j&&b.push(h))
}return g
}function wb(a,b,c,d,e,f){return d&&!d[u]&&(d=wb(d)),e&&!e[u]&&(e=wb(e,f)),ib(function(f,g,h,i){var j,k,l,m=[],n=[],o=g.length,p=f||ub(b||"*",h.nodeType?[h]:h,[]),q=!a||!f&&b?p:vb(p,m,a,h,i),r=c?e||(f?a:o||d)?[]:g:q;
if(c&&c(q,r,h,i),d){j=vb(r,n),d(j,[],h,i),k=j.length;
while(k--){(l=j[k])&&(r[n[k]]=!(q[n[k]]=l))
}}if(f){if(e||a){if(e){j=[],k=r.length;
while(k--){(l=r[k])&&j.push(q[k]=l)
}e(null,r=[],j,i)
}k=r.length;
while(k--){(l=r[k])&&(j=e?J(f,l):m[k])>-1&&(f[j]=!(g[j]=l))
}}}else{r=vb(r===g?r.splice(o,r.length):r),e?e(null,g,r,i):H.apply(g,r)
}})
}function xb(a){for(var b,c,e,f=a.length,g=d.relative[a[0].type],h=g||d.relative[" "],i=g?1:0,k=sb(function(a){return a===b
},h,!0),l=sb(function(a){return J(b,a)>-1
},h,!0),m=[function(a,c,d){var e=!g&&(d||c!==j)||((b=c).nodeType?k(a,c,d):l(a,c,d));
return b=null,e
}];
f>i;
i++){if(c=d.relative[a[i].type]){m=[sb(tb(m),c)]
}else{if(c=d.filter[a[i].type].apply(null,a[i].matches),c[u]){for(e=++i;
f>e;
e++){if(d.relative[a[e].type]){break
}}return wb(i>1&&tb(m),i>1&&rb(a.slice(0,i-1).concat({value:" "===a[i-2].type?"*":""})).replace(R,"$1"),c,e>i&&xb(a.slice(i,e)),f>e&&xb(a=a.slice(e)),f>e&&rb(a))
}m.push(c)
}}return tb(m)
}function yb(a,b){var c=b.length>0,e=a.length>0,f=function(f,g,h,i,k){var l,m,o,p=0,q="0",r=f&&[],s=[],t=j,u=f||e&&d.find.TAG("*",k),v=w+=null==t?1:Math.random()||0.1,x=u.length;
for(k&&(j=g!==n&&g);
q!==x&&null!=(l=u[q]);
q++){if(e&&l){m=0;
while(o=a[m++]){if(o(l,g,h)){i.push(l);
break
}}k&&(w=v)
}c&&((l=!o&&l)&&p--,f&&r.push(l))
}if(p+=q,c&&q!==p){m=0;
while(o=b[m++]){o(r,s,g,h)
}if(f){if(p>0){while(q--){r[q]||s[q]||(s[q]=F.call(i))
}}s=vb(s)
}H.apply(i,s),k&&!f&&s.length>0&&p+b.length>1&&gb.uniqueSort(i)
}return k&&(w=v,j=t),r
};
return c?ib(f):f
}return h=gb.compile=function(a,b){var c,d=[],e=[],f=A[a+" "];
if(!f){b||(b=g(a)),c=b.length;
while(c--){f=xb(b[c]),f[u]?d.push(f):e.push(f)
}f=A(a,yb(e,d)),f.selector=a
}return f
},i=gb.select=function(a,b,e,f){var i,j,k,l,m,n="function"==typeof a&&a,o=!f&&g(a=n.selector||a);
if(e=e||[],1===o.length){if(j=o[0]=o[0].slice(0),j.length>2&&"ID"===(k=j[0]).type&&c.getById&&9===b.nodeType&&p&&d.relative[j[1].type]){if(b=(d.find.ID(k.matches[0].replace(cb,db),b)||[])[0],!b){return e
}n&&(b=b.parentNode),a=a.slice(j.shift().value.length)
}i=X.needsContext.test(a)?0:j.length;
while(i--){if(k=j[i],d.relative[l=k.type]){break
}if((m=d.find[l])&&(f=m(k.matches[0].replace(cb,db),ab.test(j[0].type)&&pb(b.parentNode)||b))){if(j.splice(i,1),a=f.length&&rb(j),!a){return H.apply(e,f),e
}break
}}}return(n||h(a,o))(f,b,!p,e,ab.test(a)&&pb(b.parentNode)||b),e
},c.sortStable=u.split("").sort(B).join("")===u,c.detectDuplicates=!!l,m(),c.sortDetached=jb(function(a){return 1&a.compareDocumentPosition(n.createElement("div"))
}),jb(function(a){return a.innerHTML="<a href='#'></a>","#"===a.firstChild.getAttribute("href")
})||kb("type|href|height|width",function(a,b,c){return c?void 0:a.getAttribute(b,"type"===b.toLowerCase()?1:2)
}),c.attributes&&jb(function(a){return a.innerHTML="<input/>",a.firstChild.setAttribute("value",""),""===a.firstChild.getAttribute("value")
})||kb("value",function(a,b,c){return c||"input"!==a.nodeName.toLowerCase()?void 0:a.defaultValue
}),jb(function(a){return null==a.getAttribute("disabled")
})||kb(K,function(a,b,c){var d;
return c?void 0:a[b]===!0?b.toLowerCase():(d=a.getAttributeNode(b))&&d.specified?d.value:null
}),gb
}(a);
m.find=s,m.expr=s.selectors,m.expr[":"]=m.expr.pseudos,m.unique=s.uniqueSort,m.text=s.getText,m.isXMLDoc=s.isXML,m.contains=s.contains;
var t=m.expr.match.needsContext,u=/^<(\w+)\s*\/?>(?:<\/\1>|)$/,v=/^.[^:#\[\.,]*$/;
function w(a,b,c){if(m.isFunction(b)){return m.grep(a,function(a,d){return !!b.call(a,d,a)!==c
})
}if(b.nodeType){return m.grep(a,function(a){return a===b!==c
})
}if("string"==typeof b){if(v.test(b)){return m.filter(b,a,c)
}b=m.filter(b,a)
}return m.grep(a,function(a){return m.inArray(a,b)>=0!==c
})
}m.filter=function(a,b,c){var d=b[0];
return c&&(a=":not("+a+")"),1===b.length&&1===d.nodeType?m.find.matchesSelector(d,a)?[d]:[]:m.find.matches(a,m.grep(b,function(a){return 1===a.nodeType
}))
},m.fn.extend({find:function(a){var b,c=[],d=this,e=d.length;
if("string"!=typeof a){return this.pushStack(m(a).filter(function(){for(b=0;
e>b;
b++){if(m.contains(d[b],this)){return !0
}}}))
}for(b=0;
e>b;
b++){m.find(a,d[b],c)
}return c=this.pushStack(e>1?m.unique(c):c),c.selector=this.selector?this.selector+" "+a:a,c
},filter:function(a){return this.pushStack(w(this,a||[],!1))
},not:function(a){return this.pushStack(w(this,a||[],!0))
},is:function(a){return !!w(this,"string"==typeof a&&t.test(a)?m(a):a||[],!1).length
}});
var x,y=a.document,z=/^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/,A=m.fn.init=function(a,b){var c,d;
if(!a){return this
}if("string"==typeof a){if(c="<"===a.charAt(0)&&">"===a.charAt(a.length-1)&&a.length>=3?[null,a,null]:z.exec(a),!c||!c[1]&&b){return !b||b.jquery?(b||x).find(a):this.constructor(b).find(a)
}if(c[1]){if(b=b instanceof m?b[0]:b,m.merge(this,m.parseHTML(c[1],b&&b.nodeType?b.ownerDocument||b:y,!0)),u.test(c[1])&&m.isPlainObject(b)){for(c in b){m.isFunction(this[c])?this[c](b[c]):this.attr(c,b[c])
}}return this
}if(d=y.getElementById(c[2]),d&&d.parentNode){if(d.id!==c[2]){return x.find(a)
}this.length=1,this[0]=d
}return this.context=y,this.selector=a,this
}return a.nodeType?(this.context=this[0]=a,this.length=1,this):m.isFunction(a)?"undefined"!=typeof x.ready?x.ready(a):a(m):(void 0!==a.selector&&(this.selector=a.selector,this.context=a.context),m.makeArray(a,this))
};
A.prototype=m.fn,x=m(y);
var B=/^(?:parents|prev(?:Until|All))/,C={children:!0,contents:!0,next:!0,prev:!0};
m.extend({dir:function(a,b,c){var d=[],e=a[b];
while(e&&9!==e.nodeType&&(void 0===c||1!==e.nodeType||!m(e).is(c))){1===e.nodeType&&d.push(e),e=e[b]
}return d
},sibling:function(a,b){for(var c=[];
a;
a=a.nextSibling){1===a.nodeType&&a!==b&&c.push(a)
}return c
}}),m.fn.extend({has:function(a){var b,c=m(a,this),d=c.length;
return this.filter(function(){for(b=0;
d>b;
b++){if(m.contains(this,c[b])){return !0
}}})
},closest:function(a,b){for(var c,d=0,e=this.length,f=[],g=t.test(a)||"string"!=typeof a?m(a,b||this.context):0;
e>d;
d++){for(c=this[d];
c&&c!==b;
c=c.parentNode){if(c.nodeType<11&&(g?g.index(c)>-1:1===c.nodeType&&m.find.matchesSelector(c,a))){f.push(c);
break
}}}return this.pushStack(f.length>1?m.unique(f):f)
},index:function(a){return a?"string"==typeof a?m.inArray(this[0],m(a)):m.inArray(a.jquery?a[0]:a,this):this[0]&&this[0].parentNode?this.first().prevAll().length:-1
},add:function(a,b){return this.pushStack(m.unique(m.merge(this.get(),m(a,b))))
},addBack:function(a){return this.add(null==a?this.prevObject:this.prevObject.filter(a))
}});
function D(a,b){do{a=a[b]
}while(a&&1!==a.nodeType);
return a
}m.each({parent:function(a){var b=a.parentNode;
return b&&11!==b.nodeType?b:null
},parents:function(a){return m.dir(a,"parentNode")
},parentsUntil:function(a,b,c){return m.dir(a,"parentNode",c)
},next:function(a){return D(a,"nextSibling")
},prev:function(a){return D(a,"previousSibling")
},nextAll:function(a){return m.dir(a,"nextSibling")
},prevAll:function(a){return m.dir(a,"previousSibling")
},nextUntil:function(a,b,c){return m.dir(a,"nextSibling",c)
},prevUntil:function(a,b,c){return m.dir(a,"previousSibling",c)
},siblings:function(a){return m.sibling((a.parentNode||{}).firstChild,a)
},children:function(a){return m.sibling(a.firstChild)
},contents:function(a){return m.nodeName(a,"iframe")?a.contentDocument||a.contentWindow.document:m.merge([],a.childNodes)
}},function(a,b){m.fn[a]=function(c,d){var e=m.map(this,b,c);
return"Until"!==a.slice(-5)&&(d=c),d&&"string"==typeof d&&(e=m.filter(d,e)),this.length>1&&(C[a]||(e=m.unique(e)),B.test(a)&&(e=e.reverse())),this.pushStack(e)
}
});
var E=/\S+/g,F={};
function G(a){var b=F[a]={};
return m.each(a.match(E)||[],function(a,c){b[c]=!0
}),b
}m.Callbacks=function(a){a="string"==typeof a?F[a]||G(a):m.extend({},a);
var b,c,d,e,f,g,h=[],i=!a.once&&[],j=function(l){for(c=a.memory&&l,d=!0,f=g||0,g=0,e=h.length,b=!0;
h&&e>f;
f++){if(h[f].apply(l[0],l[1])===!1&&a.stopOnFalse){c=!1;
break
}}b=!1,h&&(i?i.length&&j(i.shift()):c?h=[]:k.disable())
},k={add:function(){if(h){var d=h.length;
!function f(b){m.each(b,function(b,c){var d=m.type(c);
"function"===d?a.unique&&k.has(c)||h.push(c):c&&c.length&&"string"!==d&&f(c)
})
}(arguments),b?e=h.length:c&&(g=d,j(c))
}return this
},remove:function(){return h&&m.each(arguments,function(a,c){var d;
while((d=m.inArray(c,h,d))>-1){h.splice(d,1),b&&(e>=d&&e--,f>=d&&f--)
}}),this
},has:function(a){return a?m.inArray(a,h)>-1:!(!h||!h.length)
},empty:function(){return h=[],e=0,this
},disable:function(){return h=i=c=void 0,this
},disabled:function(){return !h
},lock:function(){return i=void 0,c||k.disable(),this
},locked:function(){return !i
},fireWith:function(a,c){return !h||d&&!i||(c=c||[],c=[a,c.slice?c.slice():c],b?i.push(c):j(c)),this
},fire:function(){return k.fireWith(this,arguments),this
},fired:function(){return !!d
}};
return k
},m.extend({Deferred:function(a){var b=[["resolve","done",m.Callbacks("once memory"),"resolved"],["reject","fail",m.Callbacks("once memory"),"rejected"],["notify","progress",m.Callbacks("memory")]],c="pending",d={state:function(){return c
},always:function(){return e.done(arguments).fail(arguments),this
},then:function(){var a=arguments;
return m.Deferred(function(c){m.each(b,function(b,f){var g=m.isFunction(a[b])&&a[b];
e[f[1]](function(){var a=g&&g.apply(this,arguments);
a&&m.isFunction(a.promise)?a.promise().done(c.resolve).fail(c.reject).progress(c.notify):c[f[0]+"With"](this===d?c.promise():this,g?[a]:arguments)
})
}),a=null
}).promise()
},promise:function(a){return null!=a?m.extend(a,d):d
}},e={};
return d.pipe=d.then,m.each(b,function(a,f){var g=f[2],h=f[3];
d[f[1]]=g.add,h&&g.add(function(){c=h
},b[1^a][2].disable,b[2][2].lock),e[f[0]]=function(){return e[f[0]+"With"](this===e?d:this,arguments),this
},e[f[0]+"With"]=g.fireWith
}),d.promise(e),a&&a.call(e,e),e
},when:function(a){var b=0,c=d.call(arguments),e=c.length,f=1!==e||a&&m.isFunction(a.promise)?e:0,g=1===f?a:m.Deferred(),h=function(a,b,c){return function(e){b[a]=this,c[a]=arguments.length>1?d.call(arguments):e,c===i?g.notifyWith(b,c):--f||g.resolveWith(b,c)
}
},i,j,k;
if(e>1){for(i=new Array(e),j=new Array(e),k=new Array(e);
e>b;
b++){c[b]&&m.isFunction(c[b].promise)?c[b].promise().done(h(b,k,c)).fail(g.reject).progress(h(b,j,i)):--f
}}return f||g.resolveWith(k,c),g.promise()
}});
var H;
m.fn.ready=function(a){return m.ready.promise().done(a),this
},m.extend({isReady:!1,readyWait:1,holdReady:function(a){a?m.readyWait++:m.ready(!0)
},ready:function(a){if(a===!0?!--m.readyWait:!m.isReady){if(!y.body){return setTimeout(m.ready)
}m.isReady=!0,a!==!0&&--m.readyWait>0||(H.resolveWith(y,[m]),m.fn.triggerHandler&&(m(y).triggerHandler("ready"),m(y).off("ready")))
}}});
function I(){y.addEventListener?(y.removeEventListener("DOMContentLoaded",J,!1),a.removeEventListener("load",J,!1)):(y.detachEvent("onreadystatechange",J),a.detachEvent("onload",J))
}function J(){(y.addEventListener||"load"===event.type||"complete"===y.readyState)&&(I(),m.ready())
}m.ready.promise=function(b){if(!H){if(H=m.Deferred(),"complete"===y.readyState){setTimeout(m.ready)
}else{if(y.addEventListener){y.addEventListener("DOMContentLoaded",J,!1),a.addEventListener("load",J,!1)
}else{y.attachEvent("onreadystatechange",J),a.attachEvent("onload",J);
var c=!1;
try{c=null==a.frameElement&&y.documentElement
}catch(d){}c&&c.doScroll&&!function e(){if(!m.isReady){try{c.doScroll("left")
}catch(a){return setTimeout(e,50)
}I(),m.ready()
}}()
}}}return H.promise(b)
};
var K="undefined",L;
for(L in m(k)){break
}k.ownLast="0"!==L,k.inlineBlockNeedsLayout=!1,m(function(){var a,b,c,d;
c=y.getElementsByTagName("body")[0],c&&c.style&&(b=y.createElement("div"),d=y.createElement("div"),d.style.cssText="position:absolute;border:0;width:0;height:0;top:0;left:-9999px",c.appendChild(d).appendChild(b),typeof b.style.zoom!==K&&(b.style.cssText="display:inline;margin:0;border:0;padding:1px;width:1px;zoom:1",k.inlineBlockNeedsLayout=a=3===b.offsetWidth,a&&(c.style.zoom=1)),c.removeChild(d))
}),function(){var a=y.createElement("div");
if(null==k.deleteExpando){k.deleteExpando=!0;
try{delete a.test
}catch(b){k.deleteExpando=!1
}}a=null
}(),m.acceptData=function(a){var b=m.noData[(a.nodeName+" ").toLowerCase()],c=+a.nodeType||1;
return 1!==c&&9!==c?!1:!b||b!==!0&&a.getAttribute("classid")===b
};
var M=/^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,N=/([A-Z])/g;
function O(a,b,c){if(void 0===c&&1===a.nodeType){var d="data-"+b.replace(N,"-$1").toLowerCase();
if(c=a.getAttribute(d),"string"==typeof c){try{c="true"===c?!0:"false"===c?!1:"null"===c?null:+c+""===c?+c:M.test(c)?m.parseJSON(c):c
}catch(e){}m.data(a,b,c)
}else{c=void 0
}}return c
}function P(a){var b;
for(b in a){if(("data"!==b||!m.isEmptyObject(a[b]))&&"toJSON"!==b){return !1
}}return !0
}function Q(a,b,d,e){if(m.acceptData(a)){var f,g,h=m.expando,i=a.nodeType,j=i?m.cache:a,k=i?a[h]:a[h]&&h;
if(k&&j[k]&&(e||j[k].data)||void 0!==d||"string"!=typeof b){return k||(k=i?a[h]=c.pop()||m.guid++:h),j[k]||(j[k]=i?{}:{toJSON:m.noop}),("object"==typeof b||"function"==typeof b)&&(e?j[k]=m.extend(j[k],b):j[k].data=m.extend(j[k].data,b)),g=j[k],e||(g.data||(g.data={}),g=g.data),void 0!==d&&(g[m.camelCase(b)]=d),"string"==typeof b?(f=g[b],null==f&&(f=g[m.camelCase(b)])):f=g,f
}}}function R(a,b,c){if(m.acceptData(a)){var d,e,f=a.nodeType,g=f?m.cache:a,h=f?a[m.expando]:m.expando;
if(g[h]){if(b&&(d=c?g[h]:g[h].data)){m.isArray(b)?b=b.concat(m.map(b,m.camelCase)):b in d?b=[b]:(b=m.camelCase(b),b=b in d?[b]:b.split(" ")),e=b.length;
while(e--){delete d[b[e]]
}if(c?!P(d):!m.isEmptyObject(d)){return
}}(c||(delete g[h].data,P(g[h])))&&(f?m.cleanData([a],!0):k.deleteExpando||g!=g.window?delete g[h]:g[h]=null)
}}}m.extend({cache:{},noData:{"applet ":!0,"embed ":!0,"object ":"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"},hasData:function(a){return a=a.nodeType?m.cache[a[m.expando]]:a[m.expando],!!a&&!P(a)
},data:function(a,b,c){return Q(a,b,c)
},removeData:function(a,b){return R(a,b)
},_data:function(a,b,c){return Q(a,b,c,!0)
},_removeData:function(a,b){return R(a,b,!0)
}}),m.fn.extend({data:function(a,b){var c,d,e,f=this[0],g=f&&f.attributes;
if(void 0===a){if(this.length&&(e=m.data(f),1===f.nodeType&&!m._data(f,"parsedAttrs"))){c=g.length;
while(c--){g[c]&&(d=g[c].name,0===d.indexOf("data-")&&(d=m.camelCase(d.slice(5)),O(f,d,e[d])))
}m._data(f,"parsedAttrs",!0)
}return e
}return"object"==typeof a?this.each(function(){m.data(this,a)
}):arguments.length>1?this.each(function(){m.data(this,a,b)
}):f?O(f,a,m.data(f,a)):void 0
},removeData:function(a){return this.each(function(){m.removeData(this,a)
})
}}),m.extend({queue:function(a,b,c){var d;
return a?(b=(b||"fx")+"queue",d=m._data(a,b),c&&(!d||m.isArray(c)?d=m._data(a,b,m.makeArray(c)):d.push(c)),d||[]):void 0
},dequeue:function(a,b){b=b||"fx";
var c=m.queue(a,b),d=c.length,e=c.shift(),f=m._queueHooks(a,b),g=function(){m.dequeue(a,b)
};
"inprogress"===e&&(e=c.shift(),d--),e&&("fx"===b&&c.unshift("inprogress"),delete f.stop,e.call(a,g,f)),!d&&f&&f.empty.fire()
},_queueHooks:function(a,b){var c=b+"queueHooks";
return m._data(a,c)||m._data(a,c,{empty:m.Callbacks("once memory").add(function(){m._removeData(a,b+"queue"),m._removeData(a,c)
})})
}}),m.fn.extend({queue:function(a,b){var c=2;
return"string"!=typeof a&&(b=a,a="fx",c--),arguments.length<c?m.queue(this[0],a):void 0===b?this:this.each(function(){var c=m.queue(this,a,b);
m._queueHooks(this,a),"fx"===a&&"inprogress"!==c[0]&&m.dequeue(this,a)
})
},dequeue:function(a){return this.each(function(){m.dequeue(this,a)
})
},clearQueue:function(a){return this.queue(a||"fx",[])
},promise:function(a,b){var c,d=1,e=m.Deferred(),f=this,g=this.length,h=function(){--d||e.resolveWith(f,[f])
};
"string"!=typeof a&&(b=a,a=void 0),a=a||"fx";
while(g--){c=m._data(f[g],a+"queueHooks"),c&&c.empty&&(d++,c.empty.add(h))
}return h(),e.promise(b)
}});
var S=/[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,T=["Top","Right","Bottom","Left"],U=function(a,b){return a=b||a,"none"===m.css(a,"display")||!m.contains(a.ownerDocument,a)
},V=m.access=function(a,b,c,d,e,f,g){var h=0,i=a.length,j=null==c;
if("object"===m.type(c)){e=!0;
for(h in c){m.access(a,b,h,c[h],!0,f,g)
}}else{if(void 0!==d&&(e=!0,m.isFunction(d)||(g=!0),j&&(g?(b.call(a,d),b=null):(j=b,b=function(a,b,c){return j.call(m(a),c)
})),b)){for(;
i>h;
h++){b(a[h],c,g?d:d.call(a[h],h,b(a[h],c)))
}}}return e?a:j?b.call(a):i?b(a[0],c):f
},W=/^(?:checkbox|radio)$/i;
!function(){var a=y.createElement("input"),b=y.createElement("div"),c=y.createDocumentFragment();
if(b.innerHTML="  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",k.leadingWhitespace=3===b.firstChild.nodeType,k.tbody=!b.getElementsByTagName("tbody").length,k.htmlSerialize=!!b.getElementsByTagName("link").length,k.html5Clone="<:nav></:nav>"!==y.createElement("nav").cloneNode(!0).outerHTML,a.type="checkbox",a.checked=!0,c.appendChild(a),k.appendChecked=a.checked,b.innerHTML="<textarea>x</textarea>",k.noCloneChecked=!!b.cloneNode(!0).lastChild.defaultValue,c.appendChild(b),b.innerHTML="<input type='radio' checked='checked' name='t'/>",k.checkClone=b.cloneNode(!0).cloneNode(!0).lastChild.checked,k.noCloneEvent=!0,b.attachEvent&&(b.attachEvent("onclick",function(){k.noCloneEvent=!1
}),b.cloneNode(!0).click()),null==k.deleteExpando){k.deleteExpando=!0;
try{delete b.test
}catch(d){k.deleteExpando=!1
}}}(),function(){var b,c,d=y.createElement("div");
for(b in {submit:!0,change:!0,focusin:!0}){c="on"+b,(k[b+"Bubbles"]=c in a)||(d.setAttribute(c,"t"),k[b+"Bubbles"]=d.attributes[c].expando===!1)
}d=null
}();
var X=/^(?:input|select|textarea)$/i,Y=/^key/,Z=/^(?:mouse|pointer|contextmenu)|click/,$=/^(?:focusinfocus|focusoutblur)$/,_=/^([^.]*)(?:\.(.+)|)$/;
function ab(){return !0
}function bb(){return !1
}function cb(){try{return y.activeElement
}catch(a){}}m.event={global:{},add:function(a,b,c,d,e){var f,g,h,i,j,k,l,n,o,p,q,r=m._data(a);
if(r){c.handler&&(i=c,c=i.handler,e=i.selector),c.guid||(c.guid=m.guid++),(g=r.events)||(g=r.events={}),(k=r.handle)||(k=r.handle=function(a){return typeof m===K||a&&m.event.triggered===a.type?void 0:m.event.dispatch.apply(k.elem,arguments)
},k.elem=a),b=(b||"").match(E)||[""],h=b.length;
while(h--){f=_.exec(b[h])||[],o=q=f[1],p=(f[2]||"").split(".").sort(),o&&(j=m.event.special[o]||{},o=(e?j.delegateType:j.bindType)||o,j=m.event.special[o]||{},l=m.extend({type:o,origType:q,data:d,handler:c,guid:c.guid,selector:e,needsContext:e&&m.expr.match.needsContext.test(e),namespace:p.join(".")},i),(n=g[o])||(n=g[o]=[],n.delegateCount=0,j.setup&&j.setup.call(a,d,p,k)!==!1||(a.addEventListener?a.addEventListener(o,k,!1):a.attachEvent&&a.attachEvent("on"+o,k))),j.add&&(j.add.call(a,l),l.handler.guid||(l.handler.guid=c.guid)),e?n.splice(n.delegateCount++,0,l):n.push(l),m.event.global[o]=!0)
}a=null
}},remove:function(a,b,c,d,e){var f,g,h,i,j,k,l,n,o,p,q,r=m.hasData(a)&&m._data(a);
if(r&&(k=r.events)){b=(b||"").match(E)||[""],j=b.length;
while(j--){if(h=_.exec(b[j])||[],o=q=h[1],p=(h[2]||"").split(".").sort(),o){l=m.event.special[o]||{},o=(d?l.delegateType:l.bindType)||o,n=k[o]||[],h=h[2]&&new RegExp("(^|\\.)"+p.join("\\.(?:.*\\.|)")+"(\\.|$)"),i=f=n.length;
while(f--){g=n[f],!e&&q!==g.origType||c&&c.guid!==g.guid||h&&!h.test(g.namespace)||d&&d!==g.selector&&("**"!==d||!g.selector)||(n.splice(f,1),g.selector&&n.delegateCount--,l.remove&&l.remove.call(a,g))
}i&&!n.length&&(l.teardown&&l.teardown.call(a,p,r.handle)!==!1||m.removeEvent(a,o,r.handle),delete k[o])
}else{for(o in k){m.event.remove(a,o+b[j],c,d,!0)
}}}m.isEmptyObject(k)&&(delete r.handle,m._removeData(a,"events"))
}},trigger:function(b,c,d,e){var f,g,h,i,k,l,n,o=[d||y],p=j.call(b,"type")?b.type:b,q=j.call(b,"namespace")?b.namespace.split("."):[];
if(h=l=d=d||y,3!==d.nodeType&&8!==d.nodeType&&!$.test(p+m.event.triggered)&&(p.indexOf(".")>=0&&(q=p.split("."),p=q.shift(),q.sort()),g=p.indexOf(":")<0&&"on"+p,b=b[m.expando]?b:new m.Event(p,"object"==typeof b&&b),b.isTrigger=e?2:3,b.namespace=q.join("."),b.namespace_re=b.namespace?new RegExp("(^|\\.)"+q.join("\\.(?:.*\\.|)")+"(\\.|$)"):null,b.result=void 0,b.target||(b.target=d),c=null==c?[b]:m.makeArray(c,[b]),k=m.event.special[p]||{},e||!k.trigger||k.trigger.apply(d,c)!==!1)){if(!e&&!k.noBubble&&!m.isWindow(d)){for(i=k.delegateType||p,$.test(i+p)||(h=h.parentNode);
h;
h=h.parentNode){o.push(h),l=h
}l===(d.ownerDocument||y)&&o.push(l.defaultView||l.parentWindow||a)
}n=0;
while((h=o[n++])&&!b.isPropagationStopped()){b.type=n>1?i:k.bindType||p,f=(m._data(h,"events")||{})[b.type]&&m._data(h,"handle"),f&&f.apply(h,c),f=g&&h[g],f&&f.apply&&m.acceptData(h)&&(b.result=f.apply(h,c),b.result===!1&&b.preventDefault())
}if(b.type=p,!e&&!b.isDefaultPrevented()&&(!k._default||k._default.apply(o.pop(),c)===!1)&&m.acceptData(d)&&g&&d[p]&&!m.isWindow(d)){l=d[g],l&&(d[g]=null),m.event.triggered=p;
try{d[p]()
}catch(r){}m.event.triggered=void 0,l&&(d[g]=l)
}return b.result
}},dispatch:function(a){a=m.event.fix(a);
var b,c,e,f,g,h=[],i=d.call(arguments),j=(m._data(this,"events")||{})[a.type]||[],k=m.event.special[a.type]||{};
if(i[0]=a,a.delegateTarget=this,!k.preDispatch||k.preDispatch.call(this,a)!==!1){h=m.event.handlers.call(this,a,j),b=0;
while((f=h[b++])&&!a.isPropagationStopped()){a.currentTarget=f.elem,g=0;
while((e=f.handlers[g++])&&!a.isImmediatePropagationStopped()){(!a.namespace_re||a.namespace_re.test(e.namespace))&&(a.handleObj=e,a.data=e.data,c=((m.event.special[e.origType]||{}).handle||e.handler).apply(f.elem,i),void 0!==c&&(a.result=c)===!1&&(a.preventDefault(),a.stopPropagation()))
}}return k.postDispatch&&k.postDispatch.call(this,a),a.result
}},handlers:function(a,b){var c,d,e,f,g=[],h=b.delegateCount,i=a.target;
if(h&&i.nodeType&&(!a.button||"click"!==a.type)){for(;
i!=this;
i=i.parentNode||this){if(1===i.nodeType&&(i.disabled!==!0||"click"!==a.type)){for(e=[],f=0;
h>f;
f++){d=b[f],c=d.selector+" ",void 0===e[c]&&(e[c]=d.needsContext?m(c,this).index(i)>=0:m.find(c,this,null,[i]).length),e[c]&&e.push(d)
}e.length&&g.push({elem:i,handlers:e})
}}}return h<b.length&&g.push({elem:this,handlers:b.slice(h)}),g
},fix:function(a){if(a[m.expando]){return a
}var b,c,d,e=a.type,f=a,g=this.fixHooks[e];
g||(this.fixHooks[e]=g=Z.test(e)?this.mouseHooks:Y.test(e)?this.keyHooks:{}),d=g.props?this.props.concat(g.props):this.props,a=new m.Event(f),b=d.length;
while(b--){c=d[b],a[c]=f[c]
}return a.target||(a.target=f.srcElement||y),3===a.target.nodeType&&(a.target=a.target.parentNode),a.metaKey=!!a.metaKey,g.filter?g.filter(a,f):a
},props:"altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),fixHooks:{},keyHooks:{props:"char charCode key keyCode".split(" "),filter:function(a,b){return null==a.which&&(a.which=null!=b.charCode?b.charCode:b.keyCode),a
}},mouseHooks:{props:"button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),filter:function(a,b){var c,d,e,f=b.button,g=b.fromElement;
return null==a.pageX&&null!=b.clientX&&(d=a.target.ownerDocument||y,e=d.documentElement,c=d.body,a.pageX=b.clientX+(e&&e.scrollLeft||c&&c.scrollLeft||0)-(e&&e.clientLeft||c&&c.clientLeft||0),a.pageY=b.clientY+(e&&e.scrollTop||c&&c.scrollTop||0)-(e&&e.clientTop||c&&c.clientTop||0)),!a.relatedTarget&&g&&(a.relatedTarget=g===a.target?b.toElement:g),a.which||void 0===f||(a.which=1&f?1:2&f?3:4&f?2:0),a
}},special:{load:{noBubble:!0},focus:{trigger:function(){if(this!==cb()&&this.focus){try{return this.focus(),!1
}catch(a){}}},delegateType:"focusin"},blur:{trigger:function(){return this===cb()&&this.blur?(this.blur(),!1):void 0
},delegateType:"focusout"},click:{trigger:function(){return m.nodeName(this,"input")&&"checkbox"===this.type&&this.click?(this.click(),!1):void 0
},_default:function(a){return m.nodeName(a.target,"a")
}},beforeunload:{postDispatch:function(a){void 0!==a.result&&a.originalEvent&&(a.originalEvent.returnValue=a.result)
}}},simulate:function(a,b,c,d){var e=m.extend(new m.Event,c,{type:a,isSimulated:!0,originalEvent:{}});
d?m.event.trigger(e,null,b):m.event.dispatch.call(b,e),e.isDefaultPrevented()&&c.preventDefault()
}},m.removeEvent=y.removeEventListener?function(a,b,c){a.removeEventListener&&a.removeEventListener(b,c,!1)
}:function(a,b,c){var d="on"+b;
a.detachEvent&&(typeof a[d]===K&&(a[d]=null),a.detachEvent(d,c))
},m.Event=function(a,b){return this instanceof m.Event?(a&&a.type?(this.originalEvent=a,this.type=a.type,this.isDefaultPrevented=a.defaultPrevented||void 0===a.defaultPrevented&&a.returnValue===!1?ab:bb):this.type=a,b&&m.extend(this,b),this.timeStamp=a&&a.timeStamp||m.now(),void (this[m.expando]=!0)):new m.Event(a,b)
},m.Event.prototype={isDefaultPrevented:bb,isPropagationStopped:bb,isImmediatePropagationStopped:bb,preventDefault:function(){var a=this.originalEvent;
this.isDefaultPrevented=ab,a&&(a.preventDefault?a.preventDefault():a.returnValue=!1)
},stopPropagation:function(){var a=this.originalEvent;
this.isPropagationStopped=ab,a&&(a.stopPropagation&&a.stopPropagation(),a.cancelBubble=!0)
},stopImmediatePropagation:function(){var a=this.originalEvent;
this.isImmediatePropagationStopped=ab,a&&a.stopImmediatePropagation&&a.stopImmediatePropagation(),this.stopPropagation()
}},m.each({mouseenter:"mouseover",mouseleave:"mouseout",pointerenter:"pointerover",pointerleave:"pointerout"},function(a,b){m.event.special[a]={delegateType:b,bindType:b,handle:function(a){var c,d=this,e=a.relatedTarget,f=a.handleObj;
return(!e||e!==d&&!m.contains(d,e))&&(a.type=f.origType,c=f.handler.apply(this,arguments),a.type=b),c
}}
}),k.submitBubbles||(m.event.special.submit={setup:function(){return m.nodeName(this,"form")?!1:void m.event.add(this,"click._submit keypress._submit",function(a){var b=a.target,c=m.nodeName(b,"input")||m.nodeName(b,"button")?b.form:void 0;
c&&!m._data(c,"submitBubbles")&&(m.event.add(c,"submit._submit",function(a){a._submit_bubble=!0
}),m._data(c,"submitBubbles",!0))
})
},postDispatch:function(a){a._submit_bubble&&(delete a._submit_bubble,this.parentNode&&!a.isTrigger&&m.event.simulate("submit",this.parentNode,a,!0))
},teardown:function(){return m.nodeName(this,"form")?!1:void m.event.remove(this,"._submit")
}}),k.changeBubbles||(m.event.special.change={setup:function(){return X.test(this.nodeName)?(("checkbox"===this.type||"radio"===this.type)&&(m.event.add(this,"propertychange._change",function(a){"checked"===a.originalEvent.propertyName&&(this._just_changed=!0)
}),m.event.add(this,"click._change",function(a){this._just_changed&&!a.isTrigger&&(this._just_changed=!1),m.event.simulate("change",this,a,!0)
})),!1):void m.event.add(this,"beforeactivate._change",function(a){var b=a.target;
X.test(b.nodeName)&&!m._data(b,"changeBubbles")&&(m.event.add(b,"change._change",function(a){!this.parentNode||a.isSimulated||a.isTrigger||m.event.simulate("change",this.parentNode,a,!0)
}),m._data(b,"changeBubbles",!0))
})
},handle:function(a){var b=a.target;
return this!==b||a.isSimulated||a.isTrigger||"radio"!==b.type&&"checkbox"!==b.type?a.handleObj.handler.apply(this,arguments):void 0
},teardown:function(){return m.event.remove(this,"._change"),!X.test(this.nodeName)
}}),k.focusinBubbles||m.each({focus:"focusin",blur:"focusout"},function(a,b){var c=function(a){m.event.simulate(b,a.target,m.event.fix(a),!0)
};
m.event.special[b]={setup:function(){var d=this.ownerDocument||this,e=m._data(d,b);
e||d.addEventListener(a,c,!0),m._data(d,b,(e||0)+1)
},teardown:function(){var d=this.ownerDocument||this,e=m._data(d,b)-1;
e?m._data(d,b,e):(d.removeEventListener(a,c,!0),m._removeData(d,b))
}}
}),m.fn.extend({on:function(a,b,c,d,e){var f,g;
if("object"==typeof a){"string"!=typeof b&&(c=c||b,b=void 0);
for(f in a){this.on(f,b,c,a[f],e)
}return this
}if(null==c&&null==d?(d=b,c=b=void 0):null==d&&("string"==typeof b?(d=c,c=void 0):(d=c,c=b,b=void 0)),d===!1){d=bb
}else{if(!d){return this
}}return 1===e&&(g=d,d=function(a){return m().off(a),g.apply(this,arguments)
},d.guid=g.guid||(g.guid=m.guid++)),this.each(function(){m.event.add(this,a,d,c,b)
})
},one:function(a,b,c,d){return this.on(a,b,c,d,1)
},off:function(a,b,c){var d,e;
if(a&&a.preventDefault&&a.handleObj){return d=a.handleObj,m(a.delegateTarget).off(d.namespace?d.origType+"."+d.namespace:d.origType,d.selector,d.handler),this
}if("object"==typeof a){for(e in a){this.off(e,b,a[e])
}return this
}return(b===!1||"function"==typeof b)&&(c=b,b=void 0),c===!1&&(c=bb),this.each(function(){m.event.remove(this,a,c,b)
})
},trigger:function(a,b){return this.each(function(){m.event.trigger(a,b,this)
})
},triggerHandler:function(a,b){var c=this[0];
return c?m.event.trigger(a,b,c,!0):void 0
}});
function db(a){var b=eb.split("|"),c=a.createDocumentFragment();
if(c.createElement){while(b.length){c.createElement(b.pop())
}}return c
}var eb="abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",fb=/ jQuery\d+="(?:null|\d+)"/g,gb=new RegExp("<(?:"+eb+")[\\s/>]","i"),hb=/^\s+/,ib=/<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,jb=/<([\w:]+)/,kb=/<tbody/i,lb=/<|&#?\w+;/,mb=/<(?:script|style|link)/i,nb=/checked\s*(?:[^=]|=\s*.checked.)/i,ob=/^$|\/(?:java|ecma)script/i,pb=/^true\/(.*)/,qb=/^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,rb={option:[1,"<select multiple='multiple'>","</select>"],legend:[1,"<fieldset>","</fieldset>"],area:[1,"<map>","</map>"],param:[1,"<object>","</object>"],thead:[1,"<table>","</table>"],tr:[2,"<table><tbody>","</tbody></table>"],col:[2,"<table><tbody></tbody><colgroup>","</colgroup></table>"],td:[3,"<table><tbody><tr>","</tr></tbody></table>"],_default:k.htmlSerialize?[0,"",""]:[1,"X<div>","</div>"]},sb=db(y),tb=sb.appendChild(y.createElement("div"));
rb.optgroup=rb.option,rb.tbody=rb.tfoot=rb.colgroup=rb.caption=rb.thead,rb.th=rb.td;
function ub(a,b){var c,d,e=0,f=typeof a.getElementsByTagName!==K?a.getElementsByTagName(b||"*"):typeof a.querySelectorAll!==K?a.querySelectorAll(b||"*"):void 0;
if(!f){for(f=[],c=a.childNodes||a;
null!=(d=c[e]);
e++){!b||m.nodeName(d,b)?f.push(d):m.merge(f,ub(d,b))
}}return void 0===b||b&&m.nodeName(a,b)?m.merge([a],f):f
}function vb(a){W.test(a.type)&&(a.defaultChecked=a.checked)
}function wb(a,b){return m.nodeName(a,"table")&&m.nodeName(11!==b.nodeType?b:b.firstChild,"tr")?a.getElementsByTagName("tbody")[0]||a.appendChild(a.ownerDocument.createElement("tbody")):a
}function xb(a){return a.type=(null!==m.find.attr(a,"type"))+"/"+a.type,a
}function yb(a){var b=pb.exec(a.type);
return b?a.type=b[1]:a.removeAttribute("type"),a
}function zb(a,b){for(var c,d=0;
null!=(c=a[d]);
d++){m._data(c,"globalEval",!b||m._data(b[d],"globalEval"))
}}function Ab(a,b){if(1===b.nodeType&&m.hasData(a)){var c,d,e,f=m._data(a),g=m._data(b,f),h=f.events;
if(h){delete g.handle,g.events={};
for(c in h){for(d=0,e=h[c].length;
e>d;
d++){m.event.add(b,c,h[c][d])
}}}g.data&&(g.data=m.extend({},g.data))
}}function Bb(a,b){var c,d,e;
if(1===b.nodeType){if(c=b.nodeName.toLowerCase(),!k.noCloneEvent&&b[m.expando]){e=m._data(b);
for(d in e.events){m.removeEvent(b,d,e.handle)
}b.removeAttribute(m.expando)
}"script"===c&&b.text!==a.text?(xb(b).text=a.text,yb(b)):"object"===c?(b.parentNode&&(b.outerHTML=a.outerHTML),k.html5Clone&&a.innerHTML&&!m.trim(b.innerHTML)&&(b.innerHTML=a.innerHTML)):"input"===c&&W.test(a.type)?(b.defaultChecked=b.checked=a.checked,b.value!==a.value&&(b.value=a.value)):"option"===c?b.defaultSelected=b.selected=a.defaultSelected:("input"===c||"textarea"===c)&&(b.defaultValue=a.defaultValue)
}}m.extend({clone:function(a,b,c){var d,e,f,g,h,i=m.contains(a.ownerDocument,a);
if(k.html5Clone||m.isXMLDoc(a)||!gb.test("<"+a.nodeName+">")?f=a.cloneNode(!0):(tb.innerHTML=a.outerHTML,tb.removeChild(f=tb.firstChild)),!(k.noCloneEvent&&k.noCloneChecked||1!==a.nodeType&&11!==a.nodeType||m.isXMLDoc(a))){for(d=ub(f),h=ub(a),g=0;
null!=(e=h[g]);
++g){d[g]&&Bb(e,d[g])
}}if(b){if(c){for(h=h||ub(a),d=d||ub(f),g=0;
null!=(e=h[g]);
g++){Ab(e,d[g])
}}else{Ab(a,f)
}}return d=ub(f,"script"),d.length>0&&zb(d,!i&&ub(a,"script")),d=h=e=null,f
},buildFragment:function(a,b,c,d){for(var e,f,g,h,i,j,l,n=a.length,o=db(b),p=[],q=0;
n>q;
q++){if(f=a[q],f||0===f){if("object"===m.type(f)){m.merge(p,f.nodeType?[f]:f)
}else{if(lb.test(f)){h=h||o.appendChild(b.createElement("div")),i=(jb.exec(f)||["",""])[1].toLowerCase(),l=rb[i]||rb._default,h.innerHTML=l[1]+f.replace(ib,"<$1></$2>")+l[2],e=l[0];
while(e--){h=h.lastChild
}if(!k.leadingWhitespace&&hb.test(f)&&p.push(b.createTextNode(hb.exec(f)[0])),!k.tbody){f="table"!==i||kb.test(f)?"<table>"!==l[1]||kb.test(f)?0:h:h.firstChild,e=f&&f.childNodes.length;
while(e--){m.nodeName(j=f.childNodes[e],"tbody")&&!j.childNodes.length&&f.removeChild(j)
}}m.merge(p,h.childNodes),h.textContent="";
while(h.firstChild){h.removeChild(h.firstChild)
}h=o.lastChild
}else{p.push(b.createTextNode(f))
}}}}h&&o.removeChild(h),k.appendChecked||m.grep(ub(p,"input"),vb),q=0;
while(f=p[q++]){if((!d||-1===m.inArray(f,d))&&(g=m.contains(f.ownerDocument,f),h=ub(o.appendChild(f),"script"),g&&zb(h),c)){e=0;
while(f=h[e++]){ob.test(f.type||"")&&c.push(f)
}}}return h=null,o
},cleanData:function(a,b){for(var d,e,f,g,h=0,i=m.expando,j=m.cache,l=k.deleteExpando,n=m.event.special;
null!=(d=a[h]);
h++){if((b||m.acceptData(d))&&(f=d[i],g=f&&j[f])){if(g.events){for(e in g.events){n[e]?m.event.remove(d,e):m.removeEvent(d,e,g.handle)
}}j[f]&&(delete j[f],l?delete d[i]:typeof d.removeAttribute!==K?d.removeAttribute(i):d[i]=null,c.push(f))
}}}}),m.fn.extend({text:function(a){return V(this,function(a){return void 0===a?m.text(this):this.empty().append((this[0]&&this[0].ownerDocument||y).createTextNode(a))
},null,a,arguments.length)
},append:function(){return this.domManip(arguments,function(a){if(1===this.nodeType||11===this.nodeType||9===this.nodeType){var b=wb(this,a);
b.appendChild(a)
}})
},prepend:function(){return this.domManip(arguments,function(a){if(1===this.nodeType||11===this.nodeType||9===this.nodeType){var b=wb(this,a);
b.insertBefore(a,b.firstChild)
}})
},before:function(){return this.domManip(arguments,function(a){this.parentNode&&this.parentNode.insertBefore(a,this)
})
},after:function(){return this.domManip(arguments,function(a){this.parentNode&&this.parentNode.insertBefore(a,this.nextSibling)
})
},remove:function(a,b){for(var c,d=a?m.filter(a,this):this,e=0;
null!=(c=d[e]);
e++){b||1!==c.nodeType||m.cleanData(ub(c)),c.parentNode&&(b&&m.contains(c.ownerDocument,c)&&zb(ub(c,"script")),c.parentNode.removeChild(c))
}return this
},empty:function(){for(var a,b=0;
null!=(a=this[b]);
b++){1===a.nodeType&&m.cleanData(ub(a,!1));
while(a.firstChild){a.removeChild(a.firstChild)
}a.options&&m.nodeName(a,"select")&&(a.options.length=0)
}return this
},clone:function(a,b){return a=null==a?!1:a,b=null==b?a:b,this.map(function(){return m.clone(this,a,b)
})
},html:function(a){return V(this,function(a){var b=this[0]||{},c=0,d=this.length;
if(void 0===a){return 1===b.nodeType?b.innerHTML.replace(fb,""):void 0
}if(!("string"!=typeof a||mb.test(a)||!k.htmlSerialize&&gb.test(a)||!k.leadingWhitespace&&hb.test(a)||rb[(jb.exec(a)||["",""])[1].toLowerCase()])){a=a.replace(ib,"<$1></$2>");
try{for(;
d>c;
c++){b=this[c]||{},1===b.nodeType&&(m.cleanData(ub(b,!1)),b.innerHTML=a)
}b=0
}catch(e){}}b&&this.empty().append(a)
},null,a,arguments.length)
},replaceWith:function(){var a=arguments[0];
return this.domManip(arguments,function(b){a=this.parentNode,m.cleanData(ub(this)),a&&a.replaceChild(b,this)
}),a&&(a.length||a.nodeType)?this:this.remove()
},detach:function(a){return this.remove(a,!0)
},domManip:function(a,b){a=e.apply([],a);
var c,d,f,g,h,i,j=0,l=this.length,n=this,o=l-1,p=a[0],q=m.isFunction(p);
if(q||l>1&&"string"==typeof p&&!k.checkClone&&nb.test(p)){return this.each(function(c){var d=n.eq(c);
q&&(a[0]=p.call(this,c,d.html())),d.domManip(a,b)
})
}if(l&&(i=m.buildFragment(a,this[0].ownerDocument,!1,this),c=i.firstChild,1===i.childNodes.length&&(i=c),c)){for(g=m.map(ub(i,"script"),xb),f=g.length;
l>j;
j++){d=i,j!==o&&(d=m.clone(d,!0,!0),f&&m.merge(g,ub(d,"script"))),b.call(this[j],d,j)
}if(f){for(h=g[g.length-1].ownerDocument,m.map(g,yb),j=0;
f>j;
j++){d=g[j],ob.test(d.type||"")&&!m._data(d,"globalEval")&&m.contains(h,d)&&(d.src?m._evalUrl&&m._evalUrl(d.src):m.globalEval((d.text||d.textContent||d.innerHTML||"").replace(qb,"")))
}}i=c=null
}return this
}}),m.each({appendTo:"append",prependTo:"prepend",insertBefore:"before",insertAfter:"after",replaceAll:"replaceWith"},function(a,b){m.fn[a]=function(a){for(var c,d=0,e=[],g=m(a),h=g.length-1;
h>=d;
d++){c=d===h?this:this.clone(!0),m(g[d])[b](c),f.apply(e,c.get())
}return this.pushStack(e)
}
});
var Cb,Db={};
function Eb(b,c){var d,e=m(c.createElement(b)).appendTo(c.body),f=a.getDefaultComputedStyle&&(d=a.getDefaultComputedStyle(e[0]))?d.display:m.css(e[0],"display");
return e.detach(),f
}function Fb(a){var b=y,c=Db[a];
return c||(c=Eb(a,b),"none"!==c&&c||(Cb=(Cb||m("<iframe frameborder='0' width='0' height='0'/>")).appendTo(b.documentElement),b=(Cb[0].contentWindow||Cb[0].contentDocument).document,b.write(),b.close(),c=Eb(a,b),Cb.detach()),Db[a]=c),c
}!function(){var a;
k.shrinkWrapBlocks=function(){if(null!=a){return a
}a=!1;
var b,c,d;
return c=y.getElementsByTagName("body")[0],c&&c.style?(b=y.createElement("div"),d=y.createElement("div"),d.style.cssText="position:absolute;border:0;width:0;height:0;top:0;left:-9999px",c.appendChild(d).appendChild(b),typeof b.style.zoom!==K&&(b.style.cssText="-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:1px;width:1px;zoom:1",b.appendChild(y.createElement("div")).style.width="5px",a=3!==b.offsetWidth),c.removeChild(d),a):void 0
}
}();
var Gb=/^margin/,Hb=new RegExp("^("+S+")(?!px)[a-z%]+$","i"),Ib,Jb,Kb=/^(top|right|bottom|left)$/;
a.getComputedStyle?(Ib=function(b){return b.ownerDocument.defaultView.opener?b.ownerDocument.defaultView.getComputedStyle(b,null):a.getComputedStyle(b,null)
},Jb=function(a,b,c){var d,e,f,g,h=a.style;
return c=c||Ib(a),g=c?c.getPropertyValue(b)||c[b]:void 0,c&&(""!==g||m.contains(a.ownerDocument,a)||(g=m.style(a,b)),Hb.test(g)&&Gb.test(b)&&(d=h.width,e=h.minWidth,f=h.maxWidth,h.minWidth=h.maxWidth=h.width=g,g=c.width,h.width=d,h.minWidth=e,h.maxWidth=f)),void 0===g?g:g+""
}):y.documentElement.currentStyle&&(Ib=function(a){return a.currentStyle
},Jb=function(a,b,c){var d,e,f,g,h=a.style;
return c=c||Ib(a),g=c?c[b]:void 0,null==g&&h&&h[b]&&(g=h[b]),Hb.test(g)&&!Kb.test(b)&&(d=h.left,e=a.runtimeStyle,f=e&&e.left,f&&(e.left=a.currentStyle.left),h.left="fontSize"===b?"1em":g,g=h.pixelLeft+"px",h.left=d,f&&(e.left=f)),void 0===g?g:g+""||"auto"
});
function Lb(a,b){return{get:function(){var c=a();
if(null!=c){return c?void delete this.get:(this.get=b).apply(this,arguments)
}}}
}!function(){var b,c,d,e,f,g,h;
if(b=y.createElement("div"),b.innerHTML="  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",d=b.getElementsByTagName("a")[0],c=d&&d.style){c.cssText="float:left;opacity:.5",k.opacity="0.5"===c.opacity,k.cssFloat=!!c.cssFloat,b.style.backgroundClip="content-box",b.cloneNode(!0).style.backgroundClip="",k.clearCloneStyle="content-box"===b.style.backgroundClip,k.boxSizing=""===c.boxSizing||""===c.MozBoxSizing||""===c.WebkitBoxSizing,m.extend(k,{reliableHiddenOffsets:function(){return null==g&&i(),g
},boxSizingReliable:function(){return null==f&&i(),f
},pixelPosition:function(){return null==e&&i(),e
},reliableMarginRight:function(){return null==h&&i(),h
}});
function i(){var b,c,d,i;
c=y.getElementsByTagName("body")[0],c&&c.style&&(b=y.createElement("div"),d=y.createElement("div"),d.style.cssText="position:absolute;border:0;width:0;height:0;top:0;left:-9999px",c.appendChild(d).appendChild(b),b.style.cssText="-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;display:block;margin-top:1%;top:1%;border:1px;padding:1px;width:4px;position:absolute",e=f=!1,h=!0,a.getComputedStyle&&(e="1%"!==(a.getComputedStyle(b,null)||{}).top,f="4px"===(a.getComputedStyle(b,null)||{width:"4px"}).width,i=b.appendChild(y.createElement("div")),i.style.cssText=b.style.cssText="-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:0",i.style.marginRight=i.style.width="0",b.style.width="1px",h=!parseFloat((a.getComputedStyle(i,null)||{}).marginRight),b.removeChild(i)),b.innerHTML="<table><tr><td></td><td>t</td></tr></table>",i=b.getElementsByTagName("td"),i[0].style.cssText="margin:0;border:0;padding:0;display:none",g=0===i[0].offsetHeight,g&&(i[0].style.display="",i[1].style.display="none",g=0===i[0].offsetHeight),c.removeChild(d))
}}}(),m.swap=function(a,b,c,d){var e,f,g={};
for(f in b){g[f]=a.style[f],a.style[f]=b[f]
}e=c.apply(a,d||[]);
for(f in b){a.style[f]=g[f]
}return e
};
var Mb=/alpha\([^)]*\)/i,Nb=/opacity\s*=\s*([^)]*)/,Ob=/^(none|table(?!-c[ea]).+)/,Pb=new RegExp("^("+S+")(.*)$","i"),Qb=new RegExp("^([+-])=("+S+")","i"),Rb={position:"absolute",visibility:"hidden",display:"block"},Sb={letterSpacing:"0",fontWeight:"400"},Tb=["Webkit","O","Moz","ms"];
function Ub(a,b){if(b in a){return b
}var c=b.charAt(0).toUpperCase()+b.slice(1),d=b,e=Tb.length;
while(e--){if(b=Tb[e]+c,b in a){return b
}}return d
}function Vb(a,b){for(var c,d,e,f=[],g=0,h=a.length;
h>g;
g++){d=a[g],d.style&&(f[g]=m._data(d,"olddisplay"),c=d.style.display,b?(f[g]||"none"!==c||(d.style.display=""),""===d.style.display&&U(d)&&(f[g]=m._data(d,"olddisplay",Fb(d.nodeName)))):(e=U(d),(c&&"none"!==c||!e)&&m._data(d,"olddisplay",e?c:m.css(d,"display"))))
}for(g=0;
h>g;
g++){d=a[g],d.style&&(b&&"none"!==d.style.display&&""!==d.style.display||(d.style.display=b?f[g]||"":"none"))
}return a
}function Wb(a,b,c){var d=Pb.exec(b);
return d?Math.max(0,d[1]-(c||0))+(d[2]||"px"):b
}function Xb(a,b,c,d,e){for(var f=c===(d?"border":"content")?4:"width"===b?1:0,g=0;
4>f;
f+=2){"margin"===c&&(g+=m.css(a,c+T[f],!0,e)),d?("content"===c&&(g-=m.css(a,"padding"+T[f],!0,e)),"margin"!==c&&(g-=m.css(a,"border"+T[f]+"Width",!0,e))):(g+=m.css(a,"padding"+T[f],!0,e),"padding"!==c&&(g+=m.css(a,"border"+T[f]+"Width",!0,e)))
}return g
}function Yb(a,b,c){var d=!0,e="width"===b?a.offsetWidth:a.offsetHeight,f=Ib(a),g=k.boxSizing&&"border-box"===m.css(a,"boxSizing",!1,f);
if(0>=e||null==e){if(e=Jb(a,b,f),(0>e||null==e)&&(e=a.style[b]),Hb.test(e)){return e
}d=g&&(k.boxSizingReliable()||e===a.style[b]),e=parseFloat(e)||0
}return e+Xb(a,b,c||(g?"border":"content"),d,f)+"px"
}m.extend({cssHooks:{opacity:{get:function(a,b){if(b){var c=Jb(a,"opacity");
return""===c?"1":c
}}}},cssNumber:{columnCount:!0,fillOpacity:!0,flexGrow:!0,flexShrink:!0,fontWeight:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,widows:!0,zIndex:!0,zoom:!0},cssProps:{"float":k.cssFloat?"cssFloat":"styleFloat"},style:function(a,b,c,d){if(a&&3!==a.nodeType&&8!==a.nodeType&&a.style){var e,f,g,h=m.camelCase(b),i=a.style;
if(b=m.cssProps[h]||(m.cssProps[h]=Ub(i,h)),g=m.cssHooks[b]||m.cssHooks[h],void 0===c){return g&&"get" in g&&void 0!==(e=g.get(a,!1,d))?e:i[b]
}if(f=typeof c,"string"===f&&(e=Qb.exec(c))&&(c=(e[1]+1)*e[2]+parseFloat(m.css(a,b)),f="number"),null!=c&&c===c&&("number"!==f||m.cssNumber[h]||(c+="px"),k.clearCloneStyle||""!==c||0!==b.indexOf("background")||(i[b]="inherit"),!(g&&"set" in g&&void 0===(c=g.set(a,c,d))))){try{i[b]=c
}catch(j){}}}},css:function(a,b,c,d){var e,f,g,h=m.camelCase(b);
return b=m.cssProps[h]||(m.cssProps[h]=Ub(a.style,h)),g=m.cssHooks[b]||m.cssHooks[h],g&&"get" in g&&(f=g.get(a,!0,c)),void 0===f&&(f=Jb(a,b,d)),"normal"===f&&b in Sb&&(f=Sb[b]),""===c||c?(e=parseFloat(f),c===!0||m.isNumeric(e)?e||0:f):f
}}),m.each(["height","width"],function(a,b){m.cssHooks[b]={get:function(a,c,d){return c?Ob.test(m.css(a,"display"))&&0===a.offsetWidth?m.swap(a,Rb,function(){return Yb(a,b,d)
}):Yb(a,b,d):void 0
},set:function(a,c,d){var e=d&&Ib(a);
return Wb(a,c,d?Xb(a,b,d,k.boxSizing&&"border-box"===m.css(a,"boxSizing",!1,e),e):0)
}}
}),k.opacity||(m.cssHooks.opacity={get:function(a,b){return Nb.test((b&&a.currentStyle?a.currentStyle.filter:a.style.filter)||"")?0.01*parseFloat(RegExp.$1)+"":b?"1":""
},set:function(a,b){var c=a.style,d=a.currentStyle,e=m.isNumeric(b)?"alpha(opacity="+100*b+")":"",f=d&&d.filter||c.filter||"";
c.zoom=1,(b>=1||""===b)&&""===m.trim(f.replace(Mb,""))&&c.removeAttribute&&(c.removeAttribute("filter"),""===b||d&&!d.filter)||(c.filter=Mb.test(f)?f.replace(Mb,e):f+" "+e)
}}),m.cssHooks.marginRight=Lb(k.reliableMarginRight,function(a,b){return b?m.swap(a,{display:"inline-block"},Jb,[a,"marginRight"]):void 0
}),m.each({margin:"",padding:"",border:"Width"},function(a,b){m.cssHooks[a+b]={expand:function(c){for(var d=0,e={},f="string"==typeof c?c.split(" "):[c];
4>d;
d++){e[a+T[d]+b]=f[d]||f[d-2]||f[0]
}return e
}},Gb.test(a)||(m.cssHooks[a+b].set=Wb)
}),m.fn.extend({css:function(a,b){return V(this,function(a,b,c){var d,e,f={},g=0;
if(m.isArray(b)){for(d=Ib(a),e=b.length;
e>g;
g++){f[b[g]]=m.css(a,b[g],!1,d)
}return f
}return void 0!==c?m.style(a,b,c):m.css(a,b)
},a,b,arguments.length>1)
},show:function(){return Vb(this,!0)
},hide:function(){return Vb(this)
},toggle:function(a){return"boolean"==typeof a?a?this.show():this.hide():this.each(function(){U(this)?m(this).show():m(this).hide()
})
}});
function Zb(a,b,c,d,e){return new Zb.prototype.init(a,b,c,d,e)
}m.Tween=Zb,Zb.prototype={constructor:Zb,init:function(a,b,c,d,e,f){this.elem=a,this.prop=c,this.easing=e||"swing",this.options=b,this.start=this.now=this.cur(),this.end=d,this.unit=f||(m.cssNumber[c]?"":"px")
},cur:function(){var a=Zb.propHooks[this.prop];
return a&&a.get?a.get(this):Zb.propHooks._default.get(this)
},run:function(a){var b,c=Zb.propHooks[this.prop];
return this.pos=b=this.options.duration?m.easing[this.easing](a,this.options.duration*a,0,1,this.options.duration):a,this.now=(this.end-this.start)*b+this.start,this.options.step&&this.options.step.call(this.elem,this.now,this),c&&c.set?c.set(this):Zb.propHooks._default.set(this),this
}},Zb.prototype.init.prototype=Zb.prototype,Zb.propHooks={_default:{get:function(a){var b;
return null==a.elem[a.prop]||a.elem.style&&null!=a.elem.style[a.prop]?(b=m.css(a.elem,a.prop,""),b&&"auto"!==b?b:0):a.elem[a.prop]
},set:function(a){m.fx.step[a.prop]?m.fx.step[a.prop](a):a.elem.style&&(null!=a.elem.style[m.cssProps[a.prop]]||m.cssHooks[a.prop])?m.style(a.elem,a.prop,a.now+a.unit):a.elem[a.prop]=a.now
}}},Zb.propHooks.scrollTop=Zb.propHooks.scrollLeft={set:function(a){a.elem.nodeType&&a.elem.parentNode&&(a.elem[a.prop]=a.now)
}},m.easing={linear:function(a){return a
},swing:function(a){return 0.5-Math.cos(a*Math.PI)/2
}},m.fx=Zb.prototype.init,m.fx.step={};
var $b,_b,ac=/^(?:toggle|show|hide)$/,bc=new RegExp("^(?:([+-])=|)("+S+")([a-z%]*)$","i"),cc=/queueHooks$/,dc=[ic],ec={"*":[function(a,b){var c=this.createTween(a,b),d=c.cur(),e=bc.exec(b),f=e&&e[3]||(m.cssNumber[a]?"":"px"),g=(m.cssNumber[a]||"px"!==f&&+d)&&bc.exec(m.css(c.elem,a)),h=1,i=20;
if(g&&g[3]!==f){f=f||g[3],e=e||[],g=+d||1;
do{h=h||".5",g/=h,m.style(c.elem,a,g+f)
}while(h!==(h=c.cur()/d)&&1!==h&&--i)
}return e&&(g=c.start=+g||+d||0,c.unit=f,c.end=e[1]?g+(e[1]+1)*e[2]:+e[2]),c
}]};
function fc(){return setTimeout(function(){$b=void 0
}),$b=m.now()
}function gc(a,b){var c,d={height:a},e=0;
for(b=b?1:0;
4>e;
e+=2-b){c=T[e],d["margin"+c]=d["padding"+c]=a
}return b&&(d.opacity=d.width=a),d
}function hc(a,b,c){for(var d,e=(ec[b]||[]).concat(ec["*"]),f=0,g=e.length;
g>f;
f++){if(d=e[f].call(c,b,a)){return d
}}}function ic(a,b,c){var d,e,f,g,h,i,j,l,n=this,o={},p=a.style,q=a.nodeType&&U(a),r=m._data(a,"fxshow");
c.queue||(h=m._queueHooks(a,"fx"),null==h.unqueued&&(h.unqueued=0,i=h.empty.fire,h.empty.fire=function(){h.unqueued||i()
}),h.unqueued++,n.always(function(){n.always(function(){h.unqueued--,m.queue(a,"fx").length||h.empty.fire()
})
})),1===a.nodeType&&("height" in b||"width" in b)&&(c.overflow=[p.overflow,p.overflowX,p.overflowY],j=m.css(a,"display"),l="none"===j?m._data(a,"olddisplay")||Fb(a.nodeName):j,"inline"===l&&"none"===m.css(a,"float")&&(k.inlineBlockNeedsLayout&&"inline"!==Fb(a.nodeName)?p.zoom=1:p.display="inline-block")),c.overflow&&(p.overflow="hidden",k.shrinkWrapBlocks()||n.always(function(){p.overflow=c.overflow[0],p.overflowX=c.overflow[1],p.overflowY=c.overflow[2]
}));
for(d in b){if(e=b[d],ac.exec(e)){if(delete b[d],f=f||"toggle"===e,e===(q?"hide":"show")){if("show"!==e||!r||void 0===r[d]){continue
}q=!0
}o[d]=r&&r[d]||m.style(a,d)
}else{j=void 0
}}if(m.isEmptyObject(o)){"inline"===("none"===j?Fb(a.nodeName):j)&&(p.display=j)
}else{r?"hidden" in r&&(q=r.hidden):r=m._data(a,"fxshow",{}),f&&(r.hidden=!q),q?m(a).show():n.done(function(){m(a).hide()
}),n.done(function(){var b;
m._removeData(a,"fxshow");
for(b in o){m.style(a,b,o[b])
}});
for(d in o){g=hc(q?r[d]:0,d,n),d in r||(r[d]=g.start,q&&(g.end=g.start,g.start="width"===d||"height"===d?1:0))
}}}function jc(a,b){var c,d,e,f,g;
for(c in a){if(d=m.camelCase(c),e=b[d],f=a[c],m.isArray(f)&&(e=f[1],f=a[c]=f[0]),c!==d&&(a[d]=f,delete a[c]),g=m.cssHooks[d],g&&"expand" in g){f=g.expand(f),delete a[d];
for(c in f){c in a||(a[c]=f[c],b[c]=e)
}}else{b[d]=e
}}}function kc(a,b,c){var d,e,f=0,g=dc.length,h=m.Deferred().always(function(){delete i.elem
}),i=function(){if(e){return !1
}for(var b=$b||fc(),c=Math.max(0,j.startTime+j.duration-b),d=c/j.duration||0,f=1-d,g=0,i=j.tweens.length;
i>g;
g++){j.tweens[g].run(f)
}return h.notifyWith(a,[j,f,c]),1>f&&i?c:(h.resolveWith(a,[j]),!1)
},j=h.promise({elem:a,props:m.extend({},b),opts:m.extend(!0,{specialEasing:{}},c),originalProperties:b,originalOptions:c,startTime:$b||fc(),duration:c.duration,tweens:[],createTween:function(b,c){var d=m.Tween(a,j.opts,b,c,j.opts.specialEasing[b]||j.opts.easing);
return j.tweens.push(d),d
},stop:function(b){var c=0,d=b?j.tweens.length:0;
if(e){return this
}for(e=!0;
d>c;
c++){j.tweens[c].run(1)
}return b?h.resolveWith(a,[j,b]):h.rejectWith(a,[j,b]),this
}}),k=j.props;
for(jc(k,j.opts.specialEasing);
g>f;
f++){if(d=dc[f].call(j,a,k,j.opts)){return d
}}return m.map(k,hc,j),m.isFunction(j.opts.start)&&j.opts.start.call(a,j),m.fx.timer(m.extend(i,{elem:a,anim:j,queue:j.opts.queue})),j.progress(j.opts.progress).done(j.opts.done,j.opts.complete).fail(j.opts.fail).always(j.opts.always)
}m.Animation=m.extend(kc,{tweener:function(a,b){m.isFunction(a)?(b=a,a=["*"]):a=a.split(" ");
for(var c,d=0,e=a.length;
e>d;
d++){c=a[d],ec[c]=ec[c]||[],ec[c].unshift(b)
}},prefilter:function(a,b){b?dc.unshift(a):dc.push(a)
}}),m.speed=function(a,b,c){var d=a&&"object"==typeof a?m.extend({},a):{complete:c||!c&&b||m.isFunction(a)&&a,duration:a,easing:c&&b||b&&!m.isFunction(b)&&b};
return d.duration=m.fx.off?0:"number"==typeof d.duration?d.duration:d.duration in m.fx.speeds?m.fx.speeds[d.duration]:m.fx.speeds._default,(null==d.queue||d.queue===!0)&&(d.queue="fx"),d.old=d.complete,d.complete=function(){m.isFunction(d.old)&&d.old.call(this),d.queue&&m.dequeue(this,d.queue)
},d
},m.fn.extend({fadeTo:function(a,b,c,d){return this.filter(U).css("opacity",0).show().end().animate({opacity:b},a,c,d)
},animate:function(a,b,c,d){var e=m.isEmptyObject(a),f=m.speed(b,c,d),g=function(){var b=kc(this,m.extend({},a),f);
(e||m._data(this,"finish"))&&b.stop(!0)
};
return g.finish=g,e||f.queue===!1?this.each(g):this.queue(f.queue,g)
},stop:function(a,b,c){var d=function(a){var b=a.stop;
delete a.stop,b(c)
};
return"string"!=typeof a&&(c=b,b=a,a=void 0),b&&a!==!1&&this.queue(a||"fx",[]),this.each(function(){var b=!0,e=null!=a&&a+"queueHooks",f=m.timers,g=m._data(this);
if(e){g[e]&&g[e].stop&&d(g[e])
}else{for(e in g){g[e]&&g[e].stop&&cc.test(e)&&d(g[e])
}}for(e=f.length;
e--;
){f[e].elem!==this||null!=a&&f[e].queue!==a||(f[e].anim.stop(c),b=!1,f.splice(e,1))
}(b||!c)&&m.dequeue(this,a)
})
},finish:function(a){return a!==!1&&(a=a||"fx"),this.each(function(){var b,c=m._data(this),d=c[a+"queue"],e=c[a+"queueHooks"],f=m.timers,g=d?d.length:0;
for(c.finish=!0,m.queue(this,a,[]),e&&e.stop&&e.stop.call(this,!0),b=f.length;
b--;
){f[b].elem===this&&f[b].queue===a&&(f[b].anim.stop(!0),f.splice(b,1))
}for(b=0;
g>b;
b++){d[b]&&d[b].finish&&d[b].finish.call(this)
}delete c.finish
})
}}),m.each(["toggle","show","hide"],function(a,b){var c=m.fn[b];
m.fn[b]=function(a,d,e){return null==a||"boolean"==typeof a?c.apply(this,arguments):this.animate(gc(b,!0),a,d,e)
}
}),m.each({slideDown:gc("show"),slideUp:gc("hide"),slideToggle:gc("toggle"),fadeIn:{opacity:"show"},fadeOut:{opacity:"hide"},fadeToggle:{opacity:"toggle"}},function(a,b){m.fn[a]=function(a,c,d){return this.animate(b,a,c,d)
}
}),m.timers=[],m.fx.tick=function(){var a,b=m.timers,c=0;
for($b=m.now();
c<b.length;
c++){a=b[c],a()||b[c]!==a||b.splice(c--,1)
}b.length||m.fx.stop(),$b=void 0
},m.fx.timer=function(a){m.timers.push(a),a()?m.fx.start():m.timers.pop()
},m.fx.interval=13,m.fx.start=function(){_b||(_b=setInterval(m.fx.tick,m.fx.interval))
},m.fx.stop=function(){clearInterval(_b),_b=null
},m.fx.speeds={slow:600,fast:200,_default:400},m.fn.delay=function(a,b){return a=m.fx?m.fx.speeds[a]||a:a,b=b||"fx",this.queue(b,function(b,c){var d=setTimeout(b,a);
c.stop=function(){clearTimeout(d)
}
})
},function(){var a,b,c,d,e;
b=y.createElement("div"),b.setAttribute("className","t"),b.innerHTML="  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",d=b.getElementsByTagName("a")[0],c=y.createElement("select"),e=c.appendChild(y.createElement("option")),a=b.getElementsByTagName("input")[0],d.style.cssText="top:1px",k.getSetAttribute="t"!==b.className,k.style=/top/.test(d.getAttribute("style")),k.hrefNormalized="/a"===d.getAttribute("href"),k.checkOn=!!a.value,k.optSelected=e.selected,k.enctype=!!y.createElement("form").enctype,c.disabled=!0,k.optDisabled=!e.disabled,a=y.createElement("input"),a.setAttribute("value",""),k.input=""===a.getAttribute("value"),a.value="t",a.setAttribute("type","radio"),k.radioValue="t"===a.value
}();
var lc=/\r/g;
m.fn.extend({val:function(a){var b,c,d,e=this[0];
if(arguments.length){return d=m.isFunction(a),this.each(function(c){var e;
1===this.nodeType&&(e=d?a.call(this,c,m(this).val()):a,null==e?e="":"number"==typeof e?e+="":m.isArray(e)&&(e=m.map(e,function(a){return null==a?"":a+""
})),b=m.valHooks[this.type]||m.valHooks[this.nodeName.toLowerCase()],b&&"set" in b&&void 0!==b.set(this,e,"value")||(this.value=e))
})
}if(e){return b=m.valHooks[e.type]||m.valHooks[e.nodeName.toLowerCase()],b&&"get" in b&&void 0!==(c=b.get(e,"value"))?c:(c=e.value,"string"==typeof c?c.replace(lc,""):null==c?"":c)
}}}),m.extend({valHooks:{option:{get:function(a){var b=m.find.attr(a,"value");
return null!=b?b:m.trim(m.text(a))
}},select:{get:function(a){for(var b,c,d=a.options,e=a.selectedIndex,f="select-one"===a.type||0>e,g=f?null:[],h=f?e+1:d.length,i=0>e?h:f?e:0;
h>i;
i++){if(c=d[i],!(!c.selected&&i!==e||(k.optDisabled?c.disabled:null!==c.getAttribute("disabled"))||c.parentNode.disabled&&m.nodeName(c.parentNode,"optgroup"))){if(b=m(c).val(),f){return b
}g.push(b)
}}return g
},set:function(a,b){var c,d,e=a.options,f=m.makeArray(b),g=e.length;
while(g--){if(d=e[g],m.inArray(m.valHooks.option.get(d),f)>=0){try{d.selected=c=!0
}catch(h){d.scrollHeight
}}else{d.selected=!1
}}return c||(a.selectedIndex=-1),e
}}}}),m.each(["radio","checkbox"],function(){m.valHooks[this]={set:function(a,b){return m.isArray(b)?a.checked=m.inArray(m(a).val(),b)>=0:void 0
}},k.checkOn||(m.valHooks[this].get=function(a){return null===a.getAttribute("value")?"on":a.value
})
});
var mc,nc,oc=m.expr.attrHandle,pc=/^(?:checked|selected)$/i,qc=k.getSetAttribute,rc=k.input;
m.fn.extend({attr:function(a,b){return V(this,m.attr,a,b,arguments.length>1)
},removeAttr:function(a){return this.each(function(){m.removeAttr(this,a)
})
}}),m.extend({attr:function(a,b,c){var d,e,f=a.nodeType;
if(a&&3!==f&&8!==f&&2!==f){return typeof a.getAttribute===K?m.prop(a,b,c):(1===f&&m.isXMLDoc(a)||(b=b.toLowerCase(),d=m.attrHooks[b]||(m.expr.match.bool.test(b)?nc:mc)),void 0===c?d&&"get" in d&&null!==(e=d.get(a,b))?e:(e=m.find.attr(a,b),null==e?void 0:e):null!==c?d&&"set" in d&&void 0!==(e=d.set(a,c,b))?e:(a.setAttribute(b,c+""),c):void m.removeAttr(a,b))
}},removeAttr:function(a,b){var c,d,e=0,f=b&&b.match(E);
if(f&&1===a.nodeType){while(c=f[e++]){d=m.propFix[c]||c,m.expr.match.bool.test(c)?rc&&qc||!pc.test(c)?a[d]=!1:a[m.camelCase("default-"+c)]=a[d]=!1:m.attr(a,c,""),a.removeAttribute(qc?c:d)
}}},attrHooks:{type:{set:function(a,b){if(!k.radioValue&&"radio"===b&&m.nodeName(a,"input")){var c=a.value;
return a.setAttribute("type",b),c&&(a.value=c),b
}}}}}),nc={set:function(a,b,c){return b===!1?m.removeAttr(a,c):rc&&qc||!pc.test(c)?a.setAttribute(!qc&&m.propFix[c]||c,c):a[m.camelCase("default-"+c)]=a[c]=!0,c
}},m.each(m.expr.match.bool.source.match(/\w+/g),function(a,b){var c=oc[b]||m.find.attr;
oc[b]=rc&&qc||!pc.test(b)?function(a,b,d){var e,f;
return d||(f=oc[b],oc[b]=e,e=null!=c(a,b,d)?b.toLowerCase():null,oc[b]=f),e
}:function(a,b,c){return c?void 0:a[m.camelCase("default-"+b)]?b.toLowerCase():null
}
}),rc&&qc||(m.attrHooks.value={set:function(a,b,c){return m.nodeName(a,"input")?void (a.defaultValue=b):mc&&mc.set(a,b,c)
}}),qc||(mc={set:function(a,b,c){var d=a.getAttributeNode(c);
return d||a.setAttributeNode(d=a.ownerDocument.createAttribute(c)),d.value=b+="","value"===c||b===a.getAttribute(c)?b:void 0
}},oc.id=oc.name=oc.coords=function(a,b,c){var d;
return c?void 0:(d=a.getAttributeNode(b))&&""!==d.value?d.value:null
},m.valHooks.button={get:function(a,b){var c=a.getAttributeNode(b);
return c&&c.specified?c.value:void 0
},set:mc.set},m.attrHooks.contenteditable={set:function(a,b,c){mc.set(a,""===b?!1:b,c)
}},m.each(["width","height"],function(a,b){m.attrHooks[b]={set:function(a,c){return""===c?(a.setAttribute(b,"auto"),c):void 0
}}
})),k.style||(m.attrHooks.style={get:function(a){return a.style.cssText||void 0
},set:function(a,b){return a.style.cssText=b+""
}});
var sc=/^(?:input|select|textarea|button|object)$/i,tc=/^(?:a|area)$/i;
m.fn.extend({prop:function(a,b){return V(this,m.prop,a,b,arguments.length>1)
},removeProp:function(a){return a=m.propFix[a]||a,this.each(function(){try{this[a]=void 0,delete this[a]
}catch(b){}})
}}),m.extend({propFix:{"for":"htmlFor","class":"className"},prop:function(a,b,c){var d,e,f,g=a.nodeType;
if(a&&3!==g&&8!==g&&2!==g){return f=1!==g||!m.isXMLDoc(a),f&&(b=m.propFix[b]||b,e=m.propHooks[b]),void 0!==c?e&&"set" in e&&void 0!==(d=e.set(a,c,b))?d:a[b]=c:e&&"get" in e&&null!==(d=e.get(a,b))?d:a[b]
}},propHooks:{tabIndex:{get:function(a){var b=m.find.attr(a,"tabindex");
return b?parseInt(b,10):sc.test(a.nodeName)||tc.test(a.nodeName)&&a.href?0:-1
}}}}),k.hrefNormalized||m.each(["href","src"],function(a,b){m.propHooks[b]={get:function(a){return a.getAttribute(b,4)
}}
}),k.optSelected||(m.propHooks.selected={get:function(a){var b=a.parentNode;
return b&&(b.selectedIndex,b.parentNode&&b.parentNode.selectedIndex),null
}}),m.each(["tabIndex","readOnly","maxLength","cellSpacing","cellPadding","rowSpan","colSpan","useMap","frameBorder","contentEditable"],function(){m.propFix[this.toLowerCase()]=this
}),k.enctype||(m.propFix.enctype="encoding");
var uc=/[\t\r\n\f]/g;
m.fn.extend({addClass:function(a){var b,c,d,e,f,g,h=0,i=this.length,j="string"==typeof a&&a;
if(m.isFunction(a)){return this.each(function(b){m(this).addClass(a.call(this,b,this.className))
})
}if(j){for(b=(a||"").match(E)||[];
i>h;
h++){if(c=this[h],d=1===c.nodeType&&(c.className?(" "+c.className+" ").replace(uc," "):" ")){f=0;
while(e=b[f++]){d.indexOf(" "+e+" ")<0&&(d+=e+" ")
}g=m.trim(d),c.className!==g&&(c.className=g)
}}}return this
},removeClass:function(a){var b,c,d,e,f,g,h=0,i=this.length,j=0===arguments.length||"string"==typeof a&&a;
if(m.isFunction(a)){return this.each(function(b){m(this).removeClass(a.call(this,b,this.className))
})
}if(j){for(b=(a||"").match(E)||[];
i>h;
h++){if(c=this[h],d=1===c.nodeType&&(c.className?(" "+c.className+" ").replace(uc," "):"")){f=0;
while(e=b[f++]){while(d.indexOf(" "+e+" ")>=0){d=d.replace(" "+e+" "," ")
}}g=a?m.trim(d):"",c.className!==g&&(c.className=g)
}}}return this
},toggleClass:function(a,b){var c=typeof a;
return"boolean"==typeof b&&"string"===c?b?this.addClass(a):this.removeClass(a):this.each(m.isFunction(a)?function(c){m(this).toggleClass(a.call(this,c,this.className,b),b)
}:function(){if("string"===c){var b,d=0,e=m(this),f=a.match(E)||[];
while(b=f[d++]){e.hasClass(b)?e.removeClass(b):e.addClass(b)
}}else{(c===K||"boolean"===c)&&(this.className&&m._data(this,"__className__",this.className),this.className=this.className||a===!1?"":m._data(this,"__className__")||"")
}})
},hasClass:function(a){for(var b=" "+a+" ",c=0,d=this.length;
d>c;
c++){if(1===this[c].nodeType&&(" "+this[c].className+" ").replace(uc," ").indexOf(b)>=0){return !0
}}return !1
}}),m.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "),function(a,b){m.fn[b]=function(a,c){return arguments.length>0?this.on(b,null,a,c):this.trigger(b)
}
}),m.fn.extend({hover:function(a,b){return this.mouseenter(a).mouseleave(b||a)
},bind:function(a,b,c){return this.on(a,null,b,c)
},unbind:function(a,b){return this.off(a,null,b)
},delegate:function(a,b,c,d){return this.on(b,a,c,d)
},undelegate:function(a,b,c){return 1===arguments.length?this.off(a,"**"):this.off(b,a||"**",c)
}});
var vc=m.now(),wc=/\?/,xc=/(,)|(\[|{)|(}|])|"(?:[^"\\\r\n]|\\["\\\/bfnrt]|\\u[\da-fA-F]{4})*"\s*:?|true|false|null|-?(?!0\d)\d+(?:\.\d+|)(?:[eE][+-]?\d+|)/g;
m.parseJSON=function(b){if(a.JSON&&a.JSON.parse){return a.JSON.parse(b+"")
}var c,d=null,e=m.trim(b+"");
return e&&!m.trim(e.replace(xc,function(a,b,e,f){return c&&b&&(d=0),0===d?a:(c=e||b,d+=!f-!e,"")
}))?Function("return "+e)():m.error("Invalid JSON: "+b)
},m.parseXML=function(b){var c,d;
if(!b||"string"!=typeof b){return null
}try{a.DOMParser?(d=new DOMParser,c=d.parseFromString(b,"text/xml")):(c=new ActiveXObject("Microsoft.XMLDOM"),c.async="false",c.loadXML(b))
}catch(e){c=void 0
}return c&&c.documentElement&&!c.getElementsByTagName("parsererror").length||m.error("Invalid XML: "+b),c
};
var yc,zc,Ac=/#.*$/,Bc=/([?&])_=[^&]*/,Cc=/^(.*?):[ \t]*([^\r\n]*)\r?$/gm,Dc=/^(?:about|app|app-storage|.+-extension|file|res|widget):$/,Ec=/^(?:GET|HEAD)$/,Fc=/^\/\//,Gc=/^([\w.+-]+:)(?:\/\/(?:[^\/?#]*@|)([^\/?#:]*)(?::(\d+)|)|)/,Hc={},Ic={},Jc="*/".concat("*");
try{zc=location.href
}catch(Kc){zc=y.createElement("a"),zc.href="",zc=zc.href
}yc=Gc.exec(zc.toLowerCase())||[];
function Lc(a){return function(b,c){"string"!=typeof b&&(c=b,b="*");
var d,e=0,f=b.toLowerCase().match(E)||[];
if(m.isFunction(c)){while(d=f[e++]){"+"===d.charAt(0)?(d=d.slice(1)||"*",(a[d]=a[d]||[]).unshift(c)):(a[d]=a[d]||[]).push(c)
}}}
}function Mc(a,b,c,d){var e={},f=a===Ic;
function g(h){var i;
return e[h]=!0,m.each(a[h]||[],function(a,h){var j=h(b,c,d);
return"string"!=typeof j||f||e[j]?f?!(i=j):void 0:(b.dataTypes.unshift(j),g(j),!1)
}),i
}return g(b.dataTypes[0])||!e["*"]&&g("*")
}function Nc(a,b){var c,d,e=m.ajaxSettings.flatOptions||{};
for(d in b){void 0!==b[d]&&((e[d]?a:c||(c={}))[d]=b[d])
}return c&&m.extend(!0,a,c),a
}function Oc(a,b,c){var d,e,f,g,h=a.contents,i=a.dataTypes;
while("*"===i[0]){i.shift(),void 0===e&&(e=a.mimeType||b.getResponseHeader("Content-Type"))
}if(e){for(g in h){if(h[g]&&h[g].test(e)){i.unshift(g);
break
}}}if(i[0] in c){f=i[0]
}else{for(g in c){if(!i[0]||a.converters[g+" "+i[0]]){f=g;
break
}d||(d=g)
}f=f||d
}return f?(f!==i[0]&&i.unshift(f),c[f]):void 0
}function Pc(a,b,c,d){var e,f,g,h,i,j={},k=a.dataTypes.slice();
if(k[1]){for(g in a.converters){j[g.toLowerCase()]=a.converters[g]
}}f=k.shift();
while(f){if(a.responseFields[f]&&(c[a.responseFields[f]]=b),!i&&d&&a.dataFilter&&(b=a.dataFilter(b,a.dataType)),i=f,f=k.shift()){if("*"===f){f=i
}else{if("*"!==i&&i!==f){if(g=j[i+" "+f]||j["* "+f],!g){for(e in j){if(h=e.split(" "),h[1]===f&&(g=j[i+" "+h[0]]||j["* "+h[0]])){g===!0?g=j[e]:j[e]!==!0&&(f=h[0],k.unshift(h[1]));
break
}}}if(g!==!0){if(g&&a["throws"]){b=g(b)
}else{try{b=g(b)
}catch(l){return{state:"parsererror",error:g?l:"No conversion from "+i+" to "+f}
}}}}}}}return{state:"success",data:b}
}m.extend({active:0,lastModified:{},etag:{},ajaxSettings:{url:zc,type:"GET",isLocal:Dc.test(yc[1]),global:!0,processData:!0,async:!0,contentType:"application/x-www-form-urlencoded; charset=UTF-8",accepts:{"*":Jc,text:"text/plain",html:"text/html",xml:"application/xml, text/xml",json:"application/json, text/javascript"},contents:{xml:/xml/,html:/html/,json:/json/},responseFields:{xml:"responseXML",text:"responseText",json:"responseJSON"},converters:{"* text":String,"text html":!0,"text json":m.parseJSON,"text xml":m.parseXML},flatOptions:{url:!0,context:!0}},ajaxSetup:function(a,b){return b?Nc(Nc(a,m.ajaxSettings),b):Nc(m.ajaxSettings,a)
},ajaxPrefilter:Lc(Hc),ajaxTransport:Lc(Ic),ajax:function(a,b){"object"==typeof a&&(b=a,a=void 0),b=b||{};
var c,d,e,f,g,h,i,j,k=m.ajaxSetup({},b),l=k.context||k,n=k.context&&(l.nodeType||l.jquery)?m(l):m.event,o=m.Deferred(),p=m.Callbacks("once memory"),q=k.statusCode||{},r={},s={},t=0,u="canceled",v={readyState:0,getResponseHeader:function(a){var b;
if(2===t){if(!j){j={};
while(b=Cc.exec(f)){j[b[1].toLowerCase()]=b[2]
}}b=j[a.toLowerCase()]
}return null==b?null:b
},getAllResponseHeaders:function(){return 2===t?f:null
},setRequestHeader:function(a,b){var c=a.toLowerCase();
return t||(a=s[c]=s[c]||a,r[a]=b),this
},overrideMimeType:function(a){return t||(k.mimeType=a),this
},statusCode:function(a){var b;
if(a){if(2>t){for(b in a){q[b]=[q[b],a[b]]
}}else{v.always(a[v.status])
}}return this
},abort:function(a){var b=a||u;
return i&&i.abort(b),x(0,b),this
}};
if(o.promise(v).complete=p.add,v.success=v.done,v.error=v.fail,k.url=((a||k.url||zc)+"").replace(Ac,"").replace(Fc,yc[1]+"//"),k.type=b.method||b.type||k.method||k.type,k.dataTypes=m.trim(k.dataType||"*").toLowerCase().match(E)||[""],null==k.crossDomain&&(c=Gc.exec(k.url.toLowerCase()),k.crossDomain=!(!c||c[1]===yc[1]&&c[2]===yc[2]&&(c[3]||("http:"===c[1]?"80":"443"))===(yc[3]||("http:"===yc[1]?"80":"443")))),k.data&&k.processData&&"string"!=typeof k.data&&(k.data=m.param(k.data,k.traditional)),Mc(Hc,k,b,v),2===t){return v
}h=m.event&&k.global,h&&0===m.active++&&m.event.trigger("ajaxStart"),k.type=k.type.toUpperCase(),k.hasContent=!Ec.test(k.type),e=k.url,k.hasContent||(k.data&&(e=k.url+=(wc.test(e)?"&":"?")+k.data,delete k.data),k.cache===!1&&(k.url=Bc.test(e)?e.replace(Bc,"$1_="+vc++):e+(wc.test(e)?"&":"?")+"_="+vc++)),k.ifModified&&(m.lastModified[e]&&v.setRequestHeader("If-Modified-Since",m.lastModified[e]),m.etag[e]&&v.setRequestHeader("If-None-Match",m.etag[e])),(k.data&&k.hasContent&&k.contentType!==!1||b.contentType)&&v.setRequestHeader("Content-Type",k.contentType),v.setRequestHeader("Accept",k.dataTypes[0]&&k.accepts[k.dataTypes[0]]?k.accepts[k.dataTypes[0]]+("*"!==k.dataTypes[0]?", "+Jc+"; q=0.01":""):k.accepts["*"]);
for(d in k.headers){v.setRequestHeader(d,k.headers[d])
}if(k.beforeSend&&(k.beforeSend.call(l,v,k)===!1||2===t)){return v.abort()
}u="abort";
for(d in {success:1,error:1,complete:1}){v[d](k[d])
}if(i=Mc(Ic,k,b,v)){v.readyState=1,h&&n.trigger("ajaxSend",[v,k]),k.async&&k.timeout>0&&(g=setTimeout(function(){v.abort("timeout")
},k.timeout));
try{t=1,i.send(r,x)
}catch(w){if(!(2>t)){throw w
}x(-1,w)
}}else{x(-1,"No Transport")
}function x(a,b,c,d){var j,r,s,u,w,x=b;
2!==t&&(t=2,g&&clearTimeout(g),i=void 0,f=d||"",v.readyState=a>0?4:0,j=a>=200&&300>a||304===a,c&&(u=Oc(k,v,c)),u=Pc(k,u,v,j),j?(k.ifModified&&(w=v.getResponseHeader("Last-Modified"),w&&(m.lastModified[e]=w),w=v.getResponseHeader("etag"),w&&(m.etag[e]=w)),204===a||"HEAD"===k.type?x="nocontent":304===a?x="notmodified":(x=u.state,r=u.data,s=u.error,j=!s)):(s=x,(a||!x)&&(x="error",0>a&&(a=0))),v.status=a,v.statusText=(b||x)+"",j?o.resolveWith(l,[r,x,v]):o.rejectWith(l,[v,x,s]),v.statusCode(q),q=void 0,h&&n.trigger(j?"ajaxSuccess":"ajaxError",[v,k,j?r:s]),p.fireWith(l,[v,x]),h&&(n.trigger("ajaxComplete",[v,k]),--m.active||m.event.trigger("ajaxStop")))
}return v
},getJSON:function(a,b,c){return m.get(a,b,c,"json")
},getScript:function(a,b){return m.get(a,void 0,b,"script")
}}),m.each(["get","post"],function(a,b){m[b]=function(a,c,d,e){return m.isFunction(c)&&(e=e||d,d=c,c=void 0),m.ajax({url:a,type:b,dataType:e,data:c,success:d})
}
}),m._evalUrl=function(a){return m.ajax({url:a,type:"GET",dataType:"script",async:!1,global:!1,"throws":!0})
},m.fn.extend({wrapAll:function(a){if(m.isFunction(a)){return this.each(function(b){m(this).wrapAll(a.call(this,b))
})
}if(this[0]){var b=m(a,this[0].ownerDocument).eq(0).clone(!0);
this[0].parentNode&&b.insertBefore(this[0]),b.map(function(){var a=this;
while(a.firstChild&&1===a.firstChild.nodeType){a=a.firstChild
}return a
}).append(this)
}return this
},wrapInner:function(a){return this.each(m.isFunction(a)?function(b){m(this).wrapInner(a.call(this,b))
}:function(){var b=m(this),c=b.contents();
c.length?c.wrapAll(a):b.append(a)
})
},wrap:function(a){var b=m.isFunction(a);
return this.each(function(c){m(this).wrapAll(b?a.call(this,c):a)
})
},unwrap:function(){return this.parent().each(function(){m.nodeName(this,"body")||m(this).replaceWith(this.childNodes)
}).end()
}}),m.expr.filters.hidden=function(a){return a.offsetWidth<=0&&a.offsetHeight<=0||!k.reliableHiddenOffsets()&&"none"===(a.style&&a.style.display||m.css(a,"display"))
},m.expr.filters.visible=function(a){return !m.expr.filters.hidden(a)
};
var Qc=/%20/g,Rc=/\[\]$/,Sc=/\r?\n/g,Tc=/^(?:submit|button|image|reset|file)$/i,Uc=/^(?:input|select|textarea|keygen)/i;
function Vc(a,b,c,d){var e;
if(m.isArray(b)){m.each(b,function(b,e){c||Rc.test(a)?d(a,e):Vc(a+"["+("object"==typeof e?b:"")+"]",e,c,d)
})
}else{if(c||"object"!==m.type(b)){d(a,b)
}else{for(e in b){Vc(a+"["+e+"]",b[e],c,d)
}}}}m.param=function(a,b){var c,d=[],e=function(a,b){b=m.isFunction(b)?b():null==b?"":b,d[d.length]=encodeURIComponent(a)+"="+encodeURIComponent(b)
};
if(void 0===b&&(b=m.ajaxSettings&&m.ajaxSettings.traditional),m.isArray(a)||a.jquery&&!m.isPlainObject(a)){m.each(a,function(){e(this.name,this.value)
})
}else{for(c in a){Vc(c,a[c],b,e)
}}return d.join("&").replace(Qc,"+")
},m.fn.extend({serialize:function(){return m.param(this.serializeArray())
},serializeArray:function(){return this.map(function(){var a=m.prop(this,"elements");
return a?m.makeArray(a):this
}).filter(function(){var a=this.type;
return this.name&&!m(this).is(":disabled")&&Uc.test(this.nodeName)&&!Tc.test(a)&&(this.checked||!W.test(a))
}).map(function(a,b){var c=m(this).val();
return null==c?null:m.isArray(c)?m.map(c,function(a){return{name:b.name,value:a.replace(Sc,"\r\n")}
}):{name:b.name,value:c.replace(Sc,"\r\n")}
}).get()
}}),m.ajaxSettings.xhr=void 0!==a.ActiveXObject?function(){return !this.isLocal&&/^(get|post|head|put|delete|options)$/i.test(this.type)&&Zc()||$c()
}:Zc;
var Wc=0,Xc={},Yc=m.ajaxSettings.xhr();
a.attachEvent&&a.attachEvent("onunload",function(){for(var a in Xc){Xc[a](void 0,!0)
}}),k.cors=!!Yc&&"withCredentials" in Yc,Yc=k.ajax=!!Yc,Yc&&m.ajaxTransport(function(a){if(!a.crossDomain||k.cors){var b;
return{send:function(c,d){var e,f=a.xhr(),g=++Wc;
if(f.open(a.type,a.url,a.async,a.username,a.password),a.xhrFields){for(e in a.xhrFields){f[e]=a.xhrFields[e]
}}a.mimeType&&f.overrideMimeType&&f.overrideMimeType(a.mimeType),a.crossDomain||c["X-Requested-With"]||(c["X-Requested-With"]="XMLHttpRequest");
for(e in c){void 0!==c[e]&&f.setRequestHeader(e,c[e]+"")
}f.send(a.hasContent&&a.data||null),b=function(c,e){var h,i,j;
if(b&&(e||4===f.readyState)){if(delete Xc[g],b=void 0,f.onreadystatechange=m.noop,e){4!==f.readyState&&f.abort()
}else{j={},h=f.status,"string"==typeof f.responseText&&(j.text=f.responseText);
try{i=f.statusText
}catch(k){i=""
}h||!a.isLocal||a.crossDomain?1223===h&&(h=204):h=j.text?200:404
}}j&&d(h,i,j,f.getAllResponseHeaders())
},a.async?4===f.readyState?setTimeout(b):f.onreadystatechange=Xc[g]=b:b()
},abort:function(){b&&b(void 0,!0)
}}
}});
function Zc(){try{return new a.XMLHttpRequest
}catch(b){}}function $c(){try{return new a.ActiveXObject("Microsoft.XMLHTTP")
}catch(b){}}m.ajaxSetup({accepts:{script:"text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"},contents:{script:/(?:java|ecma)script/},converters:{"text script":function(a){return m.globalEval(a),a
}}}),m.ajaxPrefilter("script",function(a){void 0===a.cache&&(a.cache=!1),a.crossDomain&&(a.type="GET",a.global=!1)
}),m.ajaxTransport("script",function(a){if(a.crossDomain){var b,c=y.head||m("head")[0]||y.documentElement;
return{send:function(d,e){b=y.createElement("script"),b.async=!0,a.scriptCharset&&(b.charset=a.scriptCharset),b.src=a.url,b.onload=b.onreadystatechange=function(a,c){(c||!b.readyState||/loaded|complete/.test(b.readyState))&&(b.onload=b.onreadystatechange=null,b.parentNode&&b.parentNode.removeChild(b),b=null,c||e(200,"success"))
},c.insertBefore(b,c.firstChild)
},abort:function(){b&&b.onload(void 0,!0)
}}
}});
var _c=[],ad=/(=)\?(?=&|$)|\?\?/;
m.ajaxSetup({jsonp:"callback",jsonpCallback:function(){var a=_c.pop()||m.expando+"_"+vc++;
return this[a]=!0,a
}}),m.ajaxPrefilter("json jsonp",function(b,c,d){var e,f,g,h=b.jsonp!==!1&&(ad.test(b.url)?"url":"string"==typeof b.data&&!(b.contentType||"").indexOf("application/x-www-form-urlencoded")&&ad.test(b.data)&&"data");
return h||"jsonp"===b.dataTypes[0]?(e=b.jsonpCallback=m.isFunction(b.jsonpCallback)?b.jsonpCallback():b.jsonpCallback,h?b[h]=b[h].replace(ad,"$1"+e):b.jsonp!==!1&&(b.url+=(wc.test(b.url)?"&":"?")+b.jsonp+"="+e),b.converters["script json"]=function(){return g||m.error(e+" was not called"),g[0]
},b.dataTypes[0]="json",f=a[e],a[e]=function(){g=arguments
},d.always(function(){a[e]=f,b[e]&&(b.jsonpCallback=c.jsonpCallback,_c.push(e)),g&&m.isFunction(f)&&f(g[0]),g=f=void 0
}),"script"):void 0
}),m.parseHTML=function(a,b,c){if(!a||"string"!=typeof a){return null
}"boolean"==typeof b&&(c=b,b=!1),b=b||y;
var d=u.exec(a),e=!c&&[];
return d?[b.createElement(d[1])]:(d=m.buildFragment([a],b,e),e&&e.length&&m(e).remove(),m.merge([],d.childNodes))
};
var bd=m.fn.load;
m.fn.load=function(a,b,c){if("string"!=typeof a&&bd){return bd.apply(this,arguments)
}var d,e,f,g=this,h=a.indexOf(" ");
return h>=0&&(d=m.trim(a.slice(h,a.length)),a=a.slice(0,h)),m.isFunction(b)?(c=b,b=void 0):b&&"object"==typeof b&&(f="POST"),g.length>0&&m.ajax({url:a,type:f,dataType:"html",data:b}).done(function(a){e=arguments,g.html(d?m("<div>").append(m.parseHTML(a)).find(d):a)
}).complete(c&&function(a,b){g.each(c,e||[a.responseText,b,a])
}),this
},m.each(["ajaxStart","ajaxStop","ajaxComplete","ajaxError","ajaxSuccess","ajaxSend"],function(a,b){m.fn[b]=function(a){return this.on(b,a)
}
}),m.expr.filters.animated=function(a){return m.grep(m.timers,function(b){return a===b.elem
}).length
};
var cd=a.document.documentElement;
function dd(a){return m.isWindow(a)?a:9===a.nodeType?a.defaultView||a.parentWindow:!1
}m.offset={setOffset:function(a,b,c){var d,e,f,g,h,i,j,k=m.css(a,"position"),l=m(a),n={};
"static"===k&&(a.style.position="relative"),h=l.offset(),f=m.css(a,"top"),i=m.css(a,"left"),j=("absolute"===k||"fixed"===k)&&m.inArray("auto",[f,i])>-1,j?(d=l.position(),g=d.top,e=d.left):(g=parseFloat(f)||0,e=parseFloat(i)||0),m.isFunction(b)&&(b=b.call(a,c,h)),null!=b.top&&(n.top=b.top-h.top+g),null!=b.left&&(n.left=b.left-h.left+e),"using" in b?b.using.call(a,n):l.css(n)
}},m.fn.extend({offset:function(a){if(arguments.length){return void 0===a?this:this.each(function(b){m.offset.setOffset(this,a,b)
})
}var b,c,d={top:0,left:0},e=this[0],f=e&&e.ownerDocument;
if(f){return b=f.documentElement,m.contains(b,e)?(typeof e.getBoundingClientRect!==K&&(d=e.getBoundingClientRect()),c=dd(f),{top:d.top+(c.pageYOffset||b.scrollTop)-(b.clientTop||0),left:d.left+(c.pageXOffset||b.scrollLeft)-(b.clientLeft||0)}):d
}},position:function(){if(this[0]){var a,b,c={top:0,left:0},d=this[0];
return"fixed"===m.css(d,"position")?b=d.getBoundingClientRect():(a=this.offsetParent(),b=this.offset(),m.nodeName(a[0],"html")||(c=a.offset()),c.top+=m.css(a[0],"borderTopWidth",!0),c.left+=m.css(a[0],"borderLeftWidth",!0)),{top:b.top-c.top-m.css(d,"marginTop",!0),left:b.left-c.left-m.css(d,"marginLeft",!0)}
}},offsetParent:function(){return this.map(function(){var a=this.offsetParent||cd;
while(a&&!m.nodeName(a,"html")&&"static"===m.css(a,"position")){a=a.offsetParent
}return a||cd
})
}}),m.each({scrollLeft:"pageXOffset",scrollTop:"pageYOffset"},function(a,b){var c=/Y/.test(b);
m.fn[a]=function(d){return V(this,function(a,d,e){var f=dd(a);
return void 0===e?f?b in f?f[b]:f.document.documentElement[d]:a[d]:void (f?f.scrollTo(c?m(f).scrollLeft():e,c?e:m(f).scrollTop()):a[d]=e)
},a,d,arguments.length,null)
}
}),m.each(["top","left"],function(a,b){m.cssHooks[b]=Lb(k.pixelPosition,function(a,c){return c?(c=Jb(a,b),Hb.test(c)?m(a).position()[b]+"px":c):void 0
})
}),m.each({Height:"height",Width:"width"},function(a,b){m.each({padding:"inner"+a,content:b,"":"outer"+a},function(c,d){m.fn[d]=function(d,e){var f=arguments.length&&(c||"boolean"!=typeof d),g=c||(d===!0||e===!0?"margin":"border");
return V(this,function(b,c,d){var e;
return m.isWindow(b)?b.document.documentElement["client"+a]:9===b.nodeType?(e=b.documentElement,Math.max(b.body["scroll"+a],e["scroll"+a],b.body["offset"+a],e["offset"+a],e["client"+a])):void 0===d?m.css(b,c,g):m.style(b,c,d,g)
},b,f?d:void 0,f,null)
}
})
}),m.fn.size=function(){return this.length
},m.fn.andSelf=m.fn.addBack,"function"==typeof define&&define.amd&&define("jquery",[],function(){return m
});
var ed=a.jQuery,fd=a.$;
return m.noConflict=function(b){return a.$===m&&(a.$=fd),b&&a.jQuery===m&&(a.jQuery=ed),m
},typeof b===K&&(a.jQuery=a.$=m),m
});
/*! jQuery UI - v1.9.1 - 2012-10-26
* http://jqueryui.com
* Includes: jquery.ui.core.js, jquery.ui.widget.js, jquery.ui.accordion.js
* Copyright (c) 2012 jQuery Foundation and other contributors Licensed MIT */
(function(g,b){function a(k,q){var l,j,p,e=k.nodeName.toLowerCase();
return"area"===e?(l=k.parentNode,j=l.name,!k.href||!j||l.nodeName.toLowerCase()!=="map"?!1:(p=g("img[usemap=#"+j+"]")[0],!!p&&d(p))):(/input|select|textarea|button|object/.test(e)?!k.disabled:"a"===e?k.href||q:q)&&d(k)
}function d(e){return g.expr.filters.visible(e)&&!g(e).parents().andSelf().filter(function(){return g.css(this,"visibility")==="hidden"
}).length
}var h=0,f=/^ui-id-\d+$/;
g.ui=g.ui||{};
if(g.ui.version){return
}g.extend(g.ui,{version:"1.9.1",keyCode:{BACKSPACE:8,COMMA:188,DELETE:46,DOWN:40,END:35,ENTER:13,ESCAPE:27,HOME:36,LEFT:37,NUMPAD_ADD:107,NUMPAD_DECIMAL:110,NUMPAD_DIVIDE:111,NUMPAD_ENTER:108,NUMPAD_MULTIPLY:106,NUMPAD_SUBTRACT:109,PAGE_DOWN:34,PAGE_UP:33,PERIOD:190,RIGHT:39,SPACE:32,TAB:9,UP:38}}),g.fn.extend({_focus:g.fn.focus,focus:function(e,j){return typeof e=="number"?this.each(function(){var k=this;
setTimeout(function(){g(k).focus(),j&&j.call(k)
},e)
}):this._focus.apply(this,arguments)
},scrollParent:function(){var e;
return g.ui.ie&&/(static|relative)/.test(this.css("position"))||/absolute/.test(this.css("position"))?e=this.parents().filter(function(){return/(relative|absolute|fixed)/.test(g.css(this,"position"))&&/(auto|scroll)/.test(g.css(this,"overflow")+g.css(this,"overflow-y")+g.css(this,"overflow-x"))
}).eq(0):e=this.parents().filter(function(){return/(auto|scroll)/.test(g.css(this,"overflow")+g.css(this,"overflow-y")+g.css(this,"overflow-x"))
}).eq(0),/fixed/.test(this.css("position"))||!e.length?g(document):e
},zIndex:function(l){if(l!==b){return this.css("zIndex",l)
}if(this.length){var k=g(this[0]),e,j;
while(k.length&&k[0]!==document){e=k.css("position");
if(e==="absolute"||e==="relative"||e==="fixed"){j=parseInt(k.css("zIndex"),10);
if(!isNaN(j)&&j!==0){return j
}}k=k.parent()
}}return 0
},uniqueId:function(){return this.each(function(){this.id||(this.id="ui-id-"+ ++h)
})
},removeUniqueId:function(){return this.each(function(){f.test(this.id)&&g(this).removeAttr("id")
})
}}),g("<a>").outerWidth(1).jquery||g.each(["Width","Height"],function(q,l){function e(o,w,v,u){return g.each(j,function(){w-=parseFloat(g.css(o,"padding"+this))||0,v&&(w-=parseFloat(g.css(o,"border"+this+"Width"))||0),u&&(w-=parseFloat(g.css(o,"margin"+this))||0)
}),w
}var j=l==="Width"?["Left","Right"]:["Top","Bottom"],k=l.toLowerCase(),p={innerWidth:g.fn.innerWidth,innerHeight:g.fn.innerHeight,outerWidth:g.fn.outerWidth,outerHeight:g.fn.outerHeight};
g.fn["inner"+l]=function(o){return o===b?p["inner"+l].call(this):this.each(function(){g(this).css(k,e(this,o)+"px")
})
},g.fn["outer"+l]=function(o,r){return typeof o!="number"?p["outer"+l].call(this,o):this.each(function(){g(this).css(k,e(this,o,!0,r)+"px")
})
}
}),g.extend(g.expr[":"],{data:g.expr.createPseudo?g.expr.createPseudo(function(e){return function(j){return !!g.data(j,e)
}
}):function(e,k,j){return !!g.data(e,j[3])
},focusable:function(e){return a(e,!isNaN(g.attr(e,"tabindex")))
},tabbable:function(e){var k=g.attr(e,"tabindex"),j=isNaN(k);
return(j||k>=0)&&a(e,!j)
}}),g(function(){var e=document.body,j=e.appendChild(j=document.createElement("div"));
j.offsetHeight,g.extend(j.style,{minHeight:"100px",height:"auto",padding:0,borderWidth:0}),g.support.minHeight=j.offsetHeight===100,g.support.selectstart="onselectstart" in j,e.removeChild(j).style.display="none"
}),function(){var e=/msie ([\w.]+)/.exec(navigator.userAgent.toLowerCase())||[];
g.ui.ie=e.length?!0:!1,g.ui.ie6=parseFloat(e[1],10)===6
}(),g.fn.extend({disableSelection:function(){return this.bind((g.support.selectstart?"selectstart":"mousedown")+".ui-disableSelection",function(j){j.preventDefault()
})
},enableSelection:function(){return this.unbind(".ui-disableSelection")
}}),g.extend(g.ui,{plugin:{add:function(j,o,l){var e,k=g.ui[j].prototype;
for(e in l){k.plugins[e]=k.plugins[e]||[],k.plugins[e].push([o,l[e]])
}},call:function(o,k,p){var l,j=o.plugins[k];
if(!j||!o.element[0].parentNode||o.element[0].parentNode.nodeType===11){return
}for(l=0;
l<j.length;
l++){o.options[j[l][0]]&&j[l][1].apply(o.element,p)
}}},contains:g.contains,hasScroll:function(j,l){if(g(j).css("overflow")==="hidden"){return !1
}var k=l&&l==="left"?"scrollLeft":"scrollTop",e=!1;
return j[k]>0?!0:(j[k]=1,e=j[k]>0,j[k]=0,e)
},isOverAxis:function(k,j,l){return k>j&&k<j+l
},isOver:function(j,q,l,e,k,p){return g.ui.isOverAxis(j,l,k)&&g.ui.isOverAxis(q,e,p)
}})
})(jQuery);
(function(f,b){var g=0,d=Array.prototype.slice,a=f.cleanData;
f.cleanData=function(e){for(var k=0,j;
(j=e[k])!=null;
k++){try{f(j).triggerHandler("remove")
}catch(h){}}a(e)
},f.widget=function(k,v,p){var j,l,q,h,e=k.split(".")[0];
k=k.split(".")[1],j=e+"-"+k,p||(p=v,v=f.Widget),f.expr[":"][j.toLowerCase()]=function(n){return !!f.data(n,j)
},f[e]=f[e]||{},l=f[e][k],q=f[e][k]=function(o,n){if(!this._createWidget){return new q(o,n)
}arguments.length&&this._createWidget(o,n)
},f.extend(q,l,{version:p.version,_proto:f.extend({},p),_childConstructors:[]}),h=new v,h.options=f.widget.extend({},h.options),f.each(p,function(o,n){f.isFunction(n)&&(p[o]=function(){var t=function(){return v.prototype[o].apply(this,arguments)
},s=function(r){return v.prototype[o].apply(this,r)
};
return function(){var r=this._super,w=this._superApply,u;
return this._super=t,this._superApply=s,u=n.apply(this,arguments),this._super=r,this._superApply=w,u
}
}())
}),q.prototype=f.widget.extend(h,{widgetEventPrefix:h.widgetEventPrefix||k},p,{constructor:q,namespace:e,widgetName:k,widgetBaseClass:j,widgetFullName:j}),l?(f.each(l._childConstructors,function(o,u){var s=u.prototype;
f.widget(s.namespace+"."+s.widgetName,q,u._proto)
}),delete l._childConstructors):v._childConstructors.push(q),f.widget.bridge(k,q)
},f.widget.extend=function(p){var j=d.call(arguments,1),k=0,l=j.length,h,e;
for(;
k<l;
k++){for(h in j[k]){e=j[k][h],j[k].hasOwnProperty(h)&&e!==b&&(f.isPlainObject(e)?p[h]=f.isPlainObject(p[h])?f.widget.extend({},p[h],e):f.widget.extend({},e):p[h]=e)
}}return p
},f.widget.bridge=function(j,e){var h=e.prototype.widgetFullName;
f.fn[j]=function(p){var l=typeof p=="string",k=d.call(arguments,1),n=this;
return p=!l&&k.length?f.widget.extend.apply(null,[p].concat(k)):p,l?this.each(function(){var q,o=f.data(this,h);
if(!o){return f.error("cannot call methods on "+j+" prior to initialization; attempted to call method '"+p+"'")
}if(!f.isFunction(o[p])||p.charAt(0)==="_"){return f.error("no such method '"+p+"' for "+j+" widget instance")
}q=o[p].apply(o,k);
if(q!==o&&q!==b){return n=q&&q.jquery?n.pushStack(q.get()):q,!1
}}):this.each(function(){var o=f.data(this,h);
o?o.option(p||{})._init():new e(p,this)
}),n
}
},f.Widget=function(){},f.Widget._childConstructors=[],f.Widget.prototype={widgetName:"widget",widgetEventPrefix:"",defaultElement:"<div>",options:{disabled:!1,create:null},_createWidget:function(e,h){h=f(h||this.defaultElement||this)[0],this.element=f(h),this.uuid=g++,this.eventNamespace="."+this.widgetName+this.uuid,this.options=f.widget.extend({},this.options,this._getCreateOptions(),e),this.bindings=f(),this.hoverable=f(),this.focusable=f(),h!==this&&(f.data(h,this.widgetName,this),f.data(h,this.widgetFullName,this),this._on(this.element,{remove:function(j){j.target===h&&this.destroy()
}}),this.document=f(h.style?h.ownerDocument:h.document||h),this.window=f(this.document[0].defaultView||this.document[0].parentWindow)),this._create(),this._trigger("create",null,this._getCreateEventData()),this._init()
},_getCreateOptions:f.noop,_getCreateEventData:f.noop,_create:f.noop,_init:f.noop,destroy:function(){this._destroy(),this.element.unbind(this.eventNamespace).removeData(this.widgetName).removeData(this.widgetFullName).removeData(f.camelCase(this.widgetFullName)),this.widget().unbind(this.eventNamespace).removeAttr("aria-disabled").removeClass(this.widgetFullName+"-disabled ui-state-disabled"),this.bindings.unbind(this.eventNamespace),this.hoverable.removeClass("ui-state-hover"),this.focusable.removeClass("ui-state-focus")
},_destroy:f.noop,widget:function(){return this.element
},option:function(p,k){var h=p,j,l,e;
if(arguments.length===0){return f.widget.extend({},this.options)
}if(typeof p=="string"){h={},j=p.split("."),p=j.shift();
if(j.length){l=h[p]=f.widget.extend({},this.options[p]);
for(e=0;
e<j.length-1;
e++){l[j[e]]=l[j[e]]||{},l=l[j[e]]
}p=j.pop();
if(k===b){return l[p]===b?null:l[p]
}l[p]=k
}else{if(k===b){return this.options[p]===b?null:this.options[p]
}h[p]=k
}}return this._setOptions(h),this
},_setOptions:function(j){var h;
for(h in j){this._setOption(h,j[h])
}return this
},_setOption:function(j,h){return this.options[j]=h,j==="disabled"&&(this.widget().toggleClass(this.widgetFullName+"-disabled ui-state-disabled",!!h).attr("aria-disabled",h),this.hoverable.removeClass("ui-state-hover"),this.focusable.removeClass("ui-state-focus")),this
},enable:function(){return this._setOption("disabled",!1)
},disable:function(){return this._setOption("disabled",!0)
},_on:function(h,k){var j,e=this;
k?(h=j=f(h),this.bindings=this.bindings.add(h)):(k=h,h=this.element,j=this.widget()),f.each(k,function(v,q){function t(){if(e.options.disabled===!0||f(this).hasClass("ui-state-disabled")){return
}return(typeof q=="string"?e[q]:q).apply(e,arguments)
}typeof q!="string"&&(t.guid=q.guid=q.guid||t.guid||f.guid++);
var p=v.match(/^(\w+)\s*(.*)$/),l=p[1]+e.eventNamespace,r=p[2];
r?j.delegate(r,l,t):h.bind(l,t)
})
},_off:function(j,h){h=(h||"").split(" ").join(this.eventNamespace+" ")+this.eventNamespace,j.unbind(h).undelegate(h)
},_delay:function(k,h){function l(){return(typeof k=="string"?j[k]:k).apply(j,arguments)
}var j=this;
return setTimeout(l,h||0)
},_hoverable:function(e){this.hoverable=this.hoverable.add(e),this._on(e,{mouseenter:function(h){f(h.currentTarget).addClass("ui-state-hover")
},mouseleave:function(h){f(h.currentTarget).removeClass("ui-state-hover")
}})
},_focusable:function(e){this.focusable=this.focusable.add(e),this._on(e,{focusin:function(h){f(h.currentTarget).addClass("ui-state-focus")
},focusout:function(h){f(h.currentTarget).removeClass("ui-state-focus")
}})
},_trigger:function(h,p,k){var e,j,l=this.options[h];
k=k||{},p=f.Event(p),p.type=(h===this.widgetEventPrefix?h:this.widgetEventPrefix+h).toLowerCase(),p.target=this.element[0],j=p.originalEvent;
if(j){for(e in j){e in p||(p[e]=j[e])
}}return this.element.trigger(p,k),!(f.isFunction(l)&&l.apply(this.element[0],[p].concat(k))===!1||p.isDefaultPrevented())
}},f.each({show:"fadeIn",hide:"fadeOut"},function(e,h){f.Widget.prototype["_"+e]=function(n,k,l){typeof k=="string"&&(k={effect:k});
var p,j=k?k===!0||typeof k=="number"?h:k.effect||h:e;
k=k||{},typeof k=="number"&&(k={duration:k}),p=!f.isEmptyObject(k),k.complete=l,k.delay&&n.delay(k.delay),p&&f.effects&&(f.effects.effect[j]||f.uiBackCompat!==!1&&f.effects[j])?n[e](k):j!==e&&n[j]?n[j](k.duration,k.easing,l):n.queue(function(o){f(this)[e](),l&&l.call(n[0]),o()
})
}
}),f.uiBackCompat!==!1&&(f.Widget.prototype._getCreateOptions=function(){return f.metadata&&f.metadata.get(this.element[0])[this.widgetName]
})
})(jQuery);
(function(f,b){var g=0,d={},a={};
d.height=d.paddingTop=d.paddingBottom=d.borderTopWidth=d.borderBottomWidth="hide",a.height=a.paddingTop=a.paddingBottom=a.borderTopWidth=a.borderBottomWidth="show",f.widget("ui.accordion",{version:"1.9.1",options:{active:0,animate:{},collapsible:!1,event:"click",header:"> li > :first-child,> :not(li):even",heightStyle:"auto",icons:{activeHeader:"ui-icon-triangle-1-s",header:"ui-icon-triangle-1-e"},activate:null,beforeActivate:null},_create:function(){var e=this.accordionId="ui-accordion-"+(this.element.attr("id")||++g),h=this.options;
this.prevShow=this.prevHide=f(),this.element.addClass("ui-accordion ui-widget ui-helper-reset"),this.headers=this.element.find(h.header).addClass("ui-accordion-header ui-helper-reset ui-state-default ui-corner-all"),this._hoverable(this.headers),this._focusable(this.headers),this.headers.next().addClass("ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom").hide(),!h.collapsible&&(h.active===!1||h.active==null)&&(h.active=0),h.active<0&&(h.active+=this.headers.length),this.active=this._findActive(h.active).addClass("ui-accordion-header-active ui-state-active").toggleClass("ui-corner-all ui-corner-top"),this.active.next().addClass("ui-accordion-content-active").show(),this._createIcons(),this.refresh(),this.element.attr("role","tablist"),this.headers.attr("role","tab").each(function(q){var l=f(this),j=l.attr("id"),k=l.next(),p=k.attr("id");
j||(j=e+"-header-"+q,l.attr("id",j)),p||(p=e+"-panel-"+q,k.attr("id",p)),l.attr("aria-controls",p),k.attr("aria-labelledby",j)
}).next().attr("role","tabpanel"),this.headers.not(this.active).attr({"aria-selected":"false",tabIndex:-1}).next().attr({"aria-expanded":"false","aria-hidden":"true"}).hide(),this.active.length?this.active.attr({"aria-selected":"true",tabIndex:0}).next().attr({"aria-expanded":"true","aria-hidden":"false"}):this.headers.eq(0).attr("tabIndex",0),this._on(this.headers,{keydown:"_keydown"}),this._on(this.headers.next(),{keydown:"_panelKeyDown"}),this._setupEvents(h.event)
},_getCreateEventData:function(){return{header:this.active,content:this.active.length?this.active.next():f()}
},_createIcons:function(){var e=this.options.icons;
e&&(f("<span>").addClass("ui-accordion-header-icon ui-icon "+e.header).prependTo(this.headers),this.active.children(".ui-accordion-header-icon").removeClass(e.header).addClass(e.activeHeader),this.headers.addClass("ui-accordion-icons"))
},_destroyIcons:function(){this.headers.removeClass("ui-accordion-icons").children(".ui-accordion-header-icon").remove()
},_destroy:function(){var h;
this.element.removeClass("ui-accordion ui-widget ui-helper-reset").removeAttr("role"),this.headers.removeClass("ui-accordion-header ui-accordion-header-active ui-helper-reset ui-state-default ui-corner-all ui-state-active ui-state-disabled ui-corner-top").removeAttr("role").removeAttr("aria-selected").removeAttr("aria-controls").removeAttr("tabIndex").each(function(){/^ui-accordion/.test(this.id)&&this.removeAttribute("id")
}),this._destroyIcons(),h=this.headers.next().css("display","").removeAttr("role").removeAttr("aria-expanded").removeAttr("aria-hidden").removeAttr("aria-labelledby").removeClass("ui-helper-reset ui-widget-content ui-corner-bottom ui-accordion-content ui-accordion-content-active ui-state-disabled").each(function(){/^ui-accordion/.test(this.id)&&this.removeAttribute("id")
}),this.options.heightStyle!=="content"&&h.css("height","")
},_setOption:function(j,h){if(j==="active"){this._activate(h);
return
}j==="event"&&(this.options.event&&this._off(this.headers,this.options.event),this._setupEvents(h)),this._super(j,h),j==="collapsible"&&!h&&this.options.active===!1&&this._activate(0),j==="icons"&&(this._destroyIcons(),h&&this._createIcons()),j==="disabled"&&this.headers.add(this.headers.next()).toggleClass("ui-state-disabled",!!h)
},_keydown:function(h){if(h.altKey||h.ctrlKey){return
}var l=f.ui.keyCode,k=this.headers.length,e=this.headers.index(h.target),j=!1;
switch(h.keyCode){case l.RIGHT:case l.DOWN:j=this.headers[(e+1)%k];
break;
case l.LEFT:case l.UP:j=this.headers[(e-1+k)%k];
break;
case l.SPACE:case l.ENTER:this._eventHandler(h);
break;
case l.HOME:j=this.headers[0];
break;
case l.END:j=this.headers[k-1]
}j&&(f(h.target).attr("tabIndex",-1),f(j).attr("tabIndex",0),j.focus(),h.preventDefault())
},_panelKeyDown:function(e){e.keyCode===f.ui.keyCode.UP&&e.ctrlKey&&f(e.currentTarget).prev().focus()
},refresh:function(){var h,k,j=this.options.heightStyle,e=this.element.parent();
j==="fill"?(f.support.minHeight||(k=e.css("overflow"),e.css("overflow","hidden")),h=e.height(),this.element.siblings(":visible").each(function(){var o=f(this),l=o.css("position");
if(l==="absolute"||l==="fixed"){return
}h-=o.outerHeight(!0)
}),k&&e.css("overflow",k),this.headers.each(function(){h-=f(this).outerHeight(!0)
}),this.headers.next().each(function(){f(this).height(Math.max(0,h-f(this).innerHeight()+f(this).height()))
}).css("overflow","auto")):j==="auto"&&(h=0,this.headers.next().each(function(){h=Math.max(h,f(this).height("").height())
}).height(h))
},_activate:function(e){var h=this._findActive(e)[0];
if(h===this.active[0]){return
}h=h||this.active[0],this._eventHandler({target:h,currentTarget:h,preventDefault:f.noop})
},_findActive:function(e){return typeof e=="number"?this.headers.eq(e):f()
},_setupEvents:function(e){var h={};
if(!e){return
}f.each(e.split(" "),function(k,j){h[j]="_eventHandler"
}),this._on(this.headers,h)
},_eventHandler:function(v){var j=this.options,e=this.active,k=f(v.currentTarget),w=k[0]===e[0],h=w&&j.collapsible,q=h?f():k.next(),p=e.next(),l={oldHeader:e,oldPanel:p,newHeader:h?f():k,newPanel:q};
v.preventDefault();
if(w&&!j.collapsible||this._trigger("beforeActivate",v,l)===!1){return
}j.active=h?!1:this.headers.index(k),this.active=w?f():k,this._toggle(l),e.removeClass("ui-accordion-header-active ui-state-active"),j.icons&&e.children(".ui-accordion-header-icon").removeClass(j.icons.activeHeader).addClass(j.icons.header),w||(k.removeClass("ui-corner-all").addClass("ui-accordion-header-active ui-state-active ui-corner-top"),j.icons&&k.children(".ui-accordion-header-icon").removeClass(j.icons.header).addClass(j.icons.activeHeader),k.next().addClass("ui-accordion-content-active"))
},_toggle:function(e){var j=e.newPanel,h=this.prevShow.length?this.prevShow:e.oldPanel;
this.prevShow.add(this.prevHide).stop(!0,!0),this.prevShow=j,this.prevHide=h,this.options.animate?this._animate(j,h,e):(h.hide(),j.show(),this._toggleComplete(e)),h.attr({"aria-expanded":"false","aria-hidden":"true"}),h.prev().attr("aria-selected","false"),j.length&&h.length?h.prev().attr("tabIndex",-1):j.length&&this.headers.filter(function(){return f(this).attr("tabIndex")===0
}).attr("tabIndex",-1),j.attr({"aria-expanded":"true","aria-hidden":"false"}).prev().attr({"aria-selected":"true",tabIndex:0})
},_animate:function(x,B,q){var C,k,A,z=this,w=0,r=x.length&&(!B.length||x.index()<B.index()),y=this.options.animate||{},v=r&&y.down||y,j=function(){z._toggleComplete(q)
};
typeof v=="number"&&(A=v),typeof v=="string"&&(k=v),k=k||v.easing||y.easing,A=A||v.duration||y.duration;
if(!B.length){return x.animate(a,A,k,j)
}if(!x.length){return B.animate(d,A,k,j)
}C=x.show().outerHeight(),B.animate(d,{duration:A,easing:k,step:function(l,h){h.now=Math.round(l)
}}),x.hide().animate(a,{duration:A,easing:k,complete:j,step:function(h,l){l.now=Math.round(h),l.prop!=="height"?w+=l.now:z.options.heightStyle!=="content"&&(l.now=Math.round(C-B.outerHeight()-w),w=0)
}})
},_toggleComplete:function(j){var h=j.oldPanel;
h.removeClass("ui-accordion-content-active").prev().removeClass("ui-corner-top").addClass("ui-corner-all"),h.length&&(h.parent()[0].className=h.parent()[0].className),this._trigger("activate",null,j)
}}),f.uiBackCompat!==!1&&(function(j,h){j.extend(h.options,{navigation:!1,navigationFilter:function(){return this.href.toLowerCase()===location.href.toLowerCase()
}});
var k=h._create;
h._create=function(){if(this.options.navigation){var l=this,o=this.element.find(this.options.header),e=o.next(),n=o.add(e).find("a").filter(this.options.navigationFilter)[0];
n&&o.add(e).each(function(p){if(j.contains(this,n)){return l.options.active=Math.floor(p/2),!1
}})
}k.call(this)
}
}(jQuery,jQuery.ui.accordion.prototype),function(k,h){k.extend(h.options,{heightStyle:null,autoHeight:!0,clearStyle:!1,fillSpace:!1});
var l=h._create,j=h._setOption;
k.extend(h,{_create:function(){this.options.heightStyle=this.options.heightStyle||this._mergeHeightStyle(),l.call(this)
},_setOption:function(n){if(n==="autoHeight"||n==="clearStyle"||n==="fillSpace"){this.options.heightStyle=this._mergeHeightStyle()
}j.apply(this,arguments)
},_mergeHeightStyle:function(){var n=this.options;
if(n.fillSpace){return"fill"
}if(n.clearStyle){return"content"
}if(n.autoHeight){return"auto"
}}})
}(jQuery,jQuery.ui.accordion.prototype),function(j,h){j.extend(h.options.icons,{activeHeader:null,headerSelected:"ui-icon-triangle-1-s"});
var k=h._createIcons;
h._createIcons=function(){this.options.icons&&(this.options.icons.activeHeader=this.options.icons.activeHeader||this.options.icons.headerSelected),k.call(this)
}
}(jQuery,jQuery.ui.accordion.prototype),function(j,h){h.activate=h._activate;
var k=h._findActive;
h._findActive=function(l){return l===-1&&(l=!1),l&&typeof l!="number"&&(l=this.headers.index(this.headers.filter(l)),l===-1&&(l=!1)),k.call(this,l)
}
}(jQuery,jQuery.ui.accordion.prototype),jQuery.ui.accordion.prototype.resize=jQuery.ui.accordion.prototype.refresh,function(j,h){j.extend(h.options,{change:null,changestart:null});
var k=h._trigger;
h._trigger=function(p,n,o){var l=k.apply(this,arguments);
return l?(p==="beforeActivate"?l=k.call(this,"changestart",n,{oldHeader:o.oldHeader,oldContent:o.oldPanel,newHeader:o.newHeader,newContent:o.newPanel}):p==="activate"&&(l=k.call(this,"change",n,{oldHeader:o.oldHeader,oldContent:o.oldPanel,newHeader:o.newHeader,newContent:o.newPanel})),l):!1
}
}(jQuery,jQuery.ui.accordion.prototype),function(j,h){j.extend(h.options,{animate:null,animated:"slide"});
var k=h._create;
h._create=function(){var l=this.options;
l.animate===null&&(l.animated?l.animated==="slide"?l.animate=300:l.animated==="bounceslide"?l.animate={duration:200,down:{easing:"easeOutBounce",duration:1000}}:l.animate=l.animated:l.animate=!1),k.call(this)
}
}(jQuery,jQuery.ui.accordion.prototype))
})(jQuery);
/*!
 * jQuery Cookie Plugin v1.4.1
 * https://github.com/carhartl/jquery-cookie
 *
 * Copyright 2013 Klaus Hartl
 * Released under the MIT license
 */
(function(a){if(typeof define==="function"&&define.amd){define(["jquery"],a)
}else{if(typeof exports==="object"){a(require("jquery"))
}else{a(jQuery)
}}}(function(g){var a=/\+/g;
function e(k){return b.raw?k:encodeURIComponent(k)
}function h(k){return b.raw?k:decodeURIComponent(k)
}function j(k){return e(b.json?JSON.stringify(k):String(k))
}function d(k){if(k.indexOf('"')===0){k=k.slice(1,-1).replace(/\\"/g,'"').replace(/\\\\/g,"\\")
}try{k=decodeURIComponent(k.replace(a," "));
return b.json?JSON.parse(k):k
}catch(l){}}function f(l,k){var n=b.raw?l:d(l);
return g.isFunction(k)?k(n):n
}var b=g.cookie=function(s,r,x){if(r!==undefined&&!g.isFunction(r)){x=g.extend({},b.defaults,x);
if(typeof x.expires==="number"){var u=x.expires,w=x.expires=new Date();
w.setTime(+w+u*86400000)
}return(document.cookie=[e(s),"=",j(r),x.expires?"; expires="+x.expires.toUTCString():"",x.path?"; path="+x.path:"",x.domain?"; domain="+x.domain:"",x.secure?"; secure":""].join(""))
}var y=s?undefined:{};
var v=document.cookie?document.cookie.split("; "):[];
for(var q=0,o=v.length;
q<o;
q++){var p=v[q].split("=");
var k=h(p.shift());
var n=p.join("=");
if(s&&s===k){y=f(n,r);
break
}if(!s&&(n=f(n))!==undefined){y[k]=n
}}return y
};
b.defaults={};
g.removeCookie=function(l,k){if(g.cookie(l)===undefined){return false
}g.cookie(l,"",g.extend({},k,{expires:-1}));
return !g.cookie(l)
}
}));
$(document).ready(function(){if(ua.indexOf("macintosh")>-1&&$("LayoutGrid-1").is(":visible")){document.getElementById("search-support").size="25"
}if(product.indexOf(",")==-1){$(".mnemonic").addClass(product+"-color")
}$("img").each(function(){if($(this).is(":visible")&&$(this).parent().width()>0&&$(this).width()>$(this).parent().width()){$(this).css("width",$(this).parent().width())
}})
});
var adobe=window.adobe||(window.adobe={});
if(typeof adobe.fn==="undefined"){adobe.fn={}
}function toggleShowAll(a){$("."+a+" .hiddenList").toggle();
$("."+a+" .showAllLink").toggle();
$("."+a+" .showLessLink").toggle();
if($("."+a+" .showAllLink").is(":visible")){$("."+a+" a.toggleButton").css("background-image","url(/etc/designs/help/images/showall.png)")
}else{$("."+a+" a.toggleButton").css("background-image","url(/etc/designs/help/images/showless.png)")
}feedbackPodTop=$("#feedbackPod").offset().top-parseFloat($("#feedbackPod").css("margin-top").replace(/auto/,12))
}var productCount=0;
var omtrProductList="";
var omtrTagList="";
var omtrContentType="";
var metaElements=document.all?document.all.tags("meta"):document.getElementsByTagName?document.getElementsByTagName("meta"):new Array();
for(var m=0;
m<metaElements.length;
m++){if(metaElements[m].name=="product"){productCount++;
if(omtrProductList.length>0){omtrProductList=omtrProductList+", "
}omtrProductList=omtrProductList+metaElements[m].content.toLowerCase()
}if(metaElements[m].name=="tag"){if(omtrTagList.length>0){omtrTagList=omtrTagList+": "
}omtrTagList=omtrTagList+metaElements[m].content.toLowerCase()
}if(metaElements[m].name=="content-type"){omtrContentType=metaElements[m].content.toLowerCase()
}}var urlMatch=/(https?:\/\/)([-\w\.]+)+(:\d+)?(\/([\w\/_\.]*))(index.html)?(\?\S+)?(\#\S+)?/;
var adobeMatch=/(https?:\/\/)([-\w\.]+)+(\.adobe\.com)/;
var adobeLocaleMatch=/^\/(africa|at|au|be_en|be_fr|be_nl|bg|br|ca|ca_fr|ch_de|ch_fr|ch_it|cn|cy_en|cz|de|dk|ee|es|fi|fr|gr_en|hk_en|hk_zh|hr|hu|ie|il_en|il_he|in|it|jp|kr|la|lt|lu_de|lu_en|lu_fr|lv|mena_ar|mena_en|mena_fr|mt|mx|nl|no|nz|pl|pt|ro|rs|ru|se|sea|si|sk|tr|tw|ua|uk)\/.+/;
var cqLocaleMatch=/^\/content\/help\/(ae|africa|at|au|be_en|be_fr|be_nl|bg|br|ca|ca_fr|ch_de|ch_fr|ch_it|cn|cy_en|cz|de|dk|ee|es|fi|fr|gr_en|hk_en|hk_zh|hr|hu|ie|il|il_en|in|it|jp|kr|la|lt|lu_de|lu_en|lu_fr|lv|mena_en|mena_fr|mt|mx|nl|no|nz|pl|pt|ro|rs|ru|se|sea|si|sk|tr|tw|ua|uk)\/.+/;
var omtrLocale="en";
if(adobeLocaleMatch.test(location.pathname)){var matchArray=adobeLocaleMatch.exec(location.pathname).slice();
omtrLocale=matchArray[1];
if(typeof(matchArray[1])!="undefined"){omtrLocale=matchArray[1]
}}else{if(cqLocaleMatch.test(location.pathname)){var matchArray=cqLocaleMatch.exec(location.pathname).slice();
omtrLocale=matchArray[1];
if(typeof(matchArray[1])!="undefined"){omtrLocale=matchArray[1]
}}}var adobeGnavInjectCSS=true;
var ua=navigator.userAgent.toLowerCase();
if(typeof(adobe)=="undefined"){var adobe={Idiom:{Localize:function(a){return a
}}}
}else{adobe.Idiom={Localize:function(a){return a
}}
}var productCount=0;
var omtrProductList="";
var metaElements=document.all?document.all.tags("meta"):document.getElementsByTagName?document.getElementsByTagName("meta"):new Array();
for(var m=0;
m<metaElements.length;
m++){if(metaElements[m].name=="product"){productCount++;
if(omtrProductList.length>0){omtrProductList=omtrProductList+", "
}omtrProductList=omtrProductList+metaElements[m].content
}else{if(metaElements[m].name=="docid"){docid=metaElements[m].content
}}}var jaaulde=window.jaaulde||{};
jaaulde.utils=jaaulde.utils||{};
jaaulde.utils.cookies=(function(){var f,e,d,b,a={expiresAt:null,path:"/",domain:null,secure:false};
f=function(h){var j,g;
if(typeof h!=="object"||h===null){j=a
}else{j={expiresAt:a.expiresAt,path:a.path,domain:a.domain,secure:a.secure};
if(typeof h.expiresAt==="object"&&h.expiresAt instanceof Date){j.expiresAt=h.expiresAt
}else{if(typeof h.hoursToLive==="number"&&h.hoursToLive!==0){g=new Date();
g.setTime(g.getTime()+(h.hoursToLive*60*60*1000));
j.expiresAt=g
}}if(typeof h.path==="string"&&h.path!==""){j.path=h.path
}if(typeof h.domain==="string"&&h.domain!==""){j.domain=h.domain
}if(h.secure===true){j.secure=h.secure
}}return j
};
e=function(g){g=f(g);
return((typeof g.expiresAt==="object"&&g.expiresAt instanceof Date?"; expires="+g.expiresAt.toGMTString():"")+"; path="+g.path+(typeof g.domain==="string"?"; domain="+g.domain:"")+(g.secure===true?"; secure":""))
};
d=function(){var q={},j,h,g,p,l=document.cookie.split(";"),k;
for(j=0;
j<l.length;
j=j+1){h=l[j].split("=");
g=h[0].replace(/^\s*/,"").replace(/\s*$/,"");
try{p=decodeURIComponent(h[1])
}catch(o){p=h[1]
}if(typeof JSON==="object"&&JSON!==null&&typeof JSON.parse==="function"){try{k=p;
p=JSON.parse(p)
}catch(n){p=k
}}q[g]=p
}return q
};
b=function(){};
b.prototype.get=function(k){var g,j,h=d();
if(typeof k==="string"){g=(typeof h[k]!=="undefined")?h[k]:null
}else{if(typeof k==="object"&&k!==null){g={};
for(j in k){if(typeof h[k[j]]!=="undefined"){g[k[j]]=h[k[j]]
}else{g[k[j]]=null
}}}else{g=h
}}return g
};
b.prototype.filter=function(g){var k,h={},j=d();
if(typeof g==="string"){g=new RegExp(g)
}for(k in j){if(k.match(g)){h[k]=j[k]
}}return h
};
b.prototype.set=function(k,h,g){if(typeof g!=="object"||g===null){g={}
}if(typeof h==="undefined"||h===null){h="";
g.hoursToLive=-8760
}else{if(typeof h!=="string"){if(typeof JSON==="object"&&JSON!==null&&typeof JSON.stringify==="function"){h=JSON.stringify(h)
}else{throw new Error("cookies.set() received non-string value and could not serialize.")
}}}var j=e(g);
document.cookie=k+"="+encodeURIComponent(h)+j
};
b.prototype.del=function(k,j){var g={},h;
if(typeof j!=="object"||j===null){j={}
}if(typeof k==="boolean"&&k===true){g=this.get()
}else{if(typeof k==="string"){g[k]=true
}}for(h in g){if(typeof h==="string"&&h!==""){this.set(h,null,j)
}}};
b.prototype.test=function(){var h=false,g="cT",j="data";
this.set(g,j);
if(this.get(g)===j){this.del(g);
h=true
}return h
};
b.prototype.setOptions=function(g){if(typeof g!=="object"){g=null
}a=f(g)
};
return new b()
})();
URLParser=(function(){var l=window.location.toString();
var b=new Array();
var a=new Array();
b=l.split("//");
a=b[1].split("/");
var e=a[0].split(".")[0];
var k=a[1];
k=((k.length==2)||(k=="ca_fr")||(k=="africa")||(k=="be_en")||(k=="be_fr")||(k=="be_nl")||(k=="eeurope")||(k=="il_en")||(k=="il_he")||(k=="lu_de")||(k=="lu_en")||(k=="lu_fr")||(k=="mena_ar")||(k=="mena_fr")||(k=="ch_de")||(k=="ch_fr")||(k=="ch_it")||(k=="hk_zh")||(k=="hk_en")||(k=="sea"))?k:"en_us";
if(k=="en_us"){a.splice(1,0,k)
}var g=a[2];
var j=a[3];
var n=(g=="products")?product=a[3]:"";
var f=a[4];
var o=(g=="products")?product=a[4]:"";
var h=(g=="products")?product=a[5]:"";
var d;
$.each(a,function(p){});
return{url:window.location,path:window.location.pathname,protocol:window.location.protocol,hash:window.location.hash,subDomain:e,host:a[0],locale:k,siteLevel:g,siteSection:j,productName:n,siteSubSection:f,productSection:o,productSubSection:h,fileName:d}
})();
var droidDeviceProfile={id:"Motorola Droid",frag:/droid build/};
var nexusDeviceProfile={id:"Google Nexus One",frag:/Android 2/i};
var palmPreDeviceProfile={id:"Palm Pre",frag:/525.27.1 pre/i};
var genericAndroid2DeviceProfile={id:"Generic Android 2 device",frag:/Android 2/i};
var genericAndroid1DeviceProfile={id:"Generic Android 1 device",frag:/Android 1/i};
var genericWebOSDeviceProfile={id:"genericWebOS Device",frag:/webos/i};
var win311DeviceProfile={id:"Windows 3.11",frag:/win16/i};
var win95ADeviceProfile={id:"Windows 95",frag:/windows 95/i};
var win95BDeviceProfile={id:"Windows 95",frag:/win95/i};
var win95CDeviceProfile={id:"Windows 95",frag:/win_95/i};
var win2000ADeviceProfile={id:"Windows 2000",frag:/windows 2000/i};
var win2000BDeviceProfile={id:"Windows 2000",frag:/windows nt 5.0/i};
var winServer2003DeviceProfile={id:"Windows Server 2003",frag:/windows nt 5.2/i};
var winNT40ADeviceProfile={id:"Windows NT 4.0",frag:/windows nt 4.0/i};
var winNT40BDeviceProfile={id:"Windows NT 4.0",frag:/winnt/i};
var winNT40CDeviceProfile={id:"Windows NT 4.0",frag:/windows nt/i};
var winmeDeviceProfile={id:"Windows ME",frag:/windows me/i};
var openBSDDeviceProfile={id:"OpenBSD",frag:/openbsd/i};
var sunOSDeviceProfile={id:"Sun OS",frag:/sunos/i};
var linuxADeviceProfile={id:"Linux",frag:/linux/i};
var linuxBDeviceProfile={id:"Linux",frag:/x11/i};
var QNXDeviceProfile={id:"QNX",frag:/qnx/i};
var beosDeviceProfile={id:"BeOS",frag:/beos/i};
var os2DeviceProfile={id:"OS2",frag:/OS\/2/i};
var winxpDeviceProfile={id:"Windows XP",frag:/windows xp/i};
var winxp2DeviceProfile={id:"Windows XP",frag:/windows nt 5.1/i};
var win7ADeviceProfile={id:"Windows 7",frag:/windows nt 6.1/i};
var win7BDeviceProfile={id:"Windows 7",frag:/windows nt 7.01/i};
var winvistaDeviceProfile={id:"Windows Vista",frag:/windows nt 6.0/i};
var macosx106DeviceProfile={id:"Snow Leopard",frag:/mac os x 10.6/i};
var macosx105DeviceProfile={id:"Leopard",frag:/mac os x 10.5/i};
var macosA={id:"Mac OS",frag:/mac_powerpc/i};
var macosB={id:"Mac OS",frag:/macintosh/i};
var androidOSFamily={id:"Android OS",frag:/android /i,devices:[droidDeviceProfile,nexusDeviceProfile,genericAndroid1DeviceProfile,genericAndroid2DeviceProfile]};
var webOSFamily={id:"webOS",frag:/webOS\/1.3.5/i,devices:[palmPreDeviceProfile,genericWebOSDeviceProfile]};
var macOSFamily={id:"Mac OS",frag:/mac os/i,devices:[macosx105DeviceProfile,macosx106DeviceProfile,macosA,macosB]};
var winOSFamily={id:"Windows",frag:/windows/i,devices:[winxpDeviceProfile,winxp2DeviceProfile,win7ADeviceProfile,win7BDeviceProfile,winvistaDeviceProfile,win311DeviceProfile,win95ADeviceProfile,win95BDeviceProfile,win95CDeviceProfile,winServer2003DeviceProfile,winNT40ADeviceProfile,winNT40BDeviceProfile,winNT40CDeviceProfile,winmeDeviceProfile]};
var linuxOSFamily={id:"Linux",frag:/linux/i,devices:[openBSDDeviceProfile,sunOSDeviceProfile,linuxADeviceProfile,linuxBDeviceProfile,QNXDeviceProfile,beosDeviceProfile,os2DeviceProfile]};
var desktopDeviceCategory={id:"Desktop",osFamilies:[macOSFamily,winOSFamily,linuxOSFamily]};
var mobileDeviceCategory={id:"Mobile",osFamilies:[androidOSFamily,webOSFamily]};
var unknownDeviceCategory={id:"Unidentified Platform"};
var categories=[mobileDeviceCategory,desktopDeviceCategory];
function identifyDevice(b,a){if(a.search(b.frag)>-1){return{device:b.id}
}else{return null
}}function identifyOS(d,b){var f=null;
var e=d.devices.length;
for(var a=0;
a<e;
a++){f=identifyDevice(d.devices[a],b);
if(f!=null){break
}}if(f!=null){f.os=d.id
}return f
}function identifyCategory(a,f){var e=null;
var b=a.osFamilies.length;
for(var d=0;
d<b;
d++){e=identifyOS(a.osFamilies[d],f);
if(e!=null){break
}}if(e!=null){e.category=a.id
}return e
}function identifyCategories(d,f){var b=null;
var a=d.length;
for(var e=0;
e<a;
e++){b=identifyCategory(d[e],f);
if(b!=null){break
}}if(!b){b={}
}if(!b.device){b.device="unknown"
}if(!b.os){b.os="unknown"
}if(!b.category){b.category=unknownDeviceCategory.id
}return b
}function getCategoriesInfo(){return identifyCategories(categories,navigator.userAgent.toLowerCase())
}var info=getCategoriesInfo();
function displayCategoriesInfo(){alert("isDesktop:"+isDesktop()+", os:"+info.os+", device:"+info.device)
}function isDroid(){return(info.device==droidDeviceProfile.id)
}function isNexus(){return(info.device==nexusDeviceProfile.id)
}function isDesktop(){return(info.category==desktopDeviceCategory.id)
}function isLinuxDesktop(){return(info.os==linuxOSFamily.id)
}function isWinDesktop(){return(info.os==winOSFamily.id)
}function isMacDesktop(){return(info.os==macOSFamily.id)
}function simulateDroid(){info.device=droidDeviceProfile.id;
info.category=mobileDeviceCategory.id;
info.os=androidOSFamily.id
}adobe.fn.initGlobalFooter=function(){$.cookies=jaaulde.utils.cookies;
var a=$.cookies.get("international");
if(a){$("#sfRegionSet").show();
$("#sfRegion").hide()
}else{$("#sfRegionSet").hide();
$("#sfRegion").show()
}if(isDesktop()){$("#RegionPanel").bind("clickoutside focusout",function(){$("#RegionPanel").hide()
});
$("#sfRegion, #sfRegionChange, #sfRegionClose").bind("click",function(){$("#RegionPanel").toggle();
if($("#SiteHeader")!=null){$("#WelcomePanel").hide();
$("#WelcomePanelShadow").hide()
}return false
})
}};
adobe.fn.evidon=function(f){var j=$("#"+f),h=document,e,b,a=(h.location.protocol=="https:"?"https":"http"),g=(a=="https"?"https://info.evidon.com/c/betrad/pub/":"http://cdn.betrad.com/pub/");
if((j!=null)&&(hideEvidon!=true)&&isDesktop()){j.show();
if((URLParser.host=="www.adobe.com")||(URLParser.host=="adobe.com")||(URLParser.host=="get.adobe.com"||(URLParser.host=="get2.adobe.com")||(URLParser.host=="get3.adobe.com"))||(URLParser.host=="kb2.adobe.com")||(URLParser.host=="community.adobe.com")||(URLParser.host=="helpx.adobe.com")||(URLParser.host=="store1.adobe.com")||(URLParser.host=="store2.adobe.com")||(URLParser.host=="store3.adobe.com")){if(URLParser.locale=="de"){b="322"
}else{if(URLParser.locale=="fr"){b="324"
}else{if(URLParser.locale=="uk"){b="323"
}else{if(URLParser.locale=="se"){b="1013"
}else{if(URLParser.locale=="at"){b="1012"
}else{if(URLParser.locale=="ch_de"){b="1010"
}else{if(URLParser.locale=="ch_fr"){b="1009"
}else{if(URLParser.locale=="ch_it"){b="1011"
}else{b="86"
}}}}}}}}}else{if(URLParser.locale=="de"){b="327"
}else{if(URLParser.locale=="fr"){b="326"
}else{if(URLParser.locale=="uk"){b="328"
}else{if(URLParser.locale=="se"){b="1024"
}else{if(URLParser.locale=="at"){b="1021"
}else{if(URLParser.locale=="ch_de"){b="1020"
}else{if(URLParser.locale=="ch_fr"){b="1022"
}else{if(URLParser.locale=="ch_it"){b="1023"
}else{b="126"
}}}}}}}}}j.bind("click",function(l){l.preventDefault();
var k=this;
function d(p,s){var q=h.getElementsByTagName("head")[0]||h.documentElement,o=false,n=h.createElement("script");
function r(){n.onload=n.onreadystatechange=null;
q.removeChild(n);
s()
}n.src=p;
n.onreadystatechange=function(){if(!o&&(this.readyState=="loaded"||this.readyState=="complete")){o=true;
r()
}};
n.onload=r;
q.insertBefore(n,q.firstChild)
}d(a+"://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.min.js",function(){d(g+"pub1.js",function(){BAPW.i(k,{pid:b,ocid:414},false)
})
})
});
e=h.createElement("img");
e.src=a+"://l.betrad.com/pub/p.gif?pid="+b+"&ocid=414&ii=1&r="+Math.random();
e.height="1";
e.width="1";
e.className="SiteFooterEvidonPixel";
h.body.appendChild(e)
}};
adobe.fn.changeRegionFooter=function(b){if(b.indexOf("be_")==0){setRegionCookie("international",b);
setRegionCookie("storeregion","be")
}else{if(b.indexOf("ca")==0){setRegionCookie("international",b);
setRegionCookie("storeregion","ca")
}else{if(b.indexOf("eeur")==0){setRegionCookie("international",b);
setRegionCookie("storeregion","eu")
}else{if(b.indexOf("hk_")==0){setRegionCookie("international",b);
setRegionCookie("storeregion","cn")
}else{if(b.indexOf("lu_")==0){setRegionCookie("international",b);
setRegionCookie("storeregion","lu")
}else{if(b.indexOf("uk")==0){setRegionCookie("international",b);
setRegionCookie("storeregion","gb")
}else{setRegionCookie("international",b);
setRegionCookie("storeregion",b)
}}}}}}var a=window.location.pathname+window.location.search;
if(a.indexOf("/content/dotcom/")==0){a=a.replace("/content/dotcom/","/")
}else{if(a.indexOf("/content/help/")==0){a=a.replace("/content/help/","/")
}}if(a.indexOf("/en/")==0){a=a.replace("/en/","/")
}var d=a;
var f=null;
var e=["africa","ap","at","au","gr_en","mt","cy_en","be_en","be_fr","be_nl","bg","br","ca","ca_fr","ch_de","ch_fr","ch_it","cn","cz","de","dk","eeurope","ee","en","es","fi","fr","hk_en","hk_zh","hr","hu","ie","il_en","il_he","in","it","jp","kr","la","lt","lu_de","lu_en","lu_fr","lv","mena_ar","mena_en","mena_fr","mx","nl","no","nz","pl","pt","ro","ru","si","se","sea","sk","tr","tw","ua","uk"];
$.each(e,function(){if(a.indexOf("/"+this+"/")==0){a=a.replace("/"+this+"/","/");
return false
}});
if(b!="us"){d="/"+b+a
}else{d=a
}if(fallbackLocales[b]!=undefined){f=d.replace("/"+b+"/","/"+fallbackLocales[b]+"/")
}changeRegionRedirect(d,f)
};
function clearDocRegionCookie(){var b=new Date();
b.setTime(b.getTime()+(365*24*60*60*1000));
var a="expires="+b.toGMTString();
document.cookie="international=; path="+document.location.pathname+"; domain=.adobe.com; "+a
}function setRegionCookie(b,e){var f=new Date();
f.setTime(f.getTime()+(365*24*60*60*1000));
var a="expires="+f.toGMTString();
document.cookie=b+"="+e+"; path=/; domain=.adobe.com; "+a
}function changeRegionRedirect(a,b){if((a!=null)&&(a.length>0)&&(a.indexOf(document.location.pathname)!=0)){$.ajax({type:"HEAD",url:a,success:function(){window.location.replace(a)
},error:function(){if((b!=null)&&(b.length>0)&&(b.indexOf(document.location.pathname)!=0)){$.ajax({type:"HEAD",url:b,success:function(){window.location.replace(b)
},error:function(){clearDocRegionCookie()
}})
}else{clearDocRegionCookie()
}}})
}}var locales={africa:true,at:true,au:true,be_en:true,be_fr:true,be_nl:true,bg:true,br:true,ca:true,ca_fr:true,ch_de:true,ch_fr:true,ch_it:true,cn:true,cz:true,de:true,dk:true,ee:true,eeurope:true,us:true,es:true,fi:true,fr:true,hk_en:true,hk_zh:true,hr:true,hu:true,ie:true,il_en:true,il_he:true,"in":true,it:true,kr:true,la:true,lt:true,lu_de:true,lu_en:true,lu_fr:true,lv:true,mena_ar:true,mena_en:true,mena_fr:true,mx:true,nl:true,no:true,nz:true,pl:true,pt:true,ro:true,rs:true,ru:true,se:true,sea:true,si:true,sk:true,tr:true,tw:true,ua:true,uk:true,jp:true};
var fallbackLocales={hk_zh:"tw",sea:"uk",ap:"uk",eeurope:"uk",mena_en:"uk",africa:"uk",il_en:"uk",au:"uk",be_en:"uk",ca:"uk",hk_en:"uk","in":"uk",ie:"uk",lu_en:"uk",nz:"uk",ca_fr:"fr",mena_fr:"fr",be_fr:"fr",ch_fr:"fr",lu_fr:"fr",at:"de",ch_de:"de",lu_de:"de",ch_it:"it",la:"es",mx:"es"};
var tokens=document.location.pathname.split("/");
var locale=((tokens.length<2)||((locales[tokens[1]]==undefined)&&tokens[1]!="content"))?"us":tokens[1];
var geoCook="international=";
var cookies=document.cookie.split(";");
for(var i=0;
i<cookies.length;
i++){var c=cookies[i];
if((c.indexOf(geoCook)>=0)&&!(locale=="content")){var preferredLocale=c.substring(c.indexOf(geoCook)+geoCook.length,c.length);
if((preferredLocale!=locale)&&(locales[preferredLocale])){var url=document.location.pathname+document.location.search;
var fallbackUrl=null;
if(locale=="us"){url="/"+preferredLocale+url
}else{var suffix=url.substring(locale.length+1);
if((suffix==null)||(suffix=="")){suffix="/"
}if(preferredLocale!="us"){url="/"+preferredLocale+suffix
}else{url=suffix
}}if(fallbackLocales[preferredLocale]!=undefined&&fallbackLocales[preferredLocale]!=locale){fallbackUrl=url.replace("/"+preferredLocale+"/","/"+fallbackLocales[preferredLocale]+"/")
}}}}(function($){$.extend({__stringPrototype:function(str){var splitCheck=("a b".split(/\w/)[0]==" ");
function makeRegExpGlobal(p){if(!p.source){return p
}var mods="g"+((p.ignoreCase)?"i":"")+((p.multiline)?"m":"");
return new RegExp(p.source,mods)
}this.str=str;
this.JSONFilter=/^\/\*-secure-([\s\S]*)\*\/\s*$/;
this.ScriptFragment="<script[^>]*>([\\S\\s]*?)<\/script>";
this.specialChar={"\b":"\\b","\t":"\\t","\n":"\\n","\f":"\\f","\r":"\\r","\\":"\\\\"};
this.blank=function(s){return/^\s*$/.test(this.s(s)||" ")
};
this.camelize=function(s){var a=this.s(s).split("-"),i;
s=[a[0]];
for(i=1;
i<a.length;
i++){s.push(a[i].charAt(0).toUpperCase()+a[i].substring(1))
}this.str=s.join("");
return this
};
this.capitalize=function(s){s=this.s(s);
this.str=s.charAt(0).toUpperCase()+s.substring(1).toLowerCase();
return this
};
this.dasherize=function(s){this.str=this.s(s).split("_").join("-");
return this
};
this.empty=function(s){return(s)?(s==""):(this.str=="")
};
this.endsWith=function(pattern,s){s=this.s(s);
var d=s.length-pattern.length;
return d>=0&&s.lastIndexOf(pattern)===d
};
this.escapeHTML=function(s){this.str=this.s(s).split("&").join("&amp;").split("<").join("&lt;").split(">").join("&gt;");
return this
};
this.evalJSON=function(sanitize,s){s=this.s(s);
var json=this.unfilterJSON(false,s).str;
try{if(!sanitize||this.isJSON(json)){return eval("("+json+")")
}}catch(e){}throw new SyntaxError("Badly formed JSON string: "+s)
};
this.evalScripts=function(s){var scriptTags=this.extractScripts(this.s(s)),results=[];
if(scriptTags.length>0){for(var i=0;
i<scriptTags.length;
i++){results.push(eval(scriptTags[i]))
}}return results
};
this.extractScripts=function(s){var matchAll=new RegExp(this.ScriptFragment,"img"),matchOne=new RegExp(this.ScriptFragment,"im"),scriptMatches=this.s(s).match(matchAll)||[],scriptTags=[];
if(scriptMatches.length>0){for(var i=0;
i<scriptMatches.length;
i++){scriptTags.push(scriptMatches[i].match(matchOne)[1]||"")
}}return scriptTags
};
this.gsub=function(pattern,replacement,s){s=this.s(s);
if($.isFunction(replacement)){var match=s.match(makeRegExpGlobal(pattern));
if(match==null){return this
}s=this.sub(pattern,replacement,match.length,s).str
}else{s=s.split(pattern).join(replacement)
}this.str=s;
return this
};
this.include=function(pattern,s){return this.s(s).indexOf(pattern)>-1
};
this.inspect=function(useDoubleQuotes,s){s=this.s(s);
var specialChar=this.specialChar,escapedString=this.gsub(/[\x00-\x1f\\]/,function(match){var character=specialChar[match[0]];
return character?character:"\\u00"+match[0].charCodeAt().toPaddedString(2,16)
},s).str;
this.str=(useDoubleQuotes)?'"'+escapedString.replace(/"/g,'\\"')+'"':"'"+escapedString.replace(/'/g,"\\'")+"'";
return this
};
this.interpolate=function(obj,pattern,s){s=this.s(s);
if(!pattern){pattern=/(^|.|\r|\n)(\#\{\s*(\w+)\s*\})/
}var count=0,length=s.length,match;
while(pattern.match(s)&&count++<length){match=pattern.exec(s);
s=this.gsub(match[2],obj[match[3]],s).str
}this.str=s;
return this
};
this.isJSON=function(s){s=this.s(s);
if(this.blank(s)){return false
}s=s.replace(/\\./g,"@").replace(/"[^"\\\n\r]*"/g,"");
return(/^[,:{}\[\]0-9.\-+Eaeflnr-u \n\r\t]*$/).test(s)
};
this.scan=function(pattern,replacement,s){s=this.s(s);
this.gsub(pattern,replacement,s).str=s;
return this
};
this.startsWith=function(pattern,s){return this.s(s).indexOf(pattern)===0
};
this.strip=function(s){this.str=$.trim(this.s(s));
return this
};
this.stripScripts=function(s){this.str=this.s(s).replace(new RegExp(this.ScriptFragment,"img"),"");
return this
};
this.stripTags=function(s){this.str=this.s(s).replace(/<\/?[^>]+>/gi,"");
return this
};
this.sub=function(pattern,replacement,count,s){s=this.s(s);
count=(!count)?1:count;
if(count<0||isNaN(count)){return this
}pattern=makeRegExpGlobal(pattern);
var sarray=s.split(pattern),matches=s.match(pattern);
if(splitCheck&&typeof(pattern)=="object"){if(count==matches.length){++count
}if(s.indexOf(matches[0])==0){sarray.unshift("")
}if(s.lastIndexOf(matches[matches.length-1])==s.length-matches[matches.length-1].length){sarray.push("")
}}s=sarray[0];
for(var i=1;
i<sarray.length;
i++){if(i<=count){if($.isFunction(replacement)){s+=replacement(matches[i-1]||matches)+sarray[i]
}else{s+=replacement+sarray[i]
}}else{s+=(matches[i-1]||matches)+sarray[i]
}}this.str=s;
return this
};
this.succ=function(s){s=this.s(s);
this.str=s.slice(0,s.length-1)+String.fromCharCode(s.charCodeAt(s.length-1)+1);
return this
};
this.times=function(count,s){this.str=count<1?"":(new Array(count+1)).join(this.s(s));
return this
};
this.toJSON=function(s){return this.inspect(true,this.s(s))
};
this.toQueryParams=function(separator,s){s=this.s(s);
var paramsList=s.substring(s.indexOf("?")+1).split("#")[0].split(separator||"&"),params={},i,key,value,pair;
for(i=0;
i<paramsList.length;
i++){pair=paramsList[i].split("=");
key=decodeURIComponent(pair[0]);
value=(pair[1])?decodeURIComponent(pair[1]):undefined;
if(params[key]){if(typeof params[key]=="string"){params[key]=[params[key]]
}params[key].push(value)
}else{params[key]=value
}}return params
};
this.truncate=function(length,truncation,s){s=this.s(s);
length=length||30;
truncation=(!truncation)?"...":truncation;
s=(s.length>length)?s.slice(0,length-truncation.length)+truncation:String(s);
this.str=s;
return this
};
this.underscore=function(s){this.gsub(/[A-Z]/,function(m){return"_"+m.toLowerCase()
},this.s(s));
if(this.str.substring(0,1)=="_"){this.str=this.str.substring(1)
}return this
};
this.unescapeHTML=function(s){this.str=this.stripTags(this.s(s)).str.replace(/&amp;/g,"&").replace(/&lt;/g,"<").replace(/&gt;/g,">");
return this
};
this.unfilterJSON=function(filter,s){s=this.s(s);
filter=filter||this.JSONFilter;
var filtered=s.match(filter);
this.str=(filtered!==null)?filtered[1]:s;
return this
};
this.value=function(){return this.str
};
this.s=function(s){return(s)?s:this.str
}
},string:function(str){if(str===String.prototype){$.extend(String.prototype,new $.__stringPrototype())
}else{return new $.__stringPrototype(str)
}}});
$.__stringPrototype.parseQuery=$.__stringPrototype.toQueryParams
})(jQuery);
function getExternalLoadBalancer(){if(window.location.hostname.indexOf("dev02")>-1){return"https://helpx.dev02.adobe.com"
}else{if(window.location.hostname.indexOf("dev")>-1){return"https://helpx.dev.adobe.com"
}else{if(window.location.hostname.indexOf("qa")>-1){return"https://helpx.qa.adobe.com"
}else{if(window.location.hostname.indexOf("stage")>-1){return"https://helpx.stage.adobe.com"
}else{return"https://helpx.adobe.com"
}}}}}function getFolderLocale(){var b=["africa","ap","at","au","be_en","be_fr","be_nl","bg","br","ca","ca_fr","ch_de","ch_fr","ch_it","cis","cn","cy_en","cz","de","dk","eeurope","ee","en","es","fi","fr","gr_en","hk_en","hk_zh","hr","hu","ie","il_en","il_he","in","it","jp","kr","la","lt","lu_de","lu_en","lu_fr","lv","mena_ar","mena_en","mena_fr","mt","mx","nl","no","nz","pl","pt","ro","ru","rs","si","se","sea","sk","tr","tw","ua","uk"];
var a="/";
$.each(b,function(){if((window.location.pathname).indexOf("/"+this+"/")>-1){a="/"+this+"/";
return false
}});
return a
}var coveoSearchEndpoint=getExternalLoadBalancer()+getFolderLocale()+"search.html";
var useCoveoSearch=false;
function submitSearchForm(){if(location.hostname.indexOf("internal")!=-1){$("#searchform-product").attr("value",product);
$("#searchform-loc").attr("value",pageLanguage)
}else{$("#searchform-q").attr("value",encodeURIComponent($("#search-support").val()));
$("#searchform-lbl").attr("value",product);
$("#searchform-x").attr("value","0");
$("#searchform-y").attr("value","0");
$("#searchform-area").attr("value","1");
$("form#searchform div.SearchBox div.SearchInputBox").append('<input type="hidden" id="site" name="site" value="'+product+'_all">')
}}function submitCoveoSearchForm(){if($("#search-support").val()==""){return false
}else{var b="#q="+$("#search-support").val();
var d=$('meta[name="primaryProductName"]').attr("content");
if(typeof d!=="undefined"){d="&CommonProduct="+d
}else{d=""
}var a=coveoSearchEndpoint+b+d;
window.location.href=a;
return false
}}$(document).ready(function(){if(!(location.hostname.indexOf("internal")!=-1)){$("form#searchform").attr("action","//www.adobe.com/cfusion/search/proxy/ion_proxy.cfm")
}loadCoveoAbTestSearch(useCoveoSearch)
});
function loadCoveoAbTestSearch(a){if(typeof a!=="undefined"&&a==true){$("#searchform").attr("onsubmit","return submitCoveoSearchForm()");
$("form#searchform").attr("action",coveoSearchEndpoint);
$("#searchform-q").remove();
$("#searchform-lbl").remove();
$("#searchform-x").remove();
$("#searchform-y").remove();
$("#searchform-area").remove();
$("#searchform-lr").remove();
$("#searchform-hl").remove();
$("#search-support").removeAttr("name")
}}CHL_IMS={current_user_token:"none",page_language:"",imsURL:(document.location.hostname.indexOf("helpx.adobe.com")==0)?"https://adobeid-na1.services.adobe.com":"https://adobeid-na1-stg1.services.adobe.com",signInLoc:"https://www.adobe.com/account/sign-in.adobedotcom.html?returnURL=",ccRedirectLoc:"https://helpx.adobe.com/creative-cloud/topics/getting-started.html",teamPage:"creative-cloud/team/creative-cloud-teams.html",redirectPage:"creative-cloud/topics/getting-started.html",clientId:"CHLCC1",authenticate_user:function(e,b){var a=CHL_IMS.get_cookie("WCDServer")||"none";
var d=CHL_IMS.get_cookie("chl_u_t")||"none";
var h=CHL_IMS.get_cookie("chl_u_l")||"none";
var g=CHL_IMS.get_cookie("chl_u_tm")||"none";
if(a!="none"&&a==d&&(h=="lvl2"||h=="lvl1"||h=="none")){if(g=="none"){CHL_IMS.check_user_profile(e,b)
}else{if(g=="yes"&&b=="ccTeam"){$("#maincontent").attr("style","visibility:visible")
}else{if(g=="no"&&b=="ccTeam"){CHL_IMS.signinWithAdobeId(CHL_IMS.ccRedirectLoc)
}else{if(g=="no"&&b=="ccTeamRedirect"){$("#maincontent").attr("style","visibility:visible")
}else{if(h=="lvl1"){CHL_IMS.signinWithAdobeId(CHL_IMS.ccRedirectLoc)
}else{if(h=="none"){CHL_IMS.check_user_profile(e,b)
}else{$(".page_training").attr("style","visibility:visible")
}}}}}}}else{if(a!="none"){if(d=="none"||d!=a){CHL_IMS.current_user_token=a;
CHL_IMS.set_cookie("chl_u_t",a);
CHL_IMS.check_user_profile(e,b)
}}else{if(a=="none"){CHL_IMS.check_user_profile(e,b);
var f=CHL_IMS.get_cookie("WCDServer")||"none";
CHL_IMS.set_cookie("chl_u_t",f);
CHL_IMS.current_user_token=f
}}}},set_configs:function(b){var d=document.location.pathname;
if(d.charAt("3")=="/"){CHL_IMS.page_language=d.substring(1,3)+"/"
}else{if(d.charAt("4")=="/"){CHL_IMS.page_language=d.substring(1,4)+"/"
}}var f="http://helpx.adobe.com/";
if(b=="ccTeamRedirect"){CHL_IMS.ccRedirectLoc=f+CHL_IMS.page_language+CHL_IMS.teamPage
}else{CHL_IMS.ccRedirectLoc=f+CHL_IMS.page_language+CHL_IMS.redirectPage
}CHL_IMS.signInLoc="https://www.adobe.com/"+CHL_IMS.page_language+"account/sign-in.adobedotcom.html?returnURL=";
if(document.URL.indexOf(".stage.")>0||document.URL.indexOf(".qa.")>0){CHL_IMS.imsURL="https://adobeid-na1-stg1.services.adobe.com";
CHL_IMS.signInLoc="https://www.stage.adobe.com/"+CHL_IMS.page_language+"account/sign-in.adobedotcom.html?returnURL=";
var a="http://helpx.qa.adobe.com/";
var e="http://helpx.stage.adobe.com/";
if(b=="ccTeamRedirect"){CHL_IMS.ccRedirectLoc=e+CHL_IMS.page_language+CHL_IMS.teamPage
}else{CHL_IMS.ccRedirectLoc=e+CHL_IMS.page_language+CHL_IMS.redirectPage
}if(document.URL.indexOf(".qa.")>0){if(b=="ccTeamRedirect"){CHL_IMS.ccRedirectLoc=a+CHL_IMS.page_language+CHL_IMS.teamPage
}else{CHL_IMS.ccRedirectLoc=a+CHL_IMS.page_language+CHL_IMS.redirectPage
}}}},check_user_profile:function(f,b){CHL_IMS.set_configs(b);
$.support.cors=true;
var d=document.URL;
var a=CHL_IMS.get_cookie("WCDServer")||"none";
if(a=="none"&&b=="ccTeamRedirect"){$("#maincontent").attr("style","visibility:visible")
}else{var e=$.ajax({url:CHL_IMS.imsURL+"/ims/check/v1/token?client_id="+CHL_IMS.clientId+"&scope=openid%2Ccreative_cloud%2Cread_organizations",type:"GET",dataType:"jsonp"});
e.done(function(n){try{var h=n.name;
var l=f;
if(typeof h=="undefined"){CHL_IMS.signinWithAdobeId(d)
}else{var g=(n.serviceAccounts&&n.serviceAccounts[0])?n.serviceAccounts[0].serviceLevel:null;
if(g!=null){if((l.indexOf("free")!=-1)&&g=="CS_LVL_1"){CHL_IMS.set_cookie("chl_u_l","lvl1");
CHL_IMS.signinWithAdobeId(CHL_IMS.ccRedirectLoc)
}else{if((l.indexOf("paid")!=-1)&&g=="CS_LVL_1"){CHL_IMS.set_cookie("chl_u_l","lvl1");
CHL_IMS.signinWithAdobeId(CHL_IMS.ccRedirectLoc)
}else{if((l.indexOf("paid")!=-1)&&g=="CS_LVL_2"){CHL_IMS.set_cookie("chl_u_l","lvl2");
$(".page_training").attr("style","visibility:visible")
}else{if(l.indexOf("team")!=-1){var j=n.access_token;
$.ajax({url:CHL_IMS.imsURL+"/ims/organizations/v1?bearer_token="+j+"&client_id="+CHL_IMS.clientId,type:"GET",dataType:"jsonp",success:function(p){var o=p.orgs||[];
if(o.length==0){CHL_IMS.set_cookie("chl_u_tm","no");
if(l.indexOf("team_redirect")>-1){$("#maincontent").attr("style","visibility:visible")
}else{if(l.indexOf("team_member")>-1){CHL_IMS.signinWithAdobeId(CHL_IMS.ccRedirectLoc)
}}}else{CHL_IMS.set_cookie("chl_u_tm","yes");
if(l.indexOf("team_redirect")>-1){CHL_IMS.signinWithAdobeId(CHL_IMS.ccRedirectLoc)
}else{if(l.indexOf("team_member")>-1){$("#maincontent").attr("style","visibility:visible")
}}}},error:function(q,o,p){alert("An error occurred while loading the page. Please try again later.");
CHL_IMS.signinWithAdobeId(CHL_IMS.ccRedirectLoc)
}})
}}}}}else{CHL_IMS.signinWithAdobeId(CHL_IMS.ccRedirectLoc)
}}}catch(k){CHL_IMS.signinWithAdobeId(d)
}});
e.fail(function(g,h){alert("An error occurred while loading the page. Please try again later.");
CHL_IMS.signinWithAdobeId(CHL_IMS.ccRedirectLoc)
})
}},set_cookie:function(e,f,b){var a="";
if(b){var d=new Date();
d.setTime(d.getTime()+(b*60*60*1000));
a="; expires="+d.toGMTString()
}document.cookie=e+"="+f+a+"; path=/"
},get_cookie:function(b){var e=b+"=";
var a=document.cookie.split(";");
var d=0;
for(d=0;
d<a.length;
d++){var f=a[d];
while(f.charAt(0)==" "){f=f.substring(1,f.length)
}if(f.indexOf(e)===0){return f.substring(e.length,f.length)
}}return null
},signinWithAdobeId:function(a){if(typeof(adobeid)!="undefined"&&typeof(adobeGlobalNav)!="undefined"){adobeid.redirect_uri=a;
adobeGlobalNav._ims.signIn()
}}};
$(document).ready(function(){if(typeof enableTabs!="undefined"){$(".helptab").click(function(){var a=$(this).attr("class").split(" ")[0];
var g=window.location.href;
var d=g.indexOf("?");
if(window.history.replaceState){if(d>0){g=g.substring(d+1,g.length);
if(g.indexOf("=")<0){window.history.replaceState(null,document.title,"?"+a)
}else{var b=g.split("&");
var f="";
var h=false;
for(var e=0;
e<b.length;
e++){if(b[e].indexOf("=")<0){f=f+"&"+a;
h=true
}else{f=f+"&"+b[e]
}}f=f.substring(1,f.length);
if(!h){f=f+"&"+a
}window.history.replaceState(null,document.title,"?"+f)
}}else{window.history.replaceState(null,document.title,"?"+a)
}}$(this).parent().find(".helptab").removeClass("selected-tab");
$(this).parent().find(".tab-content").hide();
$(this).addClass("selected-tab");
$(this).parent().find("."+a+"-content").fadeIn(1000)
});
(function(){var a;
if(window.location.href.indexOf("?t1")!=-1){a="t1"
}else{if(window.location.href.indexOf("?t2")!=-1){a="t2"
}else{if(window.location.href.indexOf("?t3")!=-1){a="t3"
}else{if(window.location.href.indexOf("?t4")!=-1){a="t4"
}}}}if(a){$(".helptab").removeClass("selected-tab");
$("."+a).addClass("selected-tab");
$(".tab-content:first").hide();
$("."+a+"-content:first").fadeIn(1000)
}})()
}});
/*! Video.js v4.12.3 Copyright 2014 Brightcove, Inc. https://github.com/videojs/video.js/blob/master/LICENSE */
(function(){var b=void 0,f=!0,j=null,l=!1;
function m(){return function(){}
}function n(a){return function(){return this[a]
}
}function q(a){return function(){return a
}
}var s;
document.createElement("video");
document.createElement("audio");
document.createElement("track");
function t(a,c,d){if("string"===typeof a){0===a.indexOf("#")&&(a=a.slice(1));
if(t.Aa[a]){return c&&t.log.warn('Player "'+a+'" is already initialised. Options will not be applied.'),d&&t.Aa[a].I(d),t.Aa[a]
}a=t.m(a)
}if(!a||!a.nodeName){throw new TypeError("The element or ID supplied is not valid. (videojs)")
}return a.player||new t.Player(a,c,d)
}var videojs=window.videojs=t;
t.ic="4.12";
t.vd="https:"==document.location.protocol?"https://":"http://";
t.VERSION="4.12.3";
t.options={techOrder:["html5","flash"],html5:{},flash:{},width:300,height:150,defaultVolume:0,playbackRates:[],inactivityTimeout:2000,children:{mediaLoader:{},posterImage:{},loadingSpinner:{},textTrackDisplay:{},bigPlayButton:{},controlBar:{},errorDisplay:{},textTrackSettings:{}},language:document.getElementsByTagName("html")[0].getAttribute("lang")||navigator.languages&&navigator.languages[0]||navigator.If||navigator.language||"en",languages:{},notSupportedMessage:"No compatible source was found for this video."};
"GENERATED_CDN_VSN"!==t.ic&&(videojs.options.flash.swf=t.vd+"vjs.zencdn.net/"+t.ic+"/video-js.swf");
t.Jd=function(a,c){t.options.languages[a]=t.options.languages[a]!==b?t.$.ya(t.options.languages[a],c):c;
return t.options.languages
};
t.Aa={};
"function"===typeof define&&define.amd?define("videojs",[],function(){return videojs
}):"object"===typeof exports&&"object"===typeof module&&(module.exports=videojs);
t.Ea=t.CoreObject=m();
t.Ea.extend=function(a){var c,d;
a=a||{};
c=a.init||a.l||this.prototype.init||this.prototype.l||m();
d=function(){c.apply(this,arguments)
};
d.prototype=t.i.create(this.prototype);
d.prototype.constructor=d;
d.extend=t.Ea.extend;
d.create=t.Ea.create;
for(var e in a){a.hasOwnProperty(e)&&(d.prototype[e]=a[e])
}return d
};
t.Ea.create=function(){var a=t.i.create(this.prototype);
this.apply(a,arguments);
return a
};
t.b=function(a,c,d){if(t.i.isArray(c)){return v(t.b,a,c,d)
}var e=t.getData(a);
e.G||(e.G={});
e.G[c]||(e.G[c]=[]);
d.s||(d.s=t.s++);
e.G[c].push(d);
e.ca||(e.disabled=l,e.ca=function(c){if(!e.disabled){c=t.Pb(c);
var d=e.G[c.type];
if(d){for(var d=d.slice(0),k=0,p=d.length;
k<p&&!c.Rc();
k++){d[k].call(a,c)
}}}});
1==e.G[c].length&&(a.addEventListener?a.addEventListener(c,e.ca,l):a.attachEvent&&a.attachEvent("on"+c,e.ca))
};
t.n=function(a,c,d){if(t.Mc(a)){var e=t.getData(a);
if(e.G){if(t.i.isArray(c)){return v(t.n,a,c,d)
}if(c){var g=e.G[c];
if(g){if(d){if(d.s){for(e=0;
e<g.length;
e++){g[e].s===d.s&&g.splice(e--,1)
}}}else{e.G[c]=[]
}t.Ac(a,c)
}}else{for(g in e.G){c=g,e.G[c]=[],t.Ac(a,c)
}}}}};
t.Ac=function(a,c){var d=t.getData(a);
0===d.G[c].length&&(delete d.G[c],a.removeEventListener?a.removeEventListener(c,d.ca,l):a.detachEvent&&a.detachEvent("on"+c,d.ca));
t.ib(d.G)&&(delete d.G,delete d.ca,delete d.disabled);
t.ib(d)&&t.cd(a)
};
t.Pb=function(a){function c(){return f
}function d(){return l
}if(!a||!a.Vb){var e=a||window.event;
a={};
for(var g in e){"layerX"!==g&&("layerY"!==g&&"keyLocation"!==g)&&("returnValue"==g&&e.preventDefault||(a[g]=e[g]))
}a.target||(a.target=a.srcElement||document);
a.relatedTarget=a.fromElement===a.target?a.toElement:a.fromElement;
a.preventDefault=function(){e.preventDefault&&e.preventDefault();
a.returnValue=l;
a.ie=c;
a.defaultPrevented=f
};
a.ie=d;
a.defaultPrevented=l;
a.stopPropagation=function(){e.stopPropagation&&e.stopPropagation();
a.cancelBubble=f;
a.Vb=c
};
a.Vb=d;
a.stopImmediatePropagation=function(){e.stopImmediatePropagation&&e.stopImmediatePropagation();
a.Rc=c;
a.stopPropagation()
};
a.Rc=d;
if(a.clientX!=j){g=document.documentElement;
var h=document.body;
a.pageX=a.clientX+(g&&g.scrollLeft||h&&h.scrollLeft||0)-(g&&g.clientLeft||h&&h.clientLeft||0);
a.pageY=a.clientY+(g&&g.scrollTop||h&&h.scrollTop||0)-(g&&g.clientTop||h&&h.clientTop||0)
}a.which=a.charCode||a.keyCode;
a.button!=j&&(a.button=a.button&1?0:a.button&4?1:a.button&2?2:0)
}return a
};
t.o=function(a,c){var d=t.Mc(a)?t.getData(a):{},e=a.parentNode||a.ownerDocument;
"string"===typeof c&&(c={type:c,target:a});
c=t.Pb(c);
d.ca&&d.ca.call(a,c);
if(e&&!c.Vb()&&c.bubbles!==l){t.o(e,c)
}else{if(!e&&!c.defaultPrevented&&(d=t.getData(c.target),c.target[c.type])){d.disabled=f;
if("function"===typeof c.target[c.type]){c.target[c.type]()
}d.disabled=l
}}return !c.defaultPrevented
};
t.N=function(a,c,d){function e(){t.n(a,c,e);
d.apply(this,arguments)
}if(t.i.isArray(c)){return v(t.N,a,c,d)
}e.s=d.s=d.s||t.s++;
t.b(a,c,e)
};
function v(a,c,d,e){t.wc.forEach(d,function(d){a(c,d,e)
})
}var w=Object.prototype.hasOwnProperty;
t.e=function(a,c){var d;
c=c||{};
d=document.createElement(a||"div");
t.i.da(c,function(a,c){-1!==a.indexOf("aria-")||"role"==a?d.setAttribute(a,c):d[a]=c
});
return d
};
t.ua=function(a){return a.charAt(0).toUpperCase()+a.slice(1)
};
t.i={};
t.i.create=Object.create||function(a){function c(){}c.prototype=a;
return new c
};
t.i.da=function(a,c,d){for(var e in a){w.call(a,e)&&c.call(d||this,e,a[e])
}};
t.i.D=function(a,c){if(!c){return a
}for(var d in c){w.call(c,d)&&(a[d]=c[d])
}return a
};
t.i.Rd=function(a,c){var d,e,g;
a=t.i.copy(a);
for(d in c){w.call(c,d)&&(e=a[d],g=c[d],a[d]=t.i.jb(e)&&t.i.jb(g)?t.i.Rd(e,g):c[d])
}return a
};
t.i.copy=function(a){return t.i.D({},a)
};
t.i.jb=function(a){return !!a&&"object"===typeof a&&"[object Object]"===a.toString()&&a.constructor===Object
};
t.i.isArray=Array.isArray||function(a){return"[object Array]"===Object.prototype.toString.call(a)
};
t.ke=function(a){return a!==a
};
t.bind=function(a,c,d){function e(){return c.apply(a,arguments)
}c.s||(c.s=t.s++);
e.s=d?d+"_"+c.s:c.s;
return e
};
t.ta={};
t.s=1;
t.expando="vdata"+(new Date).getTime();
t.getData=function(a){var c=a[t.expando];
c||(c=a[t.expando]=t.s++);
t.ta[c]||(t.ta[c]={});
return t.ta[c]
};
t.Mc=function(a){a=a[t.expando];
return !(!a||t.ib(t.ta[a]))
};
t.cd=function(a){var c=a[t.expando];
if(c){delete t.ta[c];
try{delete a[t.expando]
}catch(d){a.removeAttribute?a.removeAttribute(t.expando):a[t.expando]=j
}}};
t.ib=function(a){for(var c in a){if(a[c]!==j){return l
}}return f
};
t.Oa=function(a,c){return -1!==(" "+a.className+" ").indexOf(" "+c+" ")
};
t.p=function(a,c){t.Oa(a,c)||(a.className=""===a.className?c:a.className+" "+c)
};
t.r=function(a,c){var d,e;
if(t.Oa(a,c)){d=a.className.split(" ");
for(e=d.length-1;
0<=e;
e--){d[e]===c&&d.splice(e,1)
}a.className=d.join(" ")
}};
t.A=t.e("video");
var x=document.createElement("track");
x.Wb="captions";
x.hd="en";
x.label="English";
t.A.appendChild(x);
t.P=navigator.userAgent;
t.Cd=/iPhone/i.test(t.P);
t.Bd=/iPad/i.test(t.P);
t.Dd=/iPod/i.test(t.P);
t.Ad=t.Cd||t.Bd||t.Dd;
var aa=t,y;
var z=t.P.match(/OS (\d+)_/i);
y=z&&z[1]?z[1]:b;
aa.kf=y;
t.zd=/Android/i.test(t.P);
var ba=t,B;
var C=t.P.match(/Android (\d+)(?:\.(\d+))?(?:\.(\d+))*/i),D,E;
C?(D=C[1]&&parseFloat(C[1]),E=C[2]&&parseFloat(C[2]),B=D&&E?parseFloat(C[1]+"."+C[2]):D?D:j):B=j;
ba.hc=B;
t.Ed=t.zd&&/webkit/i.test(t.P)&&2.3>t.hc;
t.jc=/Firefox/i.test(t.P);
t.lf=/Chrome/i.test(t.P);
t.oa=/MSIE\s8\.0/.test(t.P);
t.Eb=!!("ontouchstart" in window||window.xd&&document instanceof window.xd);
t.wd="backgroundSize" in t.A.style;
t.ed=function(a,c){t.i.da(c,function(c,e){e===j||"undefined"===typeof e||e===l?a.removeAttribute(c):a.setAttribute(c,e===f?"":e)
})
};
t.Na=function(a){var c,d,e,g;
c={};
if(a&&a.attributes&&0<a.attributes.length){d=a.attributes;
for(var h=d.length-1;
0<=h;
h--){e=d[h].name;
g=d[h].value;
if("boolean"===typeof a[e]||-1!==",autoplay,controls,loop,muted,default,".indexOf(","+e+",")){g=g!==j?f:l
}c[e]=g
}}return c
};
t.vf=function(a,c){var d="";
document.defaultView&&document.defaultView.getComputedStyle?d=document.defaultView.getComputedStyle(a,"").getPropertyValue(c):a.currentStyle&&(d=a["client"+c.substr(0,1).toUpperCase()+c.substr(1)]+"px");
return d
};
t.Ub=function(a,c){c.firstChild?c.insertBefore(a,c.firstChild):c.appendChild(a)
};
t.cb={};
t.m=function(a){0===a.indexOf("#")&&(a=a.slice(1));
return document.getElementById(a)
};
t.Ma=function(a,c){c=c||a;
var d=Math.floor(a%60),e=Math.floor(a/60%60),g=Math.floor(a/3600),h=Math.floor(c/60%60),k=Math.floor(c/3600);
if(isNaN(a)||Infinity===a){g=e=d="-"
}g=0<g||0<k?g+":":"";
return g+(((g||10<=h)&&10>e?"0"+e:e)+":")+(10>d?"0"+d:d)
};
t.Ld=function(){document.body.focus();
document.onselectstart=q(l)
};
t.af=function(){document.onselectstart=q(f)
};
t.trim=function(a){return(a+"").replace(/^\s+|\s+$/g,"")
};
t.round=function(a,c){c||(c=0);
return Math.round(a*Math.pow(10,c))/Math.pow(10,c)
};
t.Lb=function(a,c){return{length:1,start:function(){return a
},end:function(){return c
}}
};
t.Me=function(a){try{var c=window.localStorage||l;
c&&(c.volume=a)
}catch(d){22==d.code||1014==d.code?t.log("LocalStorage Full (VideoJS)",d):18==d.code?t.log("LocalStorage not allowed (VideoJS)",d):t.log("LocalStorage Error (VideoJS)",d)
}};
t.$d=function(a){a.match(/^https?:\/\//)||(a=t.e("div",{innerHTML:'<a href="'+a+'">x</a>'}).firstChild.href);
return a
};
t.Ee=function(a){var c,d,e,g;
g="protocol hostname port pathname search hash host".split(" ");
d=t.e("a",{href:a});
if(e=""===d.host&&"file:"!==d.protocol){c=t.e("div"),c.innerHTML='<a href="'+a+'"></a>',d=c.firstChild,c.setAttribute("style","display:none; position:absolute;"),document.body.appendChild(c)
}a={};
for(var h=0;
h<g.length;
h++){a[g[h]]=d[g[h]]
}"http:"===a.protocol&&(a.host=a.host.replace(/:80$/,""));
"https:"===a.protocol&&(a.host=a.host.replace(/:443$/,""));
e&&document.body.removeChild(c);
return a
};
function F(a,c){var d,e;
d=Array.prototype.slice.call(c);
e=m();
e=window.console||{log:e,warn:e,error:e};
a?d.unshift(a.toUpperCase()+":"):a="log";
t.log.history.push(d);
d.unshift("VIDEOJS:");
if(e[a].apply){e[a].apply(e,d)
}else{e[a](d.join(" "))
}}t.log=function(){F(j,arguments)
};
t.log.history=[];
t.log.error=function(){F("error",arguments)
};
t.log.warn=function(){F("warn",arguments)
};
t.Yd=function(a){var c,d;
a.getBoundingClientRect&&a.parentNode&&(c=a.getBoundingClientRect());
if(!c){return{left:0,top:0}
}a=document.documentElement;
d=document.body;
return{left:t.round(c.left+(window.pageXOffset||d.scrollLeft)-(a.clientLeft||d.clientLeft||0)),top:t.round(c.top+(window.pageYOffset||d.scrollTop)-(a.clientTop||d.clientTop||0))}
};
t.wc={};
t.wc.forEach=function(a,c,d){if(t.i.isArray(a)&&c instanceof Function){for(var e=0,g=a.length;
e<g;
++e){c.call(d||t,a[e],e,a)
}}return a
};
t.ff=function(a,c){var d,e,g,h,k,p,r;
"string"===typeof a&&(a={uri:a});
videojs.$.ya({method:"GET",timeout:45000},a);
c=c||m();
p=function(){window.clearTimeout(k);
c(j,e,e.response||e.responseText)
};
r=function(a){window.clearTimeout(k);
if(!a||"string"===typeof a){a=Error(a)
}c(a,e)
};
d=window.XMLHttpRequest;
"undefined"===typeof d&&(d=function(){try{return new window.ActiveXObject("Msxml2.XMLHTTP.6.0")
}catch(a){}try{return new window.ActiveXObject("Msxml2.XMLHTTP.3.0")
}catch(c){}try{return new window.ActiveXObject("Msxml2.XMLHTTP")
}catch(d){}throw Error("This browser does not support XMLHttpRequest.")
});
e=new d;
e.uri=a.uri;
d=t.Ee(a.uri);
g=window.location;
d.protocol+d.host!==g.protocol+g.host&&window.XDomainRequest&&!("withCredentials" in e)?(e=new window.XDomainRequest,e.onload=p,e.onerror=r,e.onprogress=m(),e.ontimeout=m()):(h="file:"==d.protocol||"file:"==g.protocol,e.onreadystatechange=function(){if(4===e.readyState){if(e.Ye){return r("timeout")
}200===e.status||h&&0===e.status?p():r()
}},a.timeout&&(k=window.setTimeout(function(){4!==e.readyState&&(e.Ye=f,e.abort())
},a.timeout)));
try{e.open(a.method||"GET",a.uri,f)
}catch(u){r(u);
return
}a.withCredentials&&(e.withCredentials=f);
a.responseType&&(e.responseType=a.responseType);
try{e.send()
}catch(A){r(A)
}};
t.$={};
t.$.ya=function(a,c){var d,e,g;
a=t.i.copy(a);
for(d in c){c.hasOwnProperty(d)&&(e=a[d],g=c[d],a[d]=t.i.jb(e)&&t.i.jb(g)?t.$.ya(e,g):c[d])
}return a
};
t.z=m();
s=t.z.prototype;
s.bb={};
s.b=function(a,c){var d=this.addEventListener;
this.addEventListener=Function.prototype;
t.b(this,a,c);
this.addEventListener=d
};
s.addEventListener=t.z.prototype.b;
s.n=function(a,c){t.n(this,a,c)
};
s.removeEventListener=t.z.prototype.n;
s.N=function(a,c){t.N(this,a,c)
};
s.o=function(a){var c=a.type||a;
"string"===typeof a&&(a={type:c});
a=t.Pb(a);
if(this.bb[c]&&this["on"+c]){this["on"+c](a)
}t.o(this,a)
};
s.dispatchEvent=t.z.prototype.o;
t.a=t.Ea.extend({l:function(a,c,d){this.d=a;
this.q=t.i.copy(this.q);
c=this.options(c);
this.Pa=c.id||c.el&&c.el.id;
this.Pa||(this.Pa=(a.id&&a.id()||"no_player")+"_component_"+t.s++);
this.te=c.name||j;
this.c=c.el||this.e();
this.R=[];
this.fb={};
this.gb={};
this.Oc();
this.I(d);
if(c.dd!==l){var e,g;
this.k().reportUserActivity&&(e=t.bind(this.k(),this.k().reportUserActivity),this.b("touchstart",function(){e();
this.clearInterval(g);
g=this.setInterval(e,250)
}),a=function(){e();
this.clearInterval(g)
},this.b("touchmove",e),this.b("touchend",a),this.b("touchcancel",a))
}}});
s=t.a.prototype;
s.dispose=function(){this.o({type:"dispose",bubbles:l});
if(this.R){for(var a=this.R.length-1;
0<=a;
a--){this.R[a].dispose&&this.R[a].dispose()
}}this.gb=this.fb=this.R=j;
this.n();
this.c.parentNode&&this.c.parentNode.removeChild(this.c);
t.cd(this.c);
this.c=j
};
s.d=f;
s.k=n("d");
s.options=function(a){return a===b?this.q:this.q=t.$.ya(this.q,a)
};
s.e=function(a,c){return t.e(a,c)
};
s.v=function(a){var c=this.d.language(),d=this.d.languages();
return d&&d[c]&&d[c][a]?d[c][a]:a
};
s.m=n("c");
s.va=function(){return this.B||this.c
};
s.id=n("Pa");
s.name=n("te");
s.children=n("R");
s.ae=function(a){return this.fb[a]
};
s.ea=function(a){return this.gb[a]
};
s.ba=function(a,c){var d,e;
"string"===typeof a?(e=a,c=c||{},d=c.componentClass||t.ua(e),c.name=e,d=new window.videojs[d](this.d||this,c)):d=a;
this.R.push(d);
"function"===typeof d.id&&(this.fb[d.id()]=d);
(e=e||d.name&&d.name())&&(this.gb[e]=d);
"function"===typeof d.el&&d.el()&&this.va().appendChild(d.el());
return d
};
s.removeChild=function(a){"string"===typeof a&&(a=this.ea(a));
if(a&&this.R){for(var c=l,d=this.R.length-1;
0<=d;
d--){if(this.R[d]===a){c=f;
this.R.splice(d,1);
break
}}c&&(this.fb[a.id()]=j,this.gb[a.name()]=j,(c=a.m())&&c.parentNode===this.va()&&this.va().removeChild(a.m()))
}};
s.Oc=function(){var a,c,d,e,g,h;
a=this;
c=a.options();
if(d=c.children){if(h=function(d,e){c[d]!==b&&(e=c[d]);
e!==l&&(a[d]=a.ba(d,e))
},t.i.isArray(d)){for(var k=0;
k<d.length;
k++){e=d[k],"string"==typeof e?(g=e,e={}):g=e.name,h(g,e)
}}else{t.i.da(d,h)
}}};
s.V=q("");
s.b=function(a,c,d){var e,g,h;
"string"===typeof a||t.i.isArray(a)?t.b(this.c,a,t.bind(this,c)):(e=t.bind(this,d),h=this,g=function(){h.n(a,c,e)
},g.s=e.s,this.b("dispose",g),d=function(){h.n("dispose",g)
},d.s=e.s,a.nodeName?(t.b(a,c,e),t.b(a,"dispose",d)):"function"===typeof a.b&&(a.b(c,e),a.b("dispose",d)));
return this
};
s.n=function(a,c,d){!a||"string"===typeof a||t.i.isArray(a)?t.n(this.c,a,c):(d=t.bind(this,d),this.n("dispose",d),a.nodeName?(t.n(a,c,d),t.n(a,"dispose",d)):(a.n(c,d),a.n("dispose",d)));
return this
};
s.N=function(a,c,d){var e,g,h;
"string"===typeof a||t.i.isArray(a)?t.N(this.c,a,t.bind(this,c)):(e=t.bind(this,d),g=this,h=function(){g.n(a,c,h);
e.apply(this,arguments)
},h.s=e.s,this.b(a,c,h));
return this
};
s.o=function(a){t.o(this.c,a);
return this
};
s.I=function(a){a&&(this.wa?a.call(this):(this.nb===b&&(this.nb=[]),this.nb.push(a)));
return this
};
s.Wa=function(){this.wa=f;
var a=this.nb;
if(a&&0<a.length){for(var c=0,d=a.length;
c<d;
c++){a[c].call(this)
}this.nb=[];
this.o("ready")
}};
s.Oa=function(a){return t.Oa(this.c,a)
};
s.p=function(a){t.p(this.c,a);
return this
};
s.r=function(a){t.r(this.c,a);
return this
};
s.show=function(){this.r("vjs-hidden");
return this
};
s.Y=function(){this.p("vjs-hidden");
return this
};
function G(a){a.r("vjs-lock-showing")
}s.width=function(a,c){return ca(this,"width",a,c)
};
s.height=function(a,c){return ca(this,"height",a,c)
};
s.Td=function(a,c){return this.width(a,f).height(c)
};
function ca(a,c,d,e){if(d!==b){if(d===j||t.ke(d)){d=0
}a.c.style[c]=-1!==(""+d).indexOf("%")||-1!==(""+d).indexOf("px")?d:"auto"===d?"":d+"px";
e||a.o("resize");
return a
}if(!a.c){return 0
}d=a.c.style[c];
e=d.indexOf("px");
return -1!==e?parseInt(d.slice(0,e),10):parseInt(a.c["offset"+t.ua(c)],10)
}function da(a){var c,d,e,g,h,k,p,r;
c=0;
d=j;
a.b("touchstart",function(a){1===a.touches.length&&(d=t.i.copy(a.touches[0]),c=(new Date).getTime(),g=f)
});
a.b("touchmove",function(a){1<a.touches.length?g=l:d&&(k=a.touches[0].pageX-d.pageX,p=a.touches[0].pageY-d.pageY,r=Math.sqrt(k*k+p*p),10<r&&(g=l))
});
h=function(){g=l
};
a.b("touchleave",h);
a.b("touchcancel",h);
a.b("touchend",function(a){d=j;
g===f&&(e=(new Date).getTime()-c,200>e&&(a.preventDefault(),this.o("tap")))
})
}s.setTimeout=function(a,c){function d(){this.clearTimeout(e)
}a=t.bind(this,a);
var e=setTimeout(a,c);
d.s="vjs-timeout-"+e;
this.b("dispose",d);
return e
};
s.clearTimeout=function(a){function c(){}clearTimeout(a);
c.s="vjs-timeout-"+a;
this.n("dispose",c);
return a
};
s.setInterval=function(a,c){function d(){this.clearInterval(e)
}a=t.bind(this,a);
var e=setInterval(a,c);
d.s="vjs-interval-"+e;
this.b("dispose",d);
return e
};
s.clearInterval=function(a){function c(){}clearInterval(a);
c.s="vjs-interval-"+a;
this.n("dispose",c);
return a
};
t.w=t.a.extend({l:function(a,c){t.a.call(this,a,c);
da(this);
this.b("tap",this.u);
this.b("click",this.u);
this.b("focus",this.lb);
this.b("blur",this.kb)
}});
s=t.w.prototype;
s.e=function(a,c){var d;
c=t.i.D({className:this.V(),role:"button","aria-live":"polite",tabIndex:0},c);
d=t.a.prototype.e.call(this,a,c);
c.innerHTML||(this.B=t.e("div",{className:"vjs-control-content"}),this.Jb=t.e("span",{className:"vjs-control-text",innerHTML:this.v(this.sa)||"Need Text"}),this.B.appendChild(this.Jb),d.appendChild(this.B));
return d
};
s.V=function(){return"vjs-control "+t.a.prototype.V.call(this)
};
s.u=m();
s.lb=function(){t.b(document,"keydown",t.bind(this,this.ja))
};
s.ja=function(a){if(32==a.which||13==a.which){a.preventDefault(),this.u()
}};
s.kb=function(){t.n(document,"keydown",t.bind(this,this.ja))
};
t.U=t.a.extend({l:function(a,c){t.a.call(this,a,c);
this.Kd=this.ea(this.q.barName);
this.handle=this.ea(this.q.handleName);
this.b("mousedown",this.mb);
this.b("touchstart",this.mb);
this.b("focus",this.lb);
this.b("blur",this.kb);
this.b("click",this.u);
this.b(a,"controlsvisible",this.update);
this.b(a,this.Yc,this.update)
}});
s=t.U.prototype;
s.e=function(a,c){c=c||{};
c.className+=" vjs-slider";
c=t.i.D({role:"slider","aria-valuenow":0,"aria-valuemin":0,"aria-valuemax":100,tabIndex:0},c);
return t.a.prototype.e.call(this,a,c)
};
s.mb=function(a){a.preventDefault();
t.Ld();
this.p("vjs-sliding");
this.b(document,"mousemove",this.ka);
this.b(document,"mouseup",this.za);
this.b(document,"touchmove",this.ka);
this.b(document,"touchend",this.za);
this.ka(a)
};
s.ka=m();
s.za=function(){t.af();
this.r("vjs-sliding");
this.n(document,"mousemove",this.ka);
this.n(document,"mouseup",this.za);
this.n(document,"touchmove",this.ka);
this.n(document,"touchend",this.za);
this.update()
};
s.update=function(){if(this.c){var a,c=this.Sb(),d=this.handle,e=this.Kd;
if("number"!==typeof c||c!==c||0>c||Infinity===c){c=0
}a=c;
if(d){a=this.c.offsetWidth;
var g=d.m().offsetWidth;
a=g?g/a:0;
c*=1-a;
a=c+a/2;
d.m().style.left=t.round(100*c,2)+"%"
}e&&(e.m().style.width=t.round(100*a,2)+"%")
}};
function ea(a,c){var d,e,g,h;
d=a.c;
e=t.Yd(d);
h=g=d.offsetWidth;
d=a.handle;
if(a.options().vertical){return h=e.top,e=c.changedTouches?c.changedTouches[0].pageY:c.pageY,d&&(d=d.m().offsetHeight,h+=d/2,g-=d),Math.max(0,Math.min(1,(h-e+g)/g))
}g=e.left;
e=c.changedTouches?c.changedTouches[0].pageX:c.pageX;
d&&(d=d.m().offsetWidth,g+=d/2,h-=d);
return Math.max(0,Math.min(1,(e-g)/h))
}s.lb=function(){this.b(document,"keydown",this.ja)
};
s.ja=function(a){if(37==a.which||40==a.which){a.preventDefault(),this.jd()
}else{if(38==a.which||39==a.which){a.preventDefault(),this.kd()
}}};
s.kb=function(){this.n(document,"keydown",this.ja)
};
s.u=function(a){a.stopImmediatePropagation();
a.preventDefault()
};
t.ga=t.a.extend();
t.ga.prototype.defaultValue=0;
t.ga.prototype.e=function(a,c){c=c||{};
c.className+=" vjs-slider-handle";
c=t.i.D({innerHTML:'<span class="vjs-control-text">'+this.defaultValue+"</span>"},c);
return t.a.prototype.e.call(this,"div",c)
};
t.pa=t.a.extend();
function fa(a,c){a.ba(c);
c.b("click",t.bind(a,function(){G(this)
}))
}t.pa.prototype.e=function(){var a=this.options().Cc||"ul";
this.B=t.e(a,{className:"vjs-menu-content"});
a=t.a.prototype.e.call(this,"div",{append:this.B,className:"vjs-menu"});
a.appendChild(this.B);
t.b(a,"click",function(a){a.preventDefault();
a.stopImmediatePropagation()
});
return a
};
t.M=t.w.extend({l:function(a,c){t.w.call(this,a,c);
this.selected(c.selected)
}});
t.M.prototype.e=function(a,c){return t.w.prototype.e.call(this,"li",t.i.D({className:"vjs-menu-item",innerHTML:this.v(this.q.label)},c))
};
t.M.prototype.u=function(){this.selected(f)
};
t.M.prototype.selected=function(a){a?(this.p("vjs-selected"),this.c.setAttribute("aria-selected",f)):(this.r("vjs-selected"),this.c.setAttribute("aria-selected",l))
};
t.O=t.w.extend({l:function(a,c){t.w.call(this,a,c);
this.update();
this.b("keydown",this.ja);
this.c.setAttribute("aria-haspopup",f);
this.c.setAttribute("role","button")
}});
s=t.O.prototype;
s.update=function(){var a=this.Ja();
this.xa&&this.removeChild(this.xa);
this.xa=a;
this.ba(a);
this.H&&0===this.H.length?this.Y():this.H&&1<this.H.length&&this.show()
};
s.Ha=l;
s.Ja=function(){var a=new t.pa(this.d);
this.options().title&&a.va().appendChild(t.e("li",{className:"vjs-menu-title",innerHTML:t.ua(this.options().title),We:-1}));
if(this.H=this.createItems()){for(var c=0;
c<this.H.length;
c++){fa(a,this.H[c])
}}return a
};
s.Ia=m();
s.V=function(){return this.className+" vjs-menu-button "+t.w.prototype.V.call(this)
};
s.lb=m();
s.kb=m();
s.u=function(){this.N("mouseout",t.bind(this,function(){G(this.xa);
this.c.blur()
}));
this.Ha?H(this):ga(this)
};
s.ja=function(a){32==a.which||13==a.which?(this.Ha?H(this):ga(this),a.preventDefault()):27==a.which&&(this.Ha&&H(this),a.preventDefault())
};
function ga(a){a.Ha=f;
a.xa.p("vjs-lock-showing");
a.c.setAttribute("aria-pressed",f);
a.H&&0<a.H.length&&a.H[0].m().focus()
}function H(a){a.Ha=l;
G(a.xa);
a.c.setAttribute("aria-pressed",l)
}t.J=function(a){"number"===typeof a?this.code=a:"string"===typeof a?this.message=a:"object"===typeof a&&t.i.D(this,a);
this.message||(this.message=t.J.Sd[this.code]||"")
};
t.J.prototype.code=0;
t.J.prototype.message="";
t.J.prototype.status=j;
t.J.hb="MEDIA_ERR_CUSTOM MEDIA_ERR_ABORTED MEDIA_ERR_NETWORK MEDIA_ERR_DECODE MEDIA_ERR_SRC_NOT_SUPPORTED MEDIA_ERR_ENCRYPTED".split(" ");
t.J.Sd={1:"You aborted the video playback",2:"A network error caused the video download to fail part-way.",3:"The video playback was aborted due to a corruption problem or because the video used features your browser did not support.",4:"The video could not be loaded, either because the server or network failed or because the format is not supported.",5:"The video is encrypted and we do not have the keys to decrypt it."};
for(var I=0;
I<t.J.hb.length;
I++){t.J[t.J.hb[I]]=I,t.J.prototype[t.J.hb[I]]=I
}var J,ha,K,L;
J=["requestFullscreen exitFullscreen fullscreenElement fullscreenEnabled fullscreenchange fullscreenerror".split(" "),"webkitRequestFullscreen webkitExitFullscreen webkitFullscreenElement webkitFullscreenEnabled webkitfullscreenchange webkitfullscreenerror".split(" "),"webkitRequestFullScreen webkitCancelFullScreen webkitCurrentFullScreenElement webkitCancelFullScreen webkitfullscreenchange webkitfullscreenerror".split(" "),"mozRequestFullScreen mozCancelFullScreen mozFullScreenElement mozFullScreenEnabled mozfullscreenchange mozfullscreenerror".split(" "),"msRequestFullscreen msExitFullscreen msFullscreenElement msFullscreenEnabled MSFullscreenChange MSFullscreenError".split(" ")];
ha=J[0];
for(L=0;
L<J.length;
L++){if(J[L][1] in document){K=J[L];
break
}}if(K){t.cb.Rb={};
for(L=0;
L<K.length;
L++){t.cb.Rb[ha[L]]=K[L]
}}t.Player=t.a.extend({l:function(a,c,d){this.L=a;
a.id=a.id||"vjs_video_"+t.s++;
this.Xe=a&&t.Na(a);
c=t.i.D(ia(a),c);
this.Tc=c.language||t.options.language;
this.ne=c.languages||t.options.languages;
this.K={};
this.Zc=c.poster||"";
this.Kb=!!c.controls;
a.controls=l;
c.dd=l;
ja(this,"audio"===this.L.nodeName.toLowerCase());
t.a.call(this,this,c,d);
this.controls()?this.p("vjs-controls-enabled"):this.p("vjs-controls-disabled");
ja(this)&&this.p("vjs-audio");
t.Aa[this.Pa]=this;
c.plugins&&t.i.da(c.plugins,function(a,c){this[a](c)
},this);
var e,g,h,k,p;
e=t.bind(this,this.reportUserActivity);
this.b("mousedown",function(){e();
this.clearInterval(g);
g=this.setInterval(e,250)
});
this.b("mousemove",function(a){if(a.screenX!=k||a.screenY!=p){k=a.screenX,p=a.screenY,e()
}});
this.b("mouseup",function(){e();
this.clearInterval(g)
});
this.b("keydown",e);
this.b("keyup",e);
this.setInterval(function(){if(this.Da){this.Da=l;
this.userActive(f);
this.clearTimeout(h);
var a=this.options().inactivityTimeout;
0<a&&(h=this.setTimeout(function(){this.Da||this.userActive(l)
},a))
}},250)
}});
s=t.Player.prototype;
s.language=function(a){if(a===b){return this.Tc
}this.Tc=a;
return this
};
s.languages=n("ne");
s.q=t.options;
s.dispose=function(){this.o("dispose");
this.n("dispose");
t.Aa[this.Pa]=j;
this.L&&this.L.player&&(this.L.player=j);
this.c&&this.c.player&&(this.c.player=j);
this.h&&this.h.dispose();
t.a.prototype.dispose.call(this)
};
function ia(a){var c,d,e={sources:[],tracks:[]};
c=t.Na(a);
d=c["data-setup"];
d!==j&&t.i.D(c,t.JSON.parse(d||"{}"));
t.i.D(e,c);
if(a.hasChildNodes()){var g,h;
a=a.childNodes;
g=0;
for(h=a.length;
g<h;
g++){c=a[g],d=c.nodeName.toLowerCase(),"source"===d?e.sources.push(t.Na(c)):"track"===d&&e.tracks.push(t.Na(c))
}}return e
}s.e=function(){var a=this.c=t.a.prototype.e.call(this,"div"),c=this.L,d;
c.removeAttribute("width");
c.removeAttribute("height");
d=t.Na(c);
t.i.da(d,function(c){"class"==c?a.className=d[c]:a.setAttribute(c,d[c])
});
c.id+="_html5_api";
c.className="vjs-tech";
c.player=a.player=this;
this.p("vjs-paused");
this.width(this.q.width,f);
this.height(this.q.height,f);
c.ge=c.networkState;
c.parentNode&&c.parentNode.insertBefore(a,c);
t.Ub(c,a);
this.c=a;
this.b("loadstart",this.xe);
this.b("waiting",this.De);
this.b(["canplay","canplaythrough","playing","ended"],this.Ce);
this.b("seeking",this.Ae);
this.b("seeked",this.ze);
this.b("ended",this.ue);
this.b("play",this.$b);
this.b("firstplay",this.ve);
this.b("pause",this.Zb);
this.b("progress",this.ye);
this.b("durationchange",this.Wc);
this.b("fullscreenchange",this.we);
return a
};
function ka(a,c,d){a.h&&(a.wa=l,a.h.dispose(),a.h=l);
"Html5"!==c&&a.L&&(t.f.Mb(a.L),a.L=j);
a.Ua=c;
a.wa=l;
var e=t.i.D({source:d,parentEl:a.c},a.q[c.toLowerCase()]);
d&&(a.Gc=d.type,d.src==a.K.src&&0<a.K.currentTime&&(e.startTime=a.K.currentTime),a.K.src=d.src);
a.h=new window.videojs[c](a,e);
a.h.I(function(){this.d.Wa()
})
}s.xe=function(){this.r("vjs-ended");
this.error(j);
this.paused()?la(this,l):this.o("firstplay")
};
s.Nc=l;
function la(a,c){c!==b&&a.Nc!==c&&((a.Nc=c)?(a.p("vjs-has-started"),a.o("firstplay")):a.r("vjs-has-started"))
}s.$b=function(){this.r("vjs-ended");
this.r("vjs-paused");
this.p("vjs-playing");
la(this,f)
};
s.De=function(){this.p("vjs-waiting")
};
s.Ce=function(){this.r("vjs-waiting")
};
s.Ae=function(){this.p("vjs-seeking")
};
s.ze=function(){this.r("vjs-seeking")
};
s.ve=function(){this.q.starttime&&this.currentTime(this.q.starttime);
this.p("vjs-has-started")
};
s.Zb=function(){this.r("vjs-playing");
this.p("vjs-paused")
};
s.ye=function(){1==this.bufferedPercent()&&this.o("loadedalldata")
};
s.ue=function(){this.p("vjs-ended");
this.q.loop?(this.currentTime(0),this.play()):this.paused()||this.pause()
};
s.Wc=function(){var a=M(this,"duration");
a&&(0>a&&(a=Infinity),this.duration(a),Infinity===a?this.p("vjs-live"):this.r("vjs-live"))
};
s.we=function(){this.isFullscreen()?this.p("vjs-fullscreen"):this.r("vjs-fullscreen")
};
function N(a,c,d){if(a.h&&!a.h.wa){a.h.I(function(){this[c](d)
})
}else{try{a.h[c](d)
}catch(e){throw t.log(e),e
}}}function M(a,c){if(a.h&&a.h.wa){try{return a.h[c]()
}catch(d){throw a.h[c]===b?t.log("Video.js: "+c+" method not defined for "+a.Ua+" playback technology.",d):"TypeError"==d.name?(t.log("Video.js: "+c+" unavailable on "+a.Ua+" playback technology element.",d),a.h.wa=l):t.log(d),d
}}}s.play=function(){N(this,"play");
return this
};
s.pause=function(){N(this,"pause");
return this
};
s.paused=function(){return M(this,"paused")===l?l:f
};
s.currentTime=function(a){return a!==b?(N(this,"setCurrentTime",a),this):this.K.currentTime=M(this,"currentTime")||0
};
s.duration=function(a){if(a!==b){return this.K.duration=parseFloat(a),this
}this.K.duration===b&&this.Wc();
return this.K.duration||0
};
s.remainingTime=function(){return this.duration()-this.currentTime()
};
s.buffered=function(){var a=M(this,"buffered");
if(!a||!a.length){a=t.Lb(0,0)
}return a
};
s.bufferedPercent=function(){var a=this.duration(),c=this.buffered(),d=0,e,g;
if(!a){return 0
}for(var h=0;
h<c.length;
h++){e=c.start(h),g=c.end(h),g>a&&(g=a),d+=g-e
}return d/a
};
s.volume=function(a){if(a!==b){return a=Math.max(0,Math.min(1,parseFloat(a))),this.K.volume=a,N(this,"setVolume",a),t.Me(a),this
}a=parseFloat(M(this,"volume"));
return isNaN(a)?1:a
};
s.muted=function(a){return a!==b?(N(this,"setMuted",a),this):M(this,"muted")||l
};
s.Ta=function(){return M(this,"supportsFullScreen")||l
};
s.Qc=l;
s.isFullscreen=function(a){return a!==b?(this.Qc=!!a,this):this.Qc
};
s.isFullScreen=function(a){t.log.warn('player.isFullScreen() has been deprecated, use player.isFullscreen() with a lowercase "s")');
return this.isFullscreen(a)
};
s.requestFullscreen=function(){var a=t.cb.Rb;
this.isFullscreen(f);
a?(t.b(document,a.fullscreenchange,t.bind(this,function(c){this.isFullscreen(document[a.fullscreenElement]);
this.isFullscreen()===l&&t.n(document,a.fullscreenchange,arguments.callee);
this.o("fullscreenchange")
})),this.c[a.requestFullscreen]()):this.h.Ta()?N(this,"enterFullScreen"):(this.Jc(),this.o("fullscreenchange"));
return this
};
s.requestFullScreen=function(){t.log.warn('player.requestFullScreen() has been deprecated, use player.requestFullscreen() with a lowercase "s")');
return this.requestFullscreen()
};
s.exitFullscreen=function(){var a=t.cb.Rb;
this.isFullscreen(l);
if(a){document[a.exitFullscreen]()
}else{this.h.Ta()?N(this,"exitFullScreen"):(this.Nb(),this.o("fullscreenchange"))
}return this
};
s.cancelFullScreen=function(){t.log.warn("player.cancelFullScreen() has been deprecated, use player.exitFullscreen()");
return this.exitFullscreen()
};
s.Jc=function(){this.je=f;
this.Ud=document.documentElement.style.overflow;
t.b(document,"keydown",t.bind(this,this.Kc));
document.documentElement.style.overflow="hidden";
t.p(document.body,"vjs-full-window");
this.o("enterFullWindow")
};
s.Kc=function(a){27===a.keyCode&&(this.isFullscreen()===f?this.exitFullscreen():this.Nb())
};
s.Nb=function(){this.je=l;
t.n(document,"keydown",this.Kc);
document.documentElement.style.overflow=this.Ud;
t.r(document.body,"vjs-full-window");
this.o("exitFullWindow")
};
s.selectSource=function(a){for(var c=0,d=this.q.techOrder;
c<d.length;
c++){var e=t.ua(d[c]),g=window.videojs[e];
if(g){if(g.isSupported()){for(var h=0,k=a;
h<k.length;
h++){var p=k[h];
if(g.canPlaySource(p)){return{source:p,h:e}
}}}}else{t.log.error('The "'+e+'" tech is undefined. Skipped browser support check for that tech.')
}}return l
};
s.src=function(a){if(a===b){return M(this,"src")
}t.i.isArray(a)?ma(this,a):"string"===typeof a?this.src({src:a}):a instanceof Object&&(a.type&&!window.videojs[this.Ua].canPlaySource(a)?ma(this,[a]):(this.K.src=a.src,this.Gc=a.type||"",this.I(function(){window.videojs[this.Ua].prototype.hasOwnProperty("setSource")?N(this,"setSource",a):N(this,"src",a.src);
"auto"==this.q.preload&&this.load();
this.q.autoplay&&this.play()
})));
return this
};
function ma(a,c){var d=a.selectSource(c);
d?d.h===a.Ua?a.src(d.source):ka(a,d.h,d.source):(a.setTimeout(function(){this.error({code:4,message:this.v(this.options().notSupportedMessage)})
},0),a.Wa())
}s.load=function(){N(this,"load");
return this
};
s.currentSrc=function(){return M(this,"currentSrc")||this.K.src||""
};
s.Qd=function(){return this.Gc||""
};
s.Qa=function(a){return a!==b?(N(this,"setPreload",a),this.q.preload=a,this):M(this,"preload")
};
s.autoplay=function(a){return a!==b?(N(this,"setAutoplay",a),this.q.autoplay=a,this):M(this,"autoplay")
};
s.loop=function(a){return a!==b?(N(this,"setLoop",a),this.q.loop=a,this):M(this,"loop")
};
s.poster=function(a){if(a===b){return this.Zc
}a||(a="");
this.Zc=a;
N(this,"setPoster",a);
this.o("posterchange");
return this
};
s.controls=function(a){return a!==b?(a=!!a,this.Kb!==a&&((this.Kb=a)?(this.r("vjs-controls-disabled"),this.p("vjs-controls-enabled"),this.o("controlsenabled")):(this.r("vjs-controls-enabled"),this.p("vjs-controls-disabled"),this.o("controlsdisabled"))),this):this.Kb
};
t.Player.prototype.ec;
s=t.Player.prototype;
s.usingNativeControls=function(a){return a!==b?(a=!!a,this.ec!==a&&((this.ec=a)?(this.p("vjs-using-native-controls"),this.o("usingnativecontrols")):(this.r("vjs-using-native-controls"),this.o("usingcustomcontrols"))),this):this.ec
};
s.ia=j;
s.error=function(a){if(a===b){return this.ia
}if(a===j){return this.ia=a,this.r("vjs-error"),this
}this.ia=a instanceof t.J?a:new t.J(a);
this.o("error");
this.p("vjs-error");
t.log.error("(CODE:"+this.ia.code+" "+t.J.hb[this.ia.code]+")",this.ia.message,this.ia);
return this
};
s.ended=function(){return M(this,"ended")
};
s.seeking=function(){return M(this,"seeking")
};
s.Da=f;
s.reportUserActivity=function(){this.Da=f
};
s.dc=f;
s.userActive=function(a){return a!==b?(a=!!a,a!==this.dc&&((this.dc=a)?(this.Da=f,this.r("vjs-user-inactive"),this.p("vjs-user-active"),this.o("useractive")):(this.Da=l,this.h&&this.h.N("mousemove",function(a){a.stopPropagation();
a.preventDefault()
}),this.r("vjs-user-active"),this.p("vjs-user-inactive"),this.o("userinactive"))),this):this.dc
};
s.playbackRate=function(a){return a!==b?(N(this,"setPlaybackRate",a),this):this.h&&this.h.featuresPlaybackRate?M(this,"playbackRate"):1
};
s.Pc=l;
function ja(a,c){return c!==b?(a.Pc=!!c,a):a.Pc
}s.networkState=function(){return M(this,"networkState")
};
s.readyState=function(){return M(this,"readyState")
};
s.textTracks=function(){return this.h&&this.h.textTracks()
};
s.Z=function(){return this.h&&this.h.remoteTextTracks()
};
s.addTextTrack=function(a,c,d){return this.h&&this.h.addTextTrack(a,c,d)
};
s.ha=function(a){return this.h&&this.h.addRemoteTextTrack(a)
};
s.Ba=function(a){this.h&&this.h.removeRemoteTextTrack(a)
};
t.ub=t.a.extend();
t.ub.prototype.q={wf:"play",children:{playToggle:{},currentTimeDisplay:{},timeDivider:{},durationDisplay:{},remainingTimeDisplay:{},liveDisplay:{},progressControl:{},fullscreenToggle:{},volumeControl:{},muteToggle:{},playbackRateMenuButton:{},subtitlesButton:{},captionsButton:{},chaptersButton:{}}};
t.ub.prototype.e=function(){return t.e("div",{className:"vjs-control-bar"})
};
t.kc=t.a.extend({l:function(a,c){t.a.call(this,a,c)
}});
t.kc.prototype.e=function(){var a=t.a.prototype.e.call(this,"div",{className:"vjs-live-controls vjs-control"});
this.B=t.e("div",{className:"vjs-live-display",innerHTML:'<span class="vjs-control-text">'+this.v("Stream Type")+"</span>"+this.v("LIVE"),"aria-live":"off"});
a.appendChild(this.B);
return a
};
t.nc=t.w.extend({l:function(a,c){t.w.call(this,a,c);
this.b(a,"play",this.$b);
this.b(a,"pause",this.Zb)
}});
s=t.nc.prototype;
s.sa="Play";
s.V=function(){return"vjs-play-control "+t.w.prototype.V.call(this)
};
s.u=function(){this.d.paused()?this.d.play():this.d.pause()
};
s.$b=function(){this.r("vjs-paused");
this.p("vjs-playing");
this.c.children[0].children[0].innerHTML=this.v("Pause")
};
s.Zb=function(){this.r("vjs-playing");
this.p("vjs-paused");
this.c.children[0].children[0].innerHTML=this.v("Play")
};
t.vb=t.a.extend({l:function(a,c){t.a.call(this,a,c);
this.b(a,"timeupdate",this.ma)
}});
t.vb.prototype.e=function(){var a=t.a.prototype.e.call(this,"div",{className:"vjs-current-time vjs-time-controls vjs-control"});
this.B=t.e("div",{className:"vjs-current-time-display",innerHTML:'<span class="vjs-control-text">Current Time </span>0:00',"aria-live":"off"});
a.appendChild(this.B);
return a
};
t.vb.prototype.ma=function(){var a=this.d.ob?this.d.K.currentTime:this.d.currentTime();
this.B.innerHTML='<span class="vjs-control-text">'+this.v("Current Time")+"</span> "+t.Ma(a,this.d.duration())
};
t.wb=t.a.extend({l:function(a,c){t.a.call(this,a,c);
this.b(a,"timeupdate",this.ma)
}});
t.wb.prototype.e=function(){var a=t.a.prototype.e.call(this,"div",{className:"vjs-duration vjs-time-controls vjs-control"});
this.B=t.e("div",{className:"vjs-duration-display",innerHTML:'<span class="vjs-control-text">'+this.v("Duration Time")+"</span> 0:00","aria-live":"off"});
a.appendChild(this.B);
return a
};
t.wb.prototype.ma=function(){var a=this.d.duration();
a&&(this.B.innerHTML='<span class="vjs-control-text">'+this.v("Duration Time")+"</span> "+t.Ma(a))
};
t.tc=t.a.extend({l:function(a,c){t.a.call(this,a,c)
}});
t.tc.prototype.e=function(){return t.a.prototype.e.call(this,"div",{className:"vjs-time-divider",innerHTML:"<div><span>/</span></div>"})
};
t.Db=t.a.extend({l:function(a,c){t.a.call(this,a,c);
this.b(a,"timeupdate",this.ma)
}});
t.Db.prototype.e=function(){var a=t.a.prototype.e.call(this,"div",{className:"vjs-remaining-time vjs-time-controls vjs-control"});
this.B=t.e("div",{className:"vjs-remaining-time-display",innerHTML:'<span class="vjs-control-text">'+this.v("Remaining Time")+"</span> -0:00","aria-live":"off"});
a.appendChild(this.B);
return a
};
t.Db.prototype.ma=function(){this.d.duration()&&(this.B.innerHTML='<span class="vjs-control-text">'+this.v("Remaining Time")+"</span> -"+t.Ma(this.d.remainingTime()))
};
t.Za=t.w.extend({l:function(a,c){t.w.call(this,a,c)
}});
t.Za.prototype.sa="Fullscreen";
t.Za.prototype.V=function(){return"vjs-fullscreen-control "+t.w.prototype.V.call(this)
};
t.Za.prototype.u=function(){this.d.isFullscreen()?(this.d.exitFullscreen(),this.Jb.innerHTML=this.v("Fullscreen")):(this.d.requestFullscreen(),this.Jb.innerHTML=this.v("Non-Fullscreen"))
};
t.Cb=t.a.extend({l:function(a,c){t.a.call(this,a,c)
}});
t.Cb.prototype.q={children:{seekBar:{}}};
t.Cb.prototype.e=function(){return t.a.prototype.e.call(this,"div",{className:"vjs-progress-control vjs-control"})
};
t.qc=t.U.extend({l:function(a,c){t.U.call(this,a,c);
this.b(a,"timeupdate",this.Ca);
a.I(t.bind(this,this.Ca))
}});
s=t.qc.prototype;
s.q={children:{loadProgressBar:{},playProgressBar:{},seekHandle:{}},barName:"playProgressBar",handleName:"seekHandle"};
s.Yc="timeupdate";
s.e=function(){return t.U.prototype.e.call(this,"div",{className:"vjs-progress-holder","aria-label":"video progress bar"})
};
s.Ca=function(){var a=this.d.ob?this.d.K.currentTime:this.d.currentTime();
this.c.setAttribute("aria-valuenow",t.round(100*this.Sb(),2));
this.c.setAttribute("aria-valuetext",t.Ma(a,this.d.duration()))
};
s.Sb=function(){return this.d.currentTime()/this.d.duration()
};
s.mb=function(a){t.U.prototype.mb.call(this,a);
this.d.ob=f;
this.d.p("vjs-scrubbing");
this.df=!this.d.paused();
this.d.pause()
};
s.ka=function(a){a=ea(this,a)*this.d.duration();
a==this.d.duration()&&(a-=0.1);
this.d.currentTime(a)
};
s.za=function(a){t.U.prototype.za.call(this,a);
this.d.ob=l;
this.d.r("vjs-scrubbing");
this.df&&this.d.play()
};
s.kd=function(){this.d.currentTime(this.d.currentTime()+5)
};
s.jd=function(){this.d.currentTime(this.d.currentTime()-5)
};
t.zb=t.a.extend({l:function(a,c){t.a.call(this,a,c);
this.b(a,"progress",this.update)
}});
t.zb.prototype.e=function(){return t.a.prototype.e.call(this,"div",{className:"vjs-load-progress",innerHTML:'<span class="vjs-control-text"><span>'+this.v("Loaded")+"</span>: 0%</span>"})
};
t.zb.prototype.update=function(){var a,c,d,e,g=this.d.buffered();
a=this.d.duration();
var h,k=this.d;
h=k.buffered();
k=k.duration();
h=h.end(h.length-1);
h>k&&(h=k);
k=this.c.children;
this.c.style.width=100*(h/a||0)+"%";
for(a=0;
a<g.length;
a++){c=g.start(a),d=g.end(a),(e=k[a])||(e=this.c.appendChild(t.e())),e.style.left=100*(c/h||0)+"%",e.style.width=100*((d-c)/h||0)+"%"
}for(a=k.length;
a>g.length;
a--){this.c.removeChild(k[a-1])
}};
t.mc=t.a.extend({l:function(a,c){t.a.call(this,a,c)
}});
t.mc.prototype.e=function(){return t.a.prototype.e.call(this,"div",{className:"vjs-play-progress",innerHTML:'<span class="vjs-control-text"><span>'+this.v("Progress")+"</span>: 0%</span>"})
};
t.$a=t.ga.extend({l:function(a,c){t.ga.call(this,a,c);
this.b(a,"timeupdate",this.ma)
}});
t.$a.prototype.defaultValue="00:00";
t.$a.prototype.e=function(){return t.ga.prototype.e.call(this,"div",{className:"vjs-seek-handle","aria-live":"off"})
};
t.$a.prototype.ma=function(){var a=this.d.ob?this.d.K.currentTime:this.d.currentTime();
this.c.innerHTML='<span class="vjs-control-text">'+t.Ma(a,this.d.duration())+"</span>"
};
t.Gb=t.a.extend({l:function(a,c){t.a.call(this,a,c);
a.h&&a.h.featuresVolumeControl===l&&this.p("vjs-hidden");
this.b(a,"loadstart",function(){a.h.featuresVolumeControl===l?this.p("vjs-hidden"):this.r("vjs-hidden")
})
}});
t.Gb.prototype.q={children:{volumeBar:{}}};
t.Gb.prototype.e=function(){return t.a.prototype.e.call(this,"div",{className:"vjs-volume-control vjs-control"})
};
t.Fb=t.U.extend({l:function(a,c){t.U.call(this,a,c);
this.b(a,"volumechange",this.Ca);
a.I(t.bind(this,this.Ca))
}});
s=t.Fb.prototype;
s.Ca=function(){this.c.setAttribute("aria-valuenow",t.round(100*this.d.volume(),2));
this.c.setAttribute("aria-valuetext",t.round(100*this.d.volume(),2)+"%")
};
s.q={children:{volumeLevel:{},volumeHandle:{}},barName:"volumeLevel",handleName:"volumeHandle"};
s.Yc="volumechange";
s.e=function(){return t.U.prototype.e.call(this,"div",{className:"vjs-volume-bar","aria-label":"volume level"})
};
s.ka=function(a){this.d.muted()&&this.d.muted(l);
this.d.volume(ea(this,a))
};
s.Sb=function(){return this.d.muted()?0:this.d.volume()
};
s.kd=function(){this.d.volume(this.d.volume()+0.1)
};
s.jd=function(){this.d.volume(this.d.volume()-0.1)
};
t.uc=t.a.extend({l:function(a,c){t.a.call(this,a,c)
}});
t.uc.prototype.e=function(){return t.a.prototype.e.call(this,"div",{className:"vjs-volume-level",innerHTML:'<span class="vjs-control-text"></span>'})
};
t.Hb=t.ga.extend();
t.Hb.prototype.defaultValue="00:00";
t.Hb.prototype.e=function(){return t.ga.prototype.e.call(this,"div",{className:"vjs-volume-handle"})
};
t.qa=t.w.extend({l:function(a,c){t.w.call(this,a,c);
this.b(a,"volumechange",this.update);
a.h&&a.h.featuresVolumeControl===l&&this.p("vjs-hidden");
this.b(a,"loadstart",function(){a.h.featuresVolumeControl===l?this.p("vjs-hidden"):this.r("vjs-hidden")
})
}});
t.qa.prototype.e=function(){return t.w.prototype.e.call(this,"div",{className:"vjs-mute-control vjs-control",innerHTML:'<div><span class="vjs-control-text">'+this.v("Mute")+"</span></div>"})
};
t.qa.prototype.u=function(){this.d.muted(this.d.muted()?l:f)
};
t.qa.prototype.update=function(){var a=this.d.volume(),c=3;
0===a||this.d.muted()?c=0:0.33>a?c=1:0.67>a&&(c=2);
this.d.muted()?this.c.children[0].children[0].innerHTML!=this.v("Unmute")&&(this.c.children[0].children[0].innerHTML=this.v("Unmute")):this.c.children[0].children[0].innerHTML!=this.v("Mute")&&(this.c.children[0].children[0].innerHTML=this.v("Mute"));
for(a=0;
4>a;
a++){t.r(this.c,"vjs-vol-"+a)
}t.p(this.c,"vjs-vol-"+c)
};
t.Fa=t.O.extend({l:function(a,c){t.O.call(this,a,c);
this.b(a,"volumechange",this.ef);
a.h&&a.h.featuresVolumeControl===l&&this.p("vjs-hidden");
this.b(a,"loadstart",function(){a.h.featuresVolumeControl===l?this.p("vjs-hidden"):this.r("vjs-hidden")
});
this.p("vjs-menu-button")
}});
t.Fa.prototype.Ja=function(){var a=new t.pa(this.d,{Cc:"div"}),c=new t.Fb(this.d,this.q.volumeBar);
c.b("focus",function(){a.p("vjs-lock-showing")
});
c.b("blur",function(){G(a)
});
a.ba(c);
return a
};
t.Fa.prototype.u=function(){t.qa.prototype.u.call(this);
t.O.prototype.u.call(this)
};
t.Fa.prototype.e=function(){return t.w.prototype.e.call(this,"div",{className:"vjs-volume-menu-button vjs-menu-button vjs-control",innerHTML:'<div><span class="vjs-control-text">'+this.v("Mute")+"</span></div>"})
};
t.Fa.prototype.ef=t.qa.prototype.update;
t.oc=t.O.extend({l:function(a,c){t.O.call(this,a,c);
this.sd();
this.rd();
this.b(a,"loadstart",this.sd);
this.b(a,"ratechange",this.rd)
}});
s=t.oc.prototype;
s.sa="Playback Rate";
s.className="vjs-playback-rate";
s.e=function(){var a=t.O.prototype.e.call(this);
this.Sc=t.e("div",{className:"vjs-playback-rate-value",innerHTML:1});
a.appendChild(this.Sc);
return a
};
s.Ja=function(){var a=new t.pa(this.k()),c=this.k().options().playbackRates;
if(c){for(var d=c.length-1;
0<=d;
d--){a.ba(new t.Bb(this.k(),{rate:c[d]+"x"}))
}}return a
};
s.Ca=function(){this.m().setAttribute("aria-valuenow",this.k().playbackRate())
};
s.u=function(){for(var a=this.k().playbackRate(),c=this.k().options().playbackRates,d=c[0],e=0;
e<c.length;
e++){if(c[e]>a){d=c[e];
break
}}this.k().playbackRate(d)
};
function na(a){return a.k().h&&a.k().h.featuresPlaybackRate&&a.k().options().playbackRates&&0<a.k().options().playbackRates.length
}s.sd=function(){na(this)?this.r("vjs-hidden"):this.p("vjs-hidden")
};
s.rd=function(){na(this)&&(this.Sc.innerHTML=this.k().playbackRate()+"x")
};
t.Bb=t.M.extend({Cc:"button",l:function(a,c){var d=this.label=c.rate,e=this.$c=parseFloat(d,10);
c.label=d;
c.selected=1===e;
t.M.call(this,a,c);
this.b(a,"ratechange",this.update)
}});
t.Bb.prototype.u=function(){t.M.prototype.u.call(this);
this.k().playbackRate(this.$c)
};
t.Bb.prototype.update=function(){this.selected(this.k().playbackRate()==this.$c)
};
t.pc=t.w.extend({l:function(a,c){t.w.call(this,a,c);
this.update();
a.b("posterchange",t.bind(this,this.update))
}});
s=t.pc.prototype;
s.dispose=function(){this.k().n("posterchange",this.update);
t.w.prototype.dispose.call(this)
};
s.e=function(){var a=t.e("div",{className:"vjs-poster",tabIndex:-1});
t.wd||(this.Ob=t.e("img"),a.appendChild(this.Ob));
return a
};
s.update=function(){var a=this.k().poster();
this.la(a);
a?this.show():this.Y()
};
s.la=function(a){var c;
this.Ob?this.Ob.src=a:(c="",a&&(c='url("'+a+'")'),this.c.style.backgroundImage=c)
};
s.u=function(){this.d.play()
};
t.lc=t.a.extend({l:function(a,c){t.a.call(this,a,c)
}});
t.lc.prototype.e=function(){return t.a.prototype.e.call(this,"div",{className:"vjs-loading-spinner"})
};
t.sb=t.w.extend();
t.sb.prototype.e=function(){return t.w.prototype.e.call(this,"div",{className:"vjs-big-play-button",innerHTML:'<span aria-hidden="true"></span>',"aria-label":"play video"})
};
t.sb.prototype.u=function(){this.d.play()
};
t.xb=t.a.extend({l:function(a,c){t.a.call(this,a,c);
this.update();
this.b(a,"error",this.update)
}});
t.xb.prototype.e=function(){var a=t.a.prototype.e.call(this,"div",{className:"vjs-error-display"});
this.B=t.e("div");
a.appendChild(this.B);
return a
};
t.xb.prototype.update=function(){this.k().error()&&(this.B.innerHTML=this.v(this.k().error().message))
};
var O;
t.j=t.a.extend({l:function(a,c,d){c=c||{};
c.dd=l;
t.a.call(this,a,c,d);
this.featuresProgressEvents||this.re();
this.featuresTimeupdateEvents||this.se();
this.fe();
this.featuresNativeTextTracks||this.Vd();
this.he()
}});
s=t.j.prototype;
s.fe=function(){var a,c;
a=this.k();
c=function(){a.controls()&&!a.usingNativeControls()&&this.Id()
};
this.I(c);
this.b(a,"controlsenabled",c);
this.b(a,"controlsdisabled",this.He);
this.I(function(){this.networkState&&0<this.networkState()&&this.k().o("loadstart")
})
};
s.Id=function(){var a;
this.b("mousedown",this.u);
this.b("touchstart",function(){a=this.d.userActive()
});
this.b("touchmove",function(){a&&this.k().reportUserActivity()
});
this.b("touchend",function(a){a.preventDefault()
});
da(this);
this.b("tap",this.Be)
};
s.He=function(){this.n("tap");
this.n("touchstart");
this.n("touchmove");
this.n("touchleave");
this.n("touchcancel");
this.n("touchend");
this.n("click");
this.n("mousedown")
};
s.u=function(a){0===a.button&&this.k().controls()&&(this.k().paused()?this.k().play():this.k().pause())
};
s.Be=function(){this.k().userActive(!this.k().userActive())
};
s.re=function(){this.Uc=f;
this.$e()
};
s.qe=function(){this.Uc=l;
this.ld()
};
s.$e=function(){this.Ge=this.setInterval(function(){var a=this.k().bufferedPercent();
this.Md!=a&&this.k().o("progress");
this.Md=a;
1===a&&this.ld()
},500)
};
s.ld=function(){this.clearInterval(this.Ge)
};
s.se=function(){var a=this.d;
this.Yb=f;
this.b(a,"play",this.pd);
this.b(a,"pause",this.rb);
this.N("timeupdate",function(){this.featuresTimeupdateEvents=f;
this.Vc()
})
};
s.Vc=function(){var a=this.d;
this.Yb=l;
this.rb();
this.n(a,"play",this.pd);
this.n(a,"pause",this.rb)
};
s.pd=function(){this.Fc&&this.rb();
this.Fc=this.setInterval(function(){this.k().o("timeupdate")
},250)
};
s.rb=function(){this.clearInterval(this.Fc);
this.k().o("timeupdate")
};
s.dispose=function(){this.Uc&&this.qe();
this.Yb&&this.Vc();
t.a.prototype.dispose.call(this)
};
s.bc=function(){this.Yb&&this.k().o("timeupdate")
};
s.he=function(){function a(){var a=c.ea("textTrackDisplay");
a&&a.C()
}var c=this.d,d;
if(d=this.textTracks()){d.addEventListener("removetrack",a),d.addEventListener("addtrack",a),this.b("dispose",t.bind(this,function(){d.removeEventListener("removetrack",a);
d.removeEventListener("addtrack",a)
}))
}};
s.Vd=function(){var a=this.d,c,d,e;
window.WebVTT||(e=document.createElement("script"),e.src=a.options()["vtt.js"]||"../node_modules/vtt.js/dist/vtt.js",a.m().appendChild(e),window.WebVTT=f);
if(d=this.textTracks()){c=function(){var c,d,e;
e=a.ea("textTrackDisplay");
e.C();
for(c=0;
c<this.length;
c++){d=this[c],d.removeEventListener("cuechange",t.bind(e,e.C)),"showing"===d.mode&&d.addEventListener("cuechange",t.bind(e,e.C))
}},d.addEventListener("change",c),this.b("dispose",t.bind(this,function(){d.removeEventListener("change",c)
}))
}};
s.textTracks=function(){this.d.od=this.d.od||new t.F;
return this.d.od
};
s.Z=function(){this.d.ad=this.d.ad||new t.F;
return this.d.ad
};
O=function(a,c,d,e,g){var h=a.textTracks();
g=g||{};
g.kind=c;
d&&(g.label=d);
e&&(g.language=e);
g.player=a.d;
a=new t.t(g);
P(h,a);
return a
};
t.j.prototype.addTextTrack=function(a,c,d){if(!a){throw Error("TextTrack kind is required but was not provided")
}return O(this,a,c,d)
};
t.j.prototype.ha=function(a){a=O(this,a.kind,a.label,a.language,a);
P(this.Z(),a);
return{T:a}
};
t.j.prototype.Ba=function(a){Q(this.textTracks(),a);
Q(this.Z(),a)
};
t.j.prototype.fd=m();
t.j.prototype.featuresVolumeControl=f;
t.j.prototype.featuresFullscreenResize=l;
t.j.prototype.featuresPlaybackRate=l;
t.j.prototype.featuresProgressEvents=l;
t.j.prototype.featuresTimeupdateEvents=l;
t.j.prototype.featuresNativeTextTracks=l;
t.j.gc=function(a){a.Ra=function(c,d){var e=a.gd;
e||(e=a.gd=[]);
d===b&&(d=e.length);
e.splice(d,0,c)
};
a.pb=function(c){for(var d=a.gd||[],e,g=0;
g<d.length;
g++){if(e=d[g].eb(c)){return d[g]
}}return j
};
a.zc=function(c){var d=a.pb(c);
return d?d.eb(c):""
};
a.prototype.Sa=function(c){var d=a.pb(c);
d||(a.S?d=a.S:t.log.error("No source hander found for the current source."));
this.Ka();
this.n("dispose",this.Ka);
this.Ec=c;
this.cc=d.Tb(c,this);
this.b("dispose",this.Ka);
return this
};
a.prototype.Ka=function(){this.cc&&this.cc.dispose&&this.cc.dispose()
}
};
t.media={};
t.f=t.j.extend({l:function(a,c,d){var e,g,h;
if(c.nativeCaptions===l||c.nativeTextTracks===l){this.featuresNativeTextTracks=l
}t.j.call(this,a,c,d);
for(d=t.f.yb.length-1;
0<=d;
d--){this.b(t.f.yb[d],this.Wd)
}(c=c.source)&&(this.c.currentSrc!==c.src||a.L&&3===a.L.ge)&&this.Sa(c);
if(this.c.hasChildNodes()){d=this.c.childNodes;
e=d.length;
for(c=[];
e--;
){g=d[e],h=g.nodeName.toLowerCase(),"track"===h&&(this.featuresNativeTextTracks?P(this.Z(),g.track):c.push(g))
}for(d=0;
d<c.length;
d++){this.c.removeChild(c[d])
}}this.featuresNativeTextTracks&&this.b("loadstart",t.bind(this,this.ee));
if(t.Eb&&a.options().nativeControlsForTouch===f){var k,p,r,u;
k=this;
p=this.k();
c=p.controls();
k.c.controls=!!c;
r=function(){k.c.controls=f
};
u=function(){k.c.controls=l
};
p.b("controlsenabled",r);
p.b("controlsdisabled",u);
c=function(){p.n("controlsenabled",r);
p.n("controlsdisabled",u)
};
k.b("dispose",c);
p.b("usingcustomcontrols",c);
p.usingNativeControls(f)
}a.I(function(){this.L&&(this.q.autoplay&&this.paused())&&(delete this.L.poster,this.play())
});
this.Wa()
}});
s=t.f.prototype;
s.dispose=function(){t.f.Mb(this.c);
t.j.prototype.dispose.call(this)
};
s.e=function(){var a=this.d,c,d,e,g=a.L;
if(!g||this.movingMediaElementInDOM===l){g?(e=g.cloneNode(l),t.f.Mb(g),g=e,a.L=j):(g=t.e("video"),e=videojs.$.ya({},a.Xe),(!t.Eb||a.options().nativeControlsForTouch!==f)&&delete e.controls,t.ed(g,t.i.D(e,{id:a.id()+"_html5_api","class":"vjs-tech"})));
g.player=a;
if(a.q.qd){for(e=0;
e<a.q.qd.length;
e++){c=a.q.qd[e],d=document.createElement("track"),d.Wb=c.Wb,d.label=c.label,d.hd=c.hd,d.src=c.src,"default" in c&&d.setAttribute("default","default"),g.appendChild(d)
}}t.Ub(g,a.m())
}c=["autoplay","preload","loop","muted"];
for(e=c.length-1;
0<=e;
e--){d=c[e];
var h={};
"undefined"!==typeof a.q[d]&&(h[d]=a.q[d]);
t.ed(g,h)
}return g
};
s.ee=function(){for(var a=this.c.querySelectorAll("track"),c,d=a.length,e={captions:1,subtitles:1};
d--;
){if((c=a[d].T)&&c.kind in e&&!a[d]["default"]){c.mode="disabled"
}}};
s.Wd=function(a){"error"==a.type&&this.error()?this.k().error(this.error().code):(a.bubbles=l,this.k().o(a))
};
s.play=function(){this.c.play()
};
s.pause=function(){this.c.pause()
};
s.paused=function(){return this.c.paused
};
s.currentTime=function(){return this.c.currentTime
};
s.bc=function(a){try{this.c.currentTime=a
}catch(c){t.log(c,"Video is not ready. (Video.js)")
}};
s.duration=function(){return this.c.duration||0
};
s.buffered=function(){return this.c.buffered
};
s.volume=function(){return this.c.volume
};
s.Se=function(a){this.c.volume=a
};
s.muted=function(){return this.c.muted
};
s.Oe=function(a){this.c.muted=a
};
s.width=function(){return this.c.offsetWidth
};
s.height=function(){return this.c.offsetHeight
};
s.Ta=function(){return"function"==typeof this.c.webkitEnterFullScreen&&(/Android/.test(t.P)||!/Chrome|Mac OS X 10.5/.test(t.P))?f:l
};
s.Ic=function(){var a=this.c;
"webkitDisplayingFullscreen" in a&&this.N("webkitbeginfullscreen",function(){this.d.isFullscreen(f);
this.N("webkitendfullscreen",function(){this.d.isFullscreen(l);
this.d.o("fullscreenchange")
});
this.d.o("fullscreenchange")
});
a.paused&&a.networkState<=a.jf?(this.c.play(),this.setTimeout(function(){a.pause();
a.webkitEnterFullScreen()
},0)):a.webkitEnterFullScreen()
};
s.Xd=function(){this.c.webkitExitFullScreen()
};
s.src=function(a){if(a===b){return this.c.src
}this.la(a)
};
s.la=function(a){this.c.src=a
};
s.load=function(){this.c.load()
};
s.currentSrc=function(){return this.c.currentSrc
};
s.poster=function(){return this.c.poster
};
s.fd=function(a){this.c.poster=a
};
s.Qa=function(){return this.c.Qa
};
s.Qe=function(a){this.c.Qa=a
};
s.autoplay=function(){return this.c.autoplay
};
s.Le=function(a){this.c.autoplay=a
};
s.controls=function(){return this.c.controls
};
s.loop=function(){return this.c.loop
};
s.Ne=function(a){this.c.loop=a
};
s.error=function(){return this.c.error
};
s.seeking=function(){return this.c.seeking
};
s.ended=function(){return this.c.ended
};
s.playbackRate=function(){return this.c.playbackRate
};
s.Pe=function(a){this.c.playbackRate=a
};
s.networkState=function(){return this.c.networkState
};
s.readyState=function(){return this.c.readyState
};
s.textTracks=function(){return !this.featuresNativeTextTracks?t.j.prototype.textTracks.call(this):this.c.textTracks
};
s.addTextTrack=function(a,c,d){return !this.featuresNativeTextTracks?t.j.prototype.addTextTrack.call(this,a,c,d):this.c.addTextTrack(a,c,d)
};
s.ha=function(a){if(!this.featuresNativeTextTracks){return t.j.prototype.ha.call(this,a)
}var c=document.createElement("track");
a=a||{};
a.kind&&(c.kind=a.kind);
a.label&&(c.label=a.label);
if(a.language||a.srclang){c.srclang=a.language||a.srclang
}a["default"]&&(c["default"]=a["default"]);
a.id&&(c.id=a.id);
a.src&&(c.src=a.src);
this.m().appendChild(c);
c.track.mode="metadata"===c.T.kind?"hidden":"disabled";
c.onload=function(){var a=c.track;
2<=c.readyState&&("metadata"===a.kind&&"hidden"!==a.mode?a.mode="hidden":"metadata"!==a.kind&&"disabled"!==a.mode&&(a.mode="disabled"),c.onload=j)
};
P(this.Z(),c.T);
return c
};
s.Ba=function(a){if(!this.featuresNativeTextTracks){return t.j.prototype.Ba.call(this,a)
}var c,d;
Q(this.Z(),a);
c=this.m().querySelectorAll("track");
for(d=0;
d<c.length;
d++){if(c[d]===a||c[d].track===a){c[d].parentNode.removeChild(c[d]);
break
}}};
t.f.isSupported=function(){try{t.A.volume=0.5
}catch(a){return l
}return !!t.A.canPlayType
};
t.j.gc(t.f);
t.f.S={};
t.f.S.eb=function(a){function c(a){try{return t.A.canPlayType(a)
}catch(c){return""
}}return a.type?c(a.type):a.src?(a=(a=a.src.match(/\.([^.\/\?]+)(\?[^\/]+)?$/i))&&a[1],c("video/"+a)):""
};
t.f.S.Tb=function(a,c){c.la(a.src)
};
t.f.S.dispose=m();
t.f.Ra(t.f.S);
t.f.Od=function(){var a=t.A.volume;
t.A.volume=a/2+0.1;
return a!==t.A.volume
};
t.f.Nd=function(){var a=t.A.playbackRate;
t.A.playbackRate=a/2+0.1;
return a!==t.A.playbackRate
};
t.f.Ve=function(){var a;
(a=!!t.A.textTracks)&&0<t.A.textTracks.length&&(a="number"!==typeof t.A.textTracks[0].mode);
a&&t.jc&&(a=l);
return a
};
t.f.prototype.featuresVolumeControl=t.f.Od();
t.f.prototype.featuresPlaybackRate=t.f.Nd();
t.f.prototype.movingMediaElementInDOM=!t.Ad;
t.f.prototype.featuresFullscreenResize=f;
t.f.prototype.featuresProgressEvents=f;
t.f.prototype.featuresNativeTextTracks=t.f.Ve();
var S,oa=/^application\/(?:x-|vnd\.apple\.)mpegurl/i,pa=/^video\/mp4/i;
t.f.Xc=function(){4<=t.hc&&(S||(S=t.A.constructor.prototype.canPlayType),t.A.constructor.prototype.canPlayType=function(a){return a&&oa.test(a)?"maybe":S.call(this,a)
});
t.Ed&&(S||(S=t.A.constructor.prototype.canPlayType),t.A.constructor.prototype.canPlayType=function(a){return a&&pa.test(a)?"maybe":S.call(this,a)
})
};
t.f.bf=function(){var a=t.A.constructor.prototype.canPlayType;
t.A.constructor.prototype.canPlayType=S;
S=j;
return a
};
t.f.Xc();
t.f.yb="loadstart suspend abort error emptied stalled loadedmetadata loadeddata canplay canplaythrough playing waiting seeking seeked ended durationchange timeupdate progress play pause ratechange volumechange".split(" ");
t.f.Mb=function(a){if(a){a.player=j;
for(a.parentNode&&a.parentNode.removeChild(a);
a.hasChildNodes();
){a.removeChild(a.firstChild)
}a.removeAttribute("src");
if("function"===typeof a.load){try{a.load()
}catch(c){}}}};
t.g=t.j.extend({l:function(a,c,d){t.j.call(this,a,c,d);
var e=c.source;
d=c.parentEl;
var g=this.c=t.e("div",{id:a.id()+"_temp_flash"}),h=a.id()+"_flash_api",k=a.q,k=t.i.D({readyFunction:"videojs.Flash.onReady",eventProxyFunction:"videojs.Flash.onEvent",errorEventProxyFunction:"videojs.Flash.onError",autoplay:k.autoplay,preload:k.Qa,loop:k.loop,muted:k.muted},c.flashVars),p=t.i.D({wmode:"opaque",bgcolor:"#000000"},c.params),h=t.i.D({id:h,name:h,"class":"vjs-tech"},c.attributes);
e&&this.I(function(){this.Sa(e)
});
t.Ub(g,d);
c.startTime&&this.I(function(){this.load();
this.play();
this.currentTime(c.startTime)
});
t.jc&&this.I(function(){this.b("mousemove",function(){this.k().o({type:"mousemove",bubbles:l})
})
});
a.b("stageclick",a.reportUserActivity);
this.c=t.g.Hc(c.swf,g,k,p,h)
}});
s=t.g.prototype;
s.dispose=function(){t.j.prototype.dispose.call(this)
};
s.play=function(){this.c.vjs_play()
};
s.pause=function(){this.c.vjs_pause()
};
s.src=function(a){return a===b?this.currentSrc():this.la(a)
};
s.la=function(a){a=t.$d(a);
this.c.vjs_src(a);
if(this.d.autoplay()){var c=this;
this.setTimeout(function(){c.play()
},0)
}};
t.g.prototype.setCurrentTime=function(a){this.oe=a;
this.c.vjs_setProperty("currentTime",a);
t.j.prototype.bc.call(this)
};
t.g.prototype.currentTime=function(){return this.seeking()?this.oe||0:this.c.vjs_getProperty("currentTime")
};
t.g.prototype.currentSrc=function(){return this.Ec?this.Ec.src:this.c.vjs_getProperty("currentSrc")
};
t.g.prototype.load=function(){this.c.vjs_load()
};
t.g.prototype.poster=function(){this.c.vjs_getProperty("poster")
};
t.g.prototype.setPoster=m();
t.g.prototype.buffered=function(){return t.Lb(0,this.c.vjs_getProperty("buffered"))
};
t.g.prototype.Ta=q(l);
t.g.prototype.Ic=q(l);
function qa(){var a=T[U],c=a.charAt(0).toUpperCase()+a.slice(1);
ra["set"+c]=function(c){return this.c.vjs_setProperty(a,c)
}
}function sa(a){ra[a]=function(){return this.c.vjs_getProperty(a)
}
}var ra=t.g.prototype,T="rtmpConnection rtmpStream preload defaultPlaybackRate playbackRate autoplay loop mediaGroup controller controls volume muted defaultMuted".split(" "),ta="error networkState readyState seeking initialTime duration startOffsetTime paused played seekable ended videoTracks audioTracks videoWidth videoHeight".split(" "),U;
for(U=0;
U<T.length;
U++){sa(T[U]),qa()
}for(U=0;
U<ta.length;
U++){sa(ta[U])
}t.g.isSupported=function(){return 10<=t.g.version()[0]
};
t.j.gc(t.g);
t.g.S={};
t.g.S.eb=function(a){return !a.type?"":a.type.replace(/;.*/,"").toLowerCase() in t.g.Zd?"maybe":""
};
t.g.S.Tb=function(a,c){c.la(a.src)
};
t.g.S.dispose=m();
t.g.Ra(t.g.S);
t.g.Zd={"video/flv":"FLV","video/x-flv":"FLV","video/mp4":"MP4","video/m4v":"MP4"};
t.g.onReady=function(a){var c;
if(c=(a=t.m(a))&&a.parentNode&&a.parentNode.player){a.player=c,t.g.checkReady(c.h)
}};
t.g.checkReady=function(a){a.m()&&(a.m().vjs_getProperty?a.Wa():this.setTimeout(function(){t.g.checkReady(a)
},50))
};
t.g.onEvent=function(a,c){t.m(a).player.o(c)
};
t.g.onError=function(a,c){var d=t.m(a).player,e="FLASH: "+c;
"srcnotfound"==c?d.error({code:4,message:e}):d.error(e)
};
t.g.version=function(){var a="0,0,0";
try{a=(new window.ActiveXObject("ShockwaveFlash.ShockwaveFlash")).GetVariable("$version").replace(/\D+/g,",").match(/^,?(.+),?$/)[1]
}catch(c){try{navigator.mimeTypes["application/x-shockwave-flash"].enabledPlugin&&(a=(navigator.plugins["Shockwave Flash 2.0"]||navigator.plugins["Shockwave Flash"]).description.replace(/\D+/g,",").match(/^,?(.+),?$/)[1])
}catch(d){}}return a.split(",")
};
t.g.Hc=function(a,c,d,e,g){a=t.g.ce(a,d,e,g);
a=t.e("div",{innerHTML:a}).childNodes[0];
d=c.parentNode;
c.parentNode.replaceChild(a,c);
var h=d.childNodes[0];
setTimeout(function(){h.style.display="block"
},1000);
return a
};
t.g.ce=function(a,c,d,e){var g="",h="",k="";
c&&t.i.da(c,function(a,c){g+=a+"="+c+"&amp;"
});
d=t.i.D({movie:a,flashvars:g,allowScriptAccess:"always",allowNetworking:"all"},d);
t.i.da(d,function(a,c){h+='<param name="'+a+'" value="'+c+'" />'
});
e=t.i.D({data:a,width:"100%",height:"100%"},e);
t.i.da(e,function(a,c){k+=a+'="'+c+'" '
});
return'<object type="application/x-shockwave-flash" '+k+">"+h+"</object>"
};
t.g.Ue={"rtmp/mp4":"MP4","rtmp/flv":"FLV"};
t.g.Hf=function(a,c){return a+"&"+c
};
t.g.Te=function(a){var c={Bc:"",md:""};
if(!a){return c
}var d=a.indexOf("&"),e;
-1!==d?e=d+1:(d=e=a.lastIndexOf("/")+1,0===d&&(d=e=a.length));
c.Bc=a.substring(0,d);
c.md=a.substring(e,a.length);
return c
};
t.g.me=function(a){return a in t.g.Ue
};
t.g.Gd=/^rtmp[set]?:\/\//i;
t.g.le=function(a){return t.g.Gd.test(a)
};
t.g.ac={};
t.g.ac.eb=function(a){return t.g.me(a.type)||t.g.le(a.src)?"maybe":""
};
t.g.ac.Tb=function(a,c){var d=t.g.Te(a.src);
c.setRtmpConnection(d.Bc);
c.setRtmpStream(d.md)
};
t.g.Ra(t.g.ac);
t.Fd=t.a.extend({l:function(a,c,d){t.a.call(this,a,c,d);
if(!a.q.sources||0===a.q.sources.length){c=0;
for(d=a.q.techOrder;
c<d.length;
c++){var e=t.ua(d[c]),g=window.videojs[e];
if(g&&g.isSupported()){ka(a,e);
break
}}}else{a.src(a.q.sources)
}}});
t.rc={disabled:"disabled",hidden:"hidden",showing:"showing"};
t.Hd={subtitles:"subtitles",captions:"captions",descriptions:"descriptions",chapters:"chapters",metadata:"metadata"};
t.t=function(a){var c,d,e,g,h,k,p,r,u,A,R;
a=a||{};
if(!a.player){throw Error("A player was not provided.")
}c=this;
if(t.oa){for(R in c=document.createElement("custom"),t.t.prototype){c[R]=t.t.prototype[R]
}}c.d=a.player;
e=t.rc[a.mode]||"disabled";
g=t.Hd[a.kind]||"subtitles";
h=a.label||"";
k=a.language||a.srclang||"";
d=a.id||"vjs_text_track_"+t.s++;
if("metadata"===g||"chapters"===g){e="hidden"
}c.X=[];
c.Ga=[];
p=new t.W(c.X);
r=new t.W(c.Ga);
A=l;
u=t.bind(c,function(){this.activeCues;
A&&(this.trigger("cuechange"),A=l)
});
"disabled"!==e&&c.d.b("timeupdate",u);
Object.defineProperty(c,"kind",{get:function(){return g
},set:Function.prototype});
Object.defineProperty(c,"label",{get:function(){return h
},set:Function.prototype});
Object.defineProperty(c,"language",{get:function(){return k
},set:Function.prototype});
Object.defineProperty(c,"id",{get:function(){return d
},set:Function.prototype});
Object.defineProperty(c,"mode",{get:function(){return e
},set:function(a){t.rc[a]&&(e=a,"showing"===e&&this.d.b("timeupdate",u),this.o("modechange"))
}});
Object.defineProperty(c,"cues",{get:function(){return !this.Xb?j:p
},set:Function.prototype});
Object.defineProperty(c,"activeCues",{get:function(){var a,c,d,e,g;
if(!this.Xb){return j
}if(0===this.cues.length){return r
}e=this.d.currentTime();
a=0;
c=this.cues.length;
for(d=[];
a<c;
a++){g=this.cues[a],g.startTime<=e&&g.endTime>=e?d.push(g):g.startTime===g.endTime&&(g.startTime<=e&&g.startTime+0.5>=e)&&d.push(g)
}A=l;
if(d.length!==this.Ga.length){A=f
}else{for(a=0;
a<d.length;
a++){-1===ua.call(this.Ga,d[a])&&(A=f)
}}this.Ga=d;
r.qb(this.Ga);
return r
},set:Function.prototype});
a.src?va(a.src,c):c.Xb=f;
if(t.oa){return c
}};
t.t.prototype=t.i.create(t.z.prototype);
t.t.prototype.constructor=t.t;
t.t.prototype.bb={cuechange:"cuechange"};
t.t.prototype.vc=function(a){var c=this.d.textTracks(),d=0;
if(c){for(;
d<c.length;
d++){c[d]!==this&&c[d].bd(a)
}}this.X.push(a);
this.cues.qb(this.X)
};
t.t.prototype.bd=function(a){for(var c=0,d=this.X.length,e,g=l;
c<d;
c++){e=this.X[c],e===a&&(this.X.splice(c,1),g=f)
}g&&this.Dc.qb(this.X)
};
var va,V,ua;
va=function(a,c){t.ff(a,t.bind(this,function(a,e,g){if(a){return t.log.error(a)
}c.Xb=f;
V(g,c)
}))
};
V=function(a,c){if("function"!==typeof window.WebVTT){window.setTimeout(function(){V(a,c)
},25)
}else{var d=new window.WebVTT.Parser(window,window.vttjs,window.WebVTT.StringDecoder());
d.oncue=function(a){c.vc(a)
};
d.onparsingerror=function(a){t.log.error(a)
};
d.parse(a);
d.flush()
}};
ua=function(a,c){var d;
if(this==j){throw new TypeError('"this" is null or not defined')
}var e=Object(this),g=e.length>>>0;
if(0===g){return -1
}d=+c||0;
Infinity===Math.abs(d)&&(d=0);
if(d>=g){return -1
}for(d=Math.max(0<=d?d:g-Math.abs(d),0);
d<g;
){if(d in e&&e[d]===a){return d
}d++
}return -1
};
t.F=function(a){var c=this,d,e=0;
if(t.oa){for(d in c=document.createElement("custom"),t.F.prototype){c[d]=t.F.prototype[d]
}}a=a||[];
c.Va=[];
for(Object.defineProperty(c,"length",{get:function(){return this.Va.length
}});
e<a.length;
e++){P(c,a[e])
}if(t.oa){return c
}};
t.F.prototype=t.i.create(t.z.prototype);
t.F.prototype.constructor=t.F;
t.F.prototype.bb={change:"change",addtrack:"addtrack",removetrack:"removetrack"};
for(var wa in t.F.prototype.bb){t.F.prototype["on"+wa]=j
}function P(a,c){var d=a.Va.length;
""+d in a||Object.defineProperty(a,d,{get:function(){return this.Va[d]
}});
c.addEventListener("modechange",t.bind(a,function(){this.o("change")
}));
a.Va.push(c);
a.o({type:"addtrack",T:c})
}function Q(a,c){for(var d=0,e=a.length,g;
d<e;
d++){if(g=a[d],g===c){a.Va.splice(d,1);
break
}}a.o({type:"removetrack",T:c})
}t.F.prototype.de=function(a){for(var c=0,d=this.length,e=j,g;
c<d;
c++){if(g=this[c],g.id===a){e=g;
break
}}return e
};
t.W=function(a){var c=this,d;
if(t.oa){for(d in c=document.createElement("custom"),t.W.prototype){c[d]=t.W.prototype[d]
}}t.W.prototype.qb.call(c,a);
Object.defineProperty(c,"length",{get:n("pe")});
if(t.oa){return c
}};
t.W.prototype.qb=function(a){var c=this.length||0,d=0,e=a.length;
this.X=a;
this.pe=a.length;
a=function(a){""+a in this||Object.defineProperty(this,""+a,{get:function(){return this.X[a]
}})
};
if(c<e){for(d=c;
d<e;
d++){a.call(this,d)
}}};
t.W.prototype.be=function(a){for(var c=0,d=this.length,e=j,g;
c<d;
c++){if(g=this[c],g.id===a){e=g;
break
}}return e
};
t.ra=t.a.extend({l:function(a,c,d){t.a.call(this,a,c,d);
a.b("loadstart",t.bind(this,this.Ze));
a.I(t.bind(this,function(){if(a.h&&a.h.featuresNativeTextTracks){this.Y()
}else{var c,d,h;
a.b("fullscreenchange",t.bind(this,this.C));
d=a.q.tracks||[];
for(c=0;
c<d.length;
c++){h=d[c],this.d.ha(h)
}}}))
}});
t.ra.prototype.Ze=function(){this.d.h&&this.d.h.featuresNativeTextTracks?this.Y():this.show()
};
t.ra.prototype.e=function(){return t.a.prototype.e.call(this,"div",{className:"vjs-text-track-display"})
};
t.ra.prototype.Pd=function(){"function"===typeof window.WebVTT&&window.WebVTT.processCues(window,[],this.c)
};
function W(a,c){return"rgba("+parseInt(a[1]+a[1],16)+","+parseInt(a[2]+a[2],16)+","+parseInt(a[3]+a[3],16)+","+c+")"
}var xa={xf:"monospace",Df:"sans-serif",Ff:"serif",yf:'"Andale Mono", "Lucida Console", monospace',zf:'"Courier New", monospace',Bf:"sans-serif",Cf:"serif",of:'"Comic Sans MS", Impact, fantasy',Ef:'"Monotype Corsiva", cursive',Gf:'"Andale Mono", "Lucida Console", monospace, sans-serif'};
t.ra.prototype.C=function(){var a=this.d.textTracks(),c=0,d;
this.Pd();
if(a){for(;
c<a.length;
c++){d=a[c],"showing"===d.mode&&this.cf(d)
}}};
t.ra.prototype.cf=function(a){if("function"===typeof window.WebVTT&&a.activeCues){for(var c=0,d=this.d.textTrackSettings.Lc(),e,g=[];
c<a.activeCues.length;
c++){g.push(a.activeCues[c])
}window.WebVTT.processCues(window,a.activeCues,this.c);
for(c=g.length;
c--;
){a=g[c].pf;
d.color&&(a.firstChild.style.color=d.color);
if(d.nd){try{a.firstChild.style.color=W(d.color||"#fff",d.nd)
}catch(h){}}d.backgroundColor&&(a.firstChild.style.backgroundColor=d.backgroundColor);
if(d.yc){try{a.firstChild.style.backgroundColor=W(d.backgroundColor||"#000",d.yc)
}catch(k){}}if(d.fc){if(d.ud){try{a.style.backgroundColor=W(d.fc,d.ud)
}catch(p){}}else{a.style.backgroundColor=d.fc
}}d.La&&("dropshadow"===d.La?a.firstChild.style.textShadow="2px 2px 3px #222, 2px 2px 4px #222, 2px 2px 5px #222":"raised"===d.La?a.firstChild.style.textShadow="1px 1px #222, 2px 2px #222, 3px 3px #222":"depressed"===d.La?a.firstChild.style.textShadow="1px 1px #ccc, 0 1px #ccc, -1px -1px #222, 0 -1px #222":"uniform"===d.La&&(a.firstChild.style.textShadow="0 0 4px #222, 0 0 4px #222, 0 0 4px #222, 0 0 4px #222"));
d.Qb&&1!==d.Qb&&(e=window.Af(a.style.fontSize),a.style.fontSize=e*d.Qb+"px",a.style.height="auto",a.style.top="auto",a.style.bottom="2px");
d.fontFamily&&"default"!==d.fontFamily&&("small-caps"===d.fontFamily?a.firstChild.style.fontVariant="small-caps":a.firstChild.style.fontFamily=xa[d.fontFamily])
}}};
t.aa=t.M.extend({l:function(a,c){var d=this.T=c.track,e=a.textTracks(),g,h;
e&&(g=t.bind(this,function(){var a="showing"===this.T.mode,c,d,g;
if(this instanceof t.Ab){a=f;
d=0;
for(g=e.length;
d<g;
d++){if(c=e[d],c.kind===this.T.kind&&"showing"===c.mode){a=l;
break
}}}this.selected(a)
}),e.addEventListener("change",g),a.b("dispose",function(){e.removeEventListener("change",g)
}));
c.label=d.label||d.language||"Unknown";
c.selected=d["default"]||"showing"===d.mode;
t.M.call(this,a,c);
e&&e.onchange===b&&this.b(["tap","click"],function(){if("object"!==typeof window.yd){try{h=new window.yd("change")
}catch(a){}}h||(h=document.createEvent("Event"),h.initEvent("change",f,f));
e.dispatchEvent(h)
})
}});
t.aa.prototype.u=function(){var a=this.T.kind,c=this.d.textTracks(),d,e=0;
t.M.prototype.u.call(this);
if(c){for(;
e<c.length;
e++){d=c[e],d.kind===a&&(d.mode=d===this.T?"showing":"disabled")
}}};
t.Ab=t.aa.extend({l:function(a,c){c.track={kind:c.kind,player:a,label:c.kind+" off","default":l,mode:"disabled"};
t.aa.call(this,a,c);
this.selected(f)
}});
t.tb=t.aa.extend({l:function(a,c){c.track={kind:c.kind,player:a,label:c.kind+" settings","default":l,mode:"disabled"};
t.aa.call(this,a,c);
this.p("vjs-texttrack-settings")
}});
t.tb.prototype.u=function(){this.k().ea("textTrackSettings").show()
};
t.Q=t.O.extend({l:function(a,c){var d,e;
t.O.call(this,a,c);
d=this.d.textTracks();
1>=this.H.length&&this.Y();
d&&(e=t.bind(this,this.update),d.addEventListener("removetrack",e),d.addEventListener("addtrack",e),this.d.b("dispose",function(){d.removeEventListener("removetrack",e);
d.removeEventListener("addtrack",e)
}))
}});
t.Q.prototype.Ia=function(){var a=[],c,d;
this instanceof t.na&&(!this.k().h||!this.k().h.featuresNativeTextTracks)&&a.push(new t.tb(this.d,{kind:this.fa}));
a.push(new t.Ab(this.d,{kind:this.fa}));
d=this.d.textTracks();
if(!d){return a
}for(var e=0;
e<d.length;
e++){c=d[e],c.kind===this.fa&&a.push(new t.aa(this.d,{track:c}))
}return a
};
t.na=t.Q.extend({l:function(a,c,d){t.Q.call(this,a,c,d);
this.c.setAttribute("aria-label","Captions Menu")
}});
t.na.prototype.fa="captions";
t.na.prototype.sa="Captions";
t.na.prototype.className="vjs-captions-button";
t.na.prototype.update=function(){var a=2;
t.Q.prototype.update.call(this);
this.k().h&&this.k().h.featuresNativeTextTracks&&(a=1);
this.H&&this.H.length>a?this.show():this.Y()
};
t.ab=t.Q.extend({l:function(a,c,d){t.Q.call(this,a,c,d);
this.c.setAttribute("aria-label","Subtitles Menu")
}});
t.ab.prototype.fa="subtitles";
t.ab.prototype.sa="Subtitles";
t.ab.prototype.className="vjs-subtitles-button";
t.Xa=t.Q.extend({l:function(a,c,d){t.Q.call(this,a,c,d);
this.c.setAttribute("aria-label","Chapters Menu")
}});
s=t.Xa.prototype;
s.fa="chapters";
s.sa="Chapters";
s.className="vjs-chapters-button";
s.Ia=function(){var a=[],c,d;
d=this.d.textTracks();
if(!d){return a
}for(var e=0;
e<d.length;
e++){c=d[e],c.kind===this.fa&&a.push(new t.aa(this.d,{track:c}))
}return a
};
s.Ja=function(){for(var a=this.d.textTracks()||[],c=0,d=a.length,e,g,h=this.H=[];
c<d;
c++){if(e=a[c],e.kind==this.fa){if(e.Dc){g=e;
break
}else{e.mode="hidden",window.setTimeout(t.bind(this,function(){this.Ja()
}),100)
}}}a=this.xa;
a===b&&(a=new t.pa(this.d),a.va().appendChild(t.e("li",{className:"vjs-menu-title",innerHTML:t.ua(this.fa),We:-1})));
if(g){e=g.cues;
for(var k,c=0,d=e.length;
c<d;
c++){k=e[c],k=new t.Ya(this.d,{track:g,cue:k}),h.push(k),a.ba(k)
}this.ba(a)
}0<this.H.length&&this.show();
return a
};
t.Ya=t.M.extend({l:function(a,c){var d=this.T=c.track,e=this.cue=c.cue,g=a.currentTime();
c.label=e.text;
c.selected=e.startTime<=g&&g<e.endTime;
t.M.call(this,a,c);
d.addEventListener("cuechange",t.bind(this,this.update))
}});
t.Ya.prototype.u=function(){t.M.prototype.u.call(this);
this.d.currentTime(this.cue.startTime);
this.update(this.cue.startTime)
};
t.Ya.prototype.update=function(){var a=this.cue,c=this.d.currentTime();
this.selected(a.startTime<=c&&c<a.endTime)
};
function X(a){var c;
a.Ke?c=a.Ke[0]:a.options&&(c=a.options[a.options.selectedIndex]);
return c.value
}function Y(a,c){var d,e;
if(c){for(d=0;
d<a.options.length&&!(e=a.options[d],e.value===c);
d++){}a.selectedIndex=d
}}t.sc=t.a.extend({l:function(a,c){t.a.call(this,a,c);
this.Y();
t.b(this.m().querySelector(".vjs-done-button"),"click",t.bind(this,function(){this.Je();
this.Y()
}));
t.b(this.m().querySelector(".vjs-default-button"),"click",t.bind(this,function(){this.m().querySelector(".vjs-fg-color > select").selectedIndex=0;
this.m().querySelector(".vjs-bg-color > select").selectedIndex=0;
this.m().querySelector(".window-color > select").selectedIndex=0;
this.m().querySelector(".vjs-text-opacity > select").selectedIndex=0;
this.m().querySelector(".vjs-bg-opacity > select").selectedIndex=0;
this.m().querySelector(".vjs-window-opacity > select").selectedIndex=0;
this.m().querySelector(".vjs-edge-style select").selectedIndex=0;
this.m().querySelector(".vjs-font-family select").selectedIndex=0;
this.m().querySelector(".vjs-font-percent select").selectedIndex=2;
this.C()
}));
t.b(this.m().querySelector(".vjs-fg-color > select"),"change",t.bind(this,this.C));
t.b(this.m().querySelector(".vjs-bg-color > select"),"change",t.bind(this,this.C));
t.b(this.m().querySelector(".window-color > select"),"change",t.bind(this,this.C));
t.b(this.m().querySelector(".vjs-text-opacity > select"),"change",t.bind(this,this.C));
t.b(this.m().querySelector(".vjs-bg-opacity > select"),"change",t.bind(this,this.C));
t.b(this.m().querySelector(".vjs-window-opacity > select"),"change",t.bind(this,this.C));
t.b(this.m().querySelector(".vjs-font-percent select"),"change",t.bind(this,this.C));
t.b(this.m().querySelector(".vjs-edge-style select"),"change",t.bind(this,this.C));
t.b(this.m().querySelector(".vjs-font-family select"),"change",t.bind(this,this.C));
a.options().persistTextTrackSettings&&this.Ie()
}});
s=t.sc.prototype;
s.e=function(){return t.a.prototype.e.call(this,"div",{className:"vjs-caption-settings vjs-modal-overlay",innerHTML:'<div class="vjs-tracksettings"><div class="vjs-tracksettings-colors"><div class="vjs-fg-color vjs-tracksetting"><label class="vjs-label">Foreground</label><select><option value="">---</option><option value="#FFF">White</option><option value="#000">Black</option><option value="#F00">Red</option><option value="#0F0">Green</option><option value="#00F">Blue</option><option value="#FF0">Yellow</option><option value="#F0F">Magenta</option><option value="#0FF">Cyan</option></select><span class="vjs-text-opacity vjs-opacity"><select><option value="">---</option><option value="1">Opaque</option><option value="0.5">Semi-Opaque</option></select></span></div><div class="vjs-bg-color vjs-tracksetting"><label class="vjs-label">Background</label><select><option value="">---</option><option value="#FFF">White</option><option value="#000">Black</option><option value="#F00">Red</option><option value="#0F0">Green</option><option value="#00F">Blue</option><option value="#FF0">Yellow</option><option value="#F0F">Magenta</option><option value="#0FF">Cyan</option></select><span class="vjs-bg-opacity vjs-opacity"><select><option value="">---</option><option value="1">Opaque</option><option value="0.5">Semi-Transparent</option><option value="0">Transparent</option></select></span></div><div class="window-color vjs-tracksetting"><label class="vjs-label">Window</label><select><option value="">---</option><option value="#FFF">White</option><option value="#000">Black</option><option value="#F00">Red</option><option value="#0F0">Green</option><option value="#00F">Blue</option><option value="#FF0">Yellow</option><option value="#F0F">Magenta</option><option value="#0FF">Cyan</option></select><span class="vjs-window-opacity vjs-opacity"><select><option value="">---</option><option value="1">Opaque</option><option value="0.5">Semi-Transparent</option><option value="0">Transparent</option></select></span></div></div><div class="vjs-tracksettings-font"><div class="vjs-font-percent vjs-tracksetting"><label class="vjs-label">Font Size</label><select><option value="0.50">50%</option><option value="0.75">75%</option><option value="1.00" selected>100%</option><option value="1.25">125%</option><option value="1.50">150%</option><option value="1.75">175%</option><option value="2.00">200%</option><option value="3.00">300%</option><option value="4.00">400%</option></select></div><div class="vjs-edge-style vjs-tracksetting"><label class="vjs-label">Text Edge Style</label><select><option value="none">None</option><option value="raised">Raised</option><option value="depressed">Depressed</option><option value="uniform">Uniform</option><option value="dropshadow">Dropshadow</option></select></div><div class="vjs-font-family vjs-tracksetting"><label class="vjs-label">Font Family</label><select><option value="">Default</option><option value="monospaceSerif">Monospace Serif</option><option value="proportionalSerif">Proportional Serif</option><option value="monospaceSansSerif">Monospace Sans-Serif</option><option value="proportionalSansSerif">Proportional Sans-Serif</option><option value="casual">Casual</option><option value="script">Script</option><option value="small-caps">Small Caps</option></select></div></div></div><div class="vjs-tracksettings-controls"><button class="vjs-default-button">Defaults</button><button class="vjs-done-button">Done</button></div>'})
};
s.Lc=function(){var a,c,d,e,g,h,k,p,r,u;
a=this.m();
g=X(a.querySelector(".vjs-edge-style select"));
h=X(a.querySelector(".vjs-font-family select"));
k=X(a.querySelector(".vjs-fg-color > select"));
d=X(a.querySelector(".vjs-text-opacity > select"));
p=X(a.querySelector(".vjs-bg-color > select"));
c=X(a.querySelector(".vjs-bg-opacity > select"));
r=X(a.querySelector(".window-color > select"));
e=X(a.querySelector(".vjs-window-opacity > select"));
a=window.parseFloat(X(a.querySelector(".vjs-font-percent > select")));
c={backgroundOpacity:c,textOpacity:d,windowOpacity:e,edgeStyle:g,fontFamily:h,color:k,backgroundColor:p,windowColor:r,fontPercent:a};
for(u in c){(""===c[u]||"none"===c[u]||"fontPercent"===u&&1===c[u])&&delete c[u]
}return c
};
s.Re=function(a){var c=this.m();
Y(c.querySelector(".vjs-edge-style select"),a.La);
Y(c.querySelector(".vjs-font-family select"),a.fontFamily);
Y(c.querySelector(".vjs-fg-color > select"),a.color);
Y(c.querySelector(".vjs-text-opacity > select"),a.nd);
Y(c.querySelector(".vjs-bg-color > select"),a.backgroundColor);
Y(c.querySelector(".vjs-bg-opacity > select"),a.yc);
Y(c.querySelector(".window-color > select"),a.fc);
Y(c.querySelector(".vjs-window-opacity > select"),a.ud);
(a=a.Qb)&&(a=a.toFixed(2));
Y(c.querySelector(".vjs-font-percent > select"),a)
};
s.Ie=function(){var a;
try{a=JSON.parse(window.localStorage.getItem("vjs-text-track-settings"))
}catch(c){}a&&this.Re(a)
};
s.Je=function(){var a;
if(this.d.options().persistTextTrackSettings){a=this.Lc();
try{t.ib(a)?window.localStorage.removeItem("vjs-text-track-settings"):window.localStorage.setItem("vjs-text-track-settings",JSON.stringify(a))
}catch(c){}}};
s.C=function(){var a=this.d.ea("textTrackDisplay");
a&&a.C()
};
if("undefined"!==typeof window.JSON&&"function"===typeof window.JSON.parse){t.JSON=window.JSON
}else{t.JSON={};
var Z=/[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
t.JSON.parse=function(a,c){function d(a,e){var k,p,r=a[e];
if(r&&"object"===typeof r){for(k in r){Object.prototype.hasOwnProperty.call(r,k)&&(p=d(r,k),p!==b?r[k]=p:delete r[k])
}}return c.call(a,e,r)
}var e;
a=String(a);
Z.lastIndex=0;
Z.test(a)&&(a=a.replace(Z,function(a){return"\\u"+("0000"+a.charCodeAt(0).toString(16)).slice(-4)
}));
if(/^[\],:{}\s]*$/.test(a.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g,"@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,"]").replace(/(?:^|:|,)(?:\s*\[)+/g,""))){return e=eval("("+a+")"),"function"===typeof c?d({"":e},""):e
}throw new SyntaxError("JSON.parse(): invalid or malformed JSON data")
}
}t.xc=function(){var a,c,d,e;
a=document.getElementsByTagName("video");
c=document.getElementsByTagName("audio");
var g=[];
if(a&&0<a.length){d=0;
for(e=a.length;
d<e;
d++){g.push(a[d])
}}if(c&&0<c.length){d=0;
for(e=c.length;
d<e;
d++){g.push(c[d])
}}if(g&&0<g.length){d=0;
for(e=g.length;
d<e;
d++){if((c=g[d])&&c.getAttribute){c.player===b&&(a=c.getAttribute("data-setup"),a!==j&&videojs(c))
}else{t.Ib();
break
}}}else{t.td||t.Ib()
}};
t.Ib=function(){setTimeout(t.xc,1)
};
"complete"===document.readyState?t.td=f:t.N(window,"load",function(){t.td=f
});
t.Ib();
t.Fe=function(a,c){t.Player.prototype[a]=c
};
var ya=this;
function $(a,c){var d=a.split("."),e=ya;
!(d[0] in e)&&e.execScript&&e.execScript("var "+d[0]);
for(var g;
d.length&&(g=d.shift());
){!d.length&&c!==b?e[g]=c:e=e[g]?e[g]:e[g]={}
}}$("videojs",t);
$("_V_",t);
$("videojs.options",t.options);
$("videojs.players",t.Aa);
$("videojs.TOUCH_ENABLED",t.Eb);
$("videojs.cache",t.ta);
$("videojs.Component",t.a);
t.a.prototype.player=t.a.prototype.k;
t.a.prototype.options=t.a.prototype.options;
t.a.prototype.init=t.a.prototype.l;
t.a.prototype.dispose=t.a.prototype.dispose;
t.a.prototype.createEl=t.a.prototype.e;
t.a.prototype.contentEl=t.a.prototype.va;
t.a.prototype.el=t.a.prototype.m;
t.a.prototype.addChild=t.a.prototype.ba;
t.a.prototype.getChild=t.a.prototype.ea;
t.a.prototype.getChildById=t.a.prototype.ae;
t.a.prototype.children=t.a.prototype.children;
t.a.prototype.initChildren=t.a.prototype.Oc;
t.a.prototype.removeChild=t.a.prototype.removeChild;
t.a.prototype.on=t.a.prototype.b;
t.a.prototype.off=t.a.prototype.n;
t.a.prototype.one=t.a.prototype.N;
t.a.prototype.trigger=t.a.prototype.o;
t.a.prototype.triggerReady=t.a.prototype.Wa;
t.a.prototype.show=t.a.prototype.show;
t.a.prototype.hide=t.a.prototype.Y;
t.a.prototype.width=t.a.prototype.width;
t.a.prototype.height=t.a.prototype.height;
t.a.prototype.dimensions=t.a.prototype.Td;
t.a.prototype.ready=t.a.prototype.I;
t.a.prototype.addClass=t.a.prototype.p;
t.a.prototype.removeClass=t.a.prototype.r;
t.a.prototype.hasClass=t.a.prototype.Oa;
t.a.prototype.buildCSSClass=t.a.prototype.V;
t.a.prototype.localize=t.a.prototype.v;
t.a.prototype.setInterval=t.a.prototype.setInterval;
t.a.prototype.setTimeout=t.a.prototype.setTimeout;
$("videojs.EventEmitter",t.z);
t.z.prototype.on=t.z.prototype.b;
t.z.prototype.addEventListener=t.z.prototype.addEventListener;
t.z.prototype.off=t.z.prototype.n;
t.z.prototype.removeEventListener=t.z.prototype.removeEventListener;
t.z.prototype.one=t.z.prototype.N;
t.z.prototype.trigger=t.z.prototype.o;
t.z.prototype.dispatchEvent=t.z.prototype.dispatchEvent;
t.Player.prototype.ended=t.Player.prototype.ended;
t.Player.prototype.enterFullWindow=t.Player.prototype.Jc;
t.Player.prototype.exitFullWindow=t.Player.prototype.Nb;
t.Player.prototype.preload=t.Player.prototype.Qa;
t.Player.prototype.remainingTime=t.Player.prototype.remainingTime;
t.Player.prototype.supportsFullScreen=t.Player.prototype.Ta;
t.Player.prototype.currentType=t.Player.prototype.Qd;
t.Player.prototype.requestFullScreen=t.Player.prototype.requestFullScreen;
t.Player.prototype.requestFullscreen=t.Player.prototype.requestFullscreen;
t.Player.prototype.cancelFullScreen=t.Player.prototype.cancelFullScreen;
t.Player.prototype.exitFullscreen=t.Player.prototype.exitFullscreen;
t.Player.prototype.isFullScreen=t.Player.prototype.isFullScreen;
t.Player.prototype.isFullscreen=t.Player.prototype.isFullscreen;
t.Player.prototype.textTracks=t.Player.prototype.textTracks;
t.Player.prototype.remoteTextTracks=t.Player.prototype.Z;
t.Player.prototype.addTextTrack=t.Player.prototype.addTextTrack;
t.Player.prototype.addRemoteTextTrack=t.Player.prototype.ha;
t.Player.prototype.removeRemoteTextTrack=t.Player.prototype.Ba;
$("videojs.MediaLoader",t.Fd);
$("videojs.TextTrackDisplay",t.ra);
$("videojs.ControlBar",t.ub);
$("videojs.Button",t.w);
$("videojs.PlayToggle",t.nc);
$("videojs.FullscreenToggle",t.Za);
$("videojs.BigPlayButton",t.sb);
$("videojs.LoadingSpinner",t.lc);
$("videojs.CurrentTimeDisplay",t.vb);
$("videojs.DurationDisplay",t.wb);
$("videojs.TimeDivider",t.tc);
$("videojs.RemainingTimeDisplay",t.Db);
$("videojs.LiveDisplay",t.kc);
$("videojs.ErrorDisplay",t.xb);
$("videojs.Slider",t.U);
$("videojs.ProgressControl",t.Cb);
$("videojs.SeekBar",t.qc);
$("videojs.LoadProgressBar",t.zb);
$("videojs.PlayProgressBar",t.mc);
$("videojs.SeekHandle",t.$a);
$("videojs.VolumeControl",t.Gb);
$("videojs.VolumeBar",t.Fb);
$("videojs.VolumeLevel",t.uc);
$("videojs.VolumeMenuButton",t.Fa);
$("videojs.VolumeHandle",t.Hb);
$("videojs.MuteToggle",t.qa);
$("videojs.PosterImage",t.pc);
$("videojs.Menu",t.pa);
$("videojs.MenuItem",t.M);
$("videojs.MenuButton",t.O);
$("videojs.PlaybackRateMenuButton",t.oc);
$("videojs.ChaptersTrackMenuItem",t.Ya);
$("videojs.TextTrackButton",t.Q);
$("videojs.TextTrackMenuItem",t.aa);
$("videojs.OffTextTrackMenuItem",t.Ab);
$("videojs.CaptionSettingsMenuItem",t.tb);
t.O.prototype.createItems=t.O.prototype.Ia;
t.Q.prototype.createItems=t.Q.prototype.Ia;
t.Xa.prototype.createItems=t.Xa.prototype.Ia;
$("videojs.SubtitlesButton",t.ab);
$("videojs.CaptionsButton",t.na);
$("videojs.ChaptersButton",t.Xa);
$("videojs.MediaTechController",t.j);
t.j.withSourceHandlers=t.j.gc;
t.j.prototype.featuresVolumeControl=t.j.prototype.uf;
t.j.prototype.featuresFullscreenResize=t.j.prototype.qf;
t.j.prototype.featuresPlaybackRate=t.j.prototype.rf;
t.j.prototype.featuresProgressEvents=t.j.prototype.sf;
t.j.prototype.featuresTimeupdateEvents=t.j.prototype.tf;
t.j.prototype.setPoster=t.j.prototype.fd;
t.j.prototype.textTracks=t.j.prototype.textTracks;
t.j.prototype.remoteTextTracks=t.j.prototype.Z;
t.j.prototype.addTextTrack=t.j.prototype.addTextTrack;
t.j.prototype.addRemoteTextTrack=t.j.prototype.ha;
t.j.prototype.removeRemoteTextTrack=t.j.prototype.Ba;
$("videojs.Html5",t.f);
t.f.Events=t.f.yb;
t.f.isSupported=t.f.isSupported;
t.f.canPlaySource=t.f.zc;
t.f.patchCanPlayType=t.f.Xc;
t.f.unpatchCanPlayType=t.f.bf;
t.f.prototype.setCurrentTime=t.f.prototype.bc;
t.f.prototype.setVolume=t.f.prototype.Se;
t.f.prototype.setMuted=t.f.prototype.Oe;
t.f.prototype.setPreload=t.f.prototype.Qe;
t.f.prototype.setAutoplay=t.f.prototype.Le;
t.f.prototype.setLoop=t.f.prototype.Ne;
t.f.prototype.enterFullScreen=t.f.prototype.Ic;
t.f.prototype.exitFullScreen=t.f.prototype.Xd;
t.f.prototype.playbackRate=t.f.prototype.playbackRate;
t.f.prototype.setPlaybackRate=t.f.prototype.Pe;
t.f.registerSourceHandler=t.f.Ra;
t.f.selectSourceHandler=t.f.pb;
t.f.prototype.setSource=t.f.prototype.Sa;
t.f.prototype.disposeSourceHandler=t.f.prototype.Ka;
t.f.prototype.textTracks=t.f.prototype.textTracks;
t.f.prototype.remoteTextTracks=t.f.prototype.Z;
t.f.prototype.addTextTrack=t.f.prototype.addTextTrack;
t.f.prototype.addRemoteTextTrack=t.f.prototype.ha;
t.f.prototype.removeRemoteTextTrack=t.f.prototype.Ba;
$("videojs.Flash",t.g);
t.g.isSupported=t.g.isSupported;
t.g.canPlaySource=t.g.zc;
t.g.onReady=t.g.onReady;
t.g.embed=t.g.Hc;
t.g.version=t.g.version;
t.g.prototype.setSource=t.g.prototype.Sa;
t.g.registerSourceHandler=t.g.Ra;
t.g.selectSourceHandler=t.g.pb;
t.g.prototype.setSource=t.g.prototype.Sa;
t.g.prototype.disposeSourceHandler=t.g.prototype.Ka;
$("videojs.TextTrack",t.t);
$("videojs.TextTrackList",t.F);
$("videojs.TextTrackCueList",t.W);
$("videojs.TextTrackSettings",t.sc);
t.t.prototype.id=t.t.prototype.id;
t.t.prototype.label=t.t.prototype.label;
t.t.prototype.kind=t.t.prototype.Wb;
t.t.prototype.mode=t.t.prototype.mode;
t.t.prototype.cues=t.t.prototype.Dc;
t.t.prototype.activeCues=t.t.prototype.nf;
t.t.prototype.addCue=t.t.prototype.vc;
t.t.prototype.removeCue=t.t.prototype.bd;
t.F.prototype.getTrackById=t.F.prototype.de;
t.W.prototype.getCueById=t.F.prototype.be;
$("videojs.CaptionsTrack",t.gf);
$("videojs.SubtitlesTrack",t.mf);
$("videojs.ChaptersTrack",t.hf);
$("videojs.autoSetup",t.xc);
$("videojs.plugin",t.Fe);
$("videojs.createTimeRange",t.Lb);
$("videojs.util",t.$);
t.$.mergeOptions=t.$.ya;
t.addLanguage=t.Jd
})();
!function(h){var g=h.vttjs={},n=g.VTTCue,l=g.VTTRegion,k=h.VTTCue,j=h.VTTRegion;
g.shim=function(){g.VTTCue=n,g.VTTRegion=l
},g.restore=function(){g.VTTCue=k,g.VTTRegion=j
}
}(this),function(s,r){function q(e){if("string"!=typeof e){return !1
}var d=k[e.toLowerCase()];
return d?e.toLowerCase():!1
}function p(e){if("string"!=typeof e){return !1
}var d=j[e.toLowerCase()];
return d?e.toLowerCase():!1
}function o(f){for(var e=1;
e<arguments.length;
e++){var h=arguments[e];
for(var g in h){f[g]=h[g]
}}return f
}function n(O,N,M){var L=this,K=/MSIE\s8\.0/.test(navigator.userAgent),J={};
K?L=document.createElement("custom"):J.enumerable=!0,L.hasBeenReset=!1;
var I="",H=!1,G=O,F=N,E=M,D=null,C="",B=!0,A="auto",z="start",y=50,g="middle",e=50,d="middle";
return Object.defineProperty(L,"id",o({},J,{get:function(){return I
},set:function(b){I=""+b
}})),Object.defineProperty(L,"pauseOnExit",o({},J,{get:function(){return H
},set:function(b){H=!!b
}})),Object.defineProperty(L,"startTime",o({},J,{get:function(){return G
},set:function(b){if("number"!=typeof b){throw new TypeError("Start time must be set to a number.")
}G=b,this.hasBeenReset=!0
}})),Object.defineProperty(L,"endTime",o({},J,{get:function(){return F
},set:function(b){if("number"!=typeof b){throw new TypeError("End time must be set to a number.")
}F=b,this.hasBeenReset=!0
}})),Object.defineProperty(L,"text",o({},J,{get:function(){return E
},set:function(b){E=""+b,this.hasBeenReset=!0
}})),Object.defineProperty(L,"region",o({},J,{get:function(){return D
},set:function(b){D=b,this.hasBeenReset=!0
}})),Object.defineProperty(L,"vertical",o({},J,{get:function(){return C
},set:function(h){var f=q(h);
if(f===!1){throw new SyntaxError("An invalid or illegal string was specified.")
}C=f,this.hasBeenReset=!0
}})),Object.defineProperty(L,"snapToLines",o({},J,{get:function(){return B
},set:function(b){B=!!b,this.hasBeenReset=!0
}})),Object.defineProperty(L,"line",o({},J,{get:function(){return A
},set:function(b){if("number"!=typeof b&&b!==l){throw new SyntaxError("An invalid number or illegal string was specified.")
}A=b,this.hasBeenReset=!0
}})),Object.defineProperty(L,"lineAlign",o({},J,{get:function(){return z
},set:function(h){var f=p(h);
if(!f){throw new SyntaxError("An invalid or illegal string was specified.")
}z=f,this.hasBeenReset=!0
}})),Object.defineProperty(L,"position",o({},J,{get:function(){return y
},set:function(b){if(0>b||b>100){throw new Error("Position must be between 0 and 100.")
}y=b,this.hasBeenReset=!0
}})),Object.defineProperty(L,"positionAlign",o({},J,{get:function(){return g
},set:function(h){var f=p(h);
if(!f){throw new SyntaxError("An invalid or illegal string was specified.")
}g=f,this.hasBeenReset=!0
}})),Object.defineProperty(L,"size",o({},J,{get:function(){return e
},set:function(b){if(0>b||b>100){throw new Error("Size must be between 0 and 100.")
}e=b,this.hasBeenReset=!0
}})),Object.defineProperty(L,"align",o({},J,{get:function(){return d
},set:function(h){var f=p(h);
if(!f){throw new SyntaxError("An invalid or illegal string was specified.")
}d=f,this.hasBeenReset=!0
}})),L.displayState=void 0,K?L:void 0
}var l="auto",k={"":!0,lr:!0,rl:!0},j={start:!0,middle:!0,end:!0,left:!0,right:!0};
n.prototype.getCueAsHTML=function(){return WebVTT.convertCueToDOMTree(window,this.text)
},s.VTTCue=s.VTTCue||n,r.VTTCue=n
}(this,this.vttjs||{}),function(h,g){function n(e){if("string"!=typeof e){return !1
}var d=j[e.toLowerCase()];
return d?e.toLowerCase():!1
}function l(b){return"number"==typeof b&&b>=0&&100>=b
}function k(){var o=100,d=3,t=0,s=100,r=0,q=100,p="";
Object.defineProperties(this,{width:{enumerable:!0,get:function(){return o
},set:function(a){if(!l(a)){throw new Error("Width must be between 0 and 100.")
}o=a
}},lines:{enumerable:!0,get:function(){return d
},set:function(b){if("number"!=typeof b){throw new TypeError("Lines must be set to a number.")
}d=b
}},regionAnchorY:{enumerable:!0,get:function(){return s
},set:function(b){if(!l(b)){throw new Error("RegionAnchorX must be between 0 and 100.")
}s=b
}},regionAnchorX:{enumerable:!0,get:function(){return t
},set:function(b){if(!l(b)){throw new Error("RegionAnchorY must be between 0 and 100.")
}t=b
}},viewportAnchorY:{enumerable:!0,get:function(){return q
},set:function(b){if(!l(b)){throw new Error("ViewportAnchorY must be between 0 and 100.")
}q=b
}},viewportAnchorX:{enumerable:!0,get:function(){return r
},set:function(b){if(!l(b)){throw new Error("ViewportAnchorX must be between 0 and 100.")
}r=b
}},scroll:{enumerable:!0,get:function(){return p
},set:function(f){var e=n(f);
if(e===!1){throw new SyntaxError("An invalid or illegal string was specified.")
}p=e
}}})
}var j={"":!0,up:!0};
h.VTTRegion=h.VTTRegion||k,g.VTTRegion=k
}(this,this.vttjs||{}),function(T){function S(e,d){this.name="ParsingError",this.code=e.code,this.message=d||e.message
}function R(e){function d(h,g,k,j){return 3600*(0|h)+60*(0|g)+(0|k)+(0|j)/1000
}var f=e.match(/^(\d+):(\d{2})(:\d{2})?\.(\d{3})/);
return f?f[3]?d(f[1],f[2],f[3].replace(":",""),f[4]):f[1]>59?d(f[1],f[2],0,f[4]):d(0,f[1],f[2],f[4]):null
}function Q(){this.values=F(null)
}function P(s,r,q,p){var o=p?s.split(p):[s];
for(var n in o){if("string"==typeof o[n]){var l=o[n].split(q);
if(2===l.length){var k=l[0],j=l[1];
r(k,j)
}}}}function O(b,p,o){function n(){var a=R(b);
if(null===a){throw new S(S.Errors.BadTimeStamp,"Malformed timestamp: "+d)
}return b=b.replace(/^[^\sa-zA-Z-]+/,""),a
}function l(g,f){var h=new Q;
P(g,function(k,j){switch(k){case"region":for(var s=o.length-1;
s>=0;
s--){if(o[s].id===j){h.set(k,o[s].region);
break
}}break;
case"vertical":h.alt(k,j,["rl","lr"]);
break;
case"line":var r=j.split(","),q=r[0];
h.integer(k,q),h.percent(k,q)?h.set("snapToLines",!1):null,h.alt(k,q,["auto"]),2===r.length&&h.alt("lineAlign",r[1],["start","middle","end"]);
break;
case"position":r=j.split(","),h.percent(k,r[0]),2===r.length&&h.alt("positionAlign",r[1],["start","middle","end"]);
break;
case"size":h.percent(k,j);
break;
case"align":h.alt(k,j,["start","middle","end","left","right"])
}},/:/,/\s/),f.region=h.get("region",null),f.vertical=h.get("vertical",""),f.line=h.get("line","auto"),f.lineAlign=h.get("lineAlign","start"),f.snapToLines=h.get("snapToLines",!0),f.size=h.get("size",100),f.align=h.get("align","middle"),f.position=h.get("position",{start:0,left:0,middle:50,end:100,right:100},f.align),f.positionAlign=h.get("positionAlign",{start:"start",left:"start",middle:"middle",end:"end",right:"end"},f.align)
}function e(){b=b.replace(/^\s+/,"")
}var d=b;
if(e(),p.startTime=n(),e(),"-->"!==b.substr(0,3)){throw new S(S.Errors.BadTimeStamp,"Malformed time stamp (time stamps must be separated by '-->'): "+d)
}b=b.substr(3),e(),p.endTime=n(),e(),l(b,p)
}function N(Z,Y){function X(){function b(e){return Y=Y.substr(e.length),e
}if(!Y){return null
}var d=Y.match(/^([^<]*)(<[^>]+>?)?/);
return b(d[1]?d[1]:d[2])
}function W(b){return E[b]
}function V(b){for(;
p=b.match(/&(amp|lt|gt|lrm|rlm|nbsp);/);
){b=b.replace(p[0],W)
}return b
}function U(e,d){return !B[d.localName]||B[d.localName]===e.localName
}function w(a,k){var j=D[a];
if(!j){return null
}var h=Z.document.createElement(j);
h.localName=j;
var g=C[a];
return g&&k&&(h[g]=k.trim()),h
}for(var v,u=Z.document.createElement("div"),t=u,s=[];
null!==(v=X());
){if("<"!==v[0]){t.appendChild(Z.document.createTextNode(V(v)))
}else{if("/"===v[1]){s.length&&s[s.length-1]===v.substr(2).replace(">","")&&(s.pop(),t=t.parentNode);
continue
}var r,q=R(v.substr(1,v.length-2));
if(q){r=Z.document.createProcessingInstruction("timestamp",q),t.appendChild(r);
continue
}var p=v.match(/^<([^.\s/0-9>]+)(\.[^\s\\>]+)?([^>\\]+)?(\\?)>?$/);
if(!p){continue
}if(r=w(p[1],p[3]),!r){continue
}if(!U(t,r)){continue
}p[2]&&(r.className=p[2].substr(1).replace("."," ")),s.push(p[1]),t.appendChild(r),t=r
}}return u
}function M(k){function j(e,d){for(var f=d.childNodes.length-1;
f>=0;
f--){e.push(d.childNodes[f])
}}function r(b){if(!b||!b.length){return null
}var s=b.pop(),h=s.textContent||s.innerText;
if(h){var g=h.match(/^.*(\n|\r)/);
return g?(b.length=0,g[0]):h
}return"ruby"===s.tagName?r(b):s.childNodes?(j(b,s),r(b)):void 0
}var q,p=[],o="";
if(!k||!k.childNodes){return"ltr"
}for(j(p,k);
o=r(p);
){for(var n=0;
n<o.length;
n++){q=o.charCodeAt(n);
for(var l=0;
l<A.length;
l++){if(A[l]===q){return"rtl"
}}}}return"ltr"
}function L(g){if("number"==typeof g.line&&(g.snapToLines||g.line>=0&&g.line<=100)){return g.line
}if(!g.track||!g.track.textTrackList||!g.track.textTrackList.mediaElement){return -1
}for(var f=g.track,k=f.textTrackList,j=0,h=0;
h<k.length&&k[h]!==f;
h++){"showing"===k[h].mode&&j++
}return -1*++j
}function K(){}function J(h,g,q){var p=/MSIE\s8\.0/.test(navigator.userAgent),o="rgba(255, 255, 255, 1)",n="rgba(0, 0, 0, 0.8)";
p&&(o="rgb(255, 255, 255)",n="rgb(0, 0, 0)"),K.call(this),this.cue=g,this.cueDiv=N(h,g.text);
var l={color:o,backgroundColor:n,position:"relative",left:0,right:0,top:0,bottom:0,display:"inline"};
p||(l.writingMode=""===g.vertical?"horizontal-tb":"lr"===g.vertical?"vertical-lr":"vertical-rl",l.unicodeBidi="plaintext"),this.applyStyles(l,this.cueDiv),this.div=h.document.createElement("div"),l={textAlign:"middle"===g.align?"center":g.align,font:q.font,whiteSpace:"pre-line",position:"absolute"},p||(l.direction=M(this.cueDiv),l.writingMode=""===g.vertical?"horizontal-tb":"lr"===g.vertical?"vertical-lr":"vertical-rl".stylesunicodeBidi="plaintext"),this.applyStyles(l),this.div.appendChild(this.cueDiv);
var j=0;
switch(g.positionAlign){case"start":j=g.position;
break;
case"middle":j=g.position-g.size/2;
break;
case"end":j=g.position-g.size
}this.applyStyles(""===g.vertical?{left:this.formatStyle(j,"%"),width:this.formatStyle(g.size,"%")}:{top:this.formatStyle(j,"%"),height:this.formatStyle(g.size,"%")}),this.move=function(b){this.applyStyles({top:this.formatStyle(b.top,"px"),bottom:this.formatStyle(b.bottom,"px"),left:this.formatStyle(b.left,"px"),right:this.formatStyle(b.right,"px"),height:this.formatStyle(b.height,"px"),width:this.formatStyle(b.width,"px")})
}
}function I(j){var h,p,o,n,l=/MSIE\s8\.0/.test(navigator.userAgent);
if(j.div){p=j.div.offsetHeight,o=j.div.offsetWidth,n=j.div.offsetTop;
var k=(k=j.div.childNodes)&&(k=k[0])&&k.getClientRects&&k.getClientRects();
j=j.div.getBoundingClientRect(),h=k?Math.max(k[0]&&k[0].height||0,j.height/k.length):0
}this.left=j.left,this.right=j.right,this.top=j.top||n,this.height=j.height||p,this.bottom=j.bottom||n+(j.height||p),this.width=j.width||o,this.lineHeight=void 0!==h?h:j.lineHeight,l&&!this.lineHeight&&(this.lineHeight=13)
}function H(ad,ac,ab,aa){function Z(j,d){for(var q,p=new I(j),o=1,n=0;
n<d.length;
n++){for(;
j.overlapsOppositeAxis(ab,d[n])||j.within(ab)&&j.overlapsAny(aa);
){j.move(d[n])
}if(j.within(ab)){return j
}var k=j.intersectPercentage(ab);
o>k&&(q=new I(j),o=k),j=new I(p)
}return q||p
}var Y=new I(ac),X=ac.cue,W=L(X),V=[];
if(X.snapToLines){var U;
switch(X.vertical){case"":V=["+y","-y"],U="height";
break;
case"rl":V=["+x","-x"],U="width";
break;
case"lr":V=["-x","+x"],U="width"
}var w=Y.lineHeight,v=w*Math.round(W),u=ab[U]+w,t=V[0];
Math.abs(v)>u&&(v=0>v?-1:1,v*=Math.ceil(u/w)*w),0>W&&(v+=""===X.vertical?ab.height:ab.width,V=V.reverse()),Y.move(t,v)
}else{var s=Y.lineHeight/ab.height*100;
switch(X.lineAlign){case"middle":W-=s/2;
break;
case"end":W-=s
}switch(X.vertical){case"":ac.applyStyles({top:ac.formatStyle(W,"%")});
break;
case"rl":ac.applyStyles({left:ac.formatStyle(W,"%")});
break;
case"lr":ac.applyStyles({right:ac.formatStyle(W,"%")})
}V=["+y","-x","+x","-y"],Y=new I(ac)
}var l=Z(Y,V);
ac.move(l.toCSSCompatValues(ab))
}function G(){}var F=Object.create||function(){function b(){}return function(a){if(1!==arguments.length){throw new Error("Object.create shim only accepts one parameter.")
}return b.prototype=a,new b
}
}();
S.prototype=F(Error.prototype),S.prototype.constructor=S,S.Errors={BadSignature:{code:0,message:"Malformed WebVTT signature."},BadTimeStamp:{code:1,message:"Malformed time stamp."}},Q.prototype={set:function(e,d){this.get(e)||""===d||(this.values[e]=d)
},get:function(e,d,f){return f?this.has(e)?this.values[e]:d[f]:this.has(e)?this.values[e]:d
},has:function(b){return b in this.values
},alt:function(f,e,h){for(var g=0;
g<h.length;
++g){if(e===h[g]){this.set(f,e);
break
}}},integer:function(e,d){/^-?\d+$/.test(d)&&this.set(e,parseInt(d,10))
},percent:function(e,d){var f;
return(f=d.match(/^([\d]{1,3})(\.[\d]*)?%$/))&&(d=parseFloat(d),d>=0&&100>=d)?(this.set(e,d),!0):!1
}};
var E={"&amp;":"&","&lt;":"<","&gt;":">","&lrm;":"â€Ž","&rlm;":"â€","&nbsp;":"Â "},D={c:"span",i:"i",b:"b",u:"u",ruby:"ruby",rt:"rt",v:"span",lang:"span"},C={v:"title",lang:"lang"},B={rt:"ruby"},A=[1470,1472,1475,1478,1488,1489,1490,1491,1492,1493,1494,1495,1496,1497,1498,1499,1500,1501,1502,1503,1504,1505,1506,1507,1508,1509,1510,1511,1512,1513,1514,1520,1521,1522,1523,1524,1544,1547,1549,1563,1566,1567,1568,1569,1570,1571,1572,1573,1574,1575,1576,1577,1578,1579,1580,1581,1582,1583,1584,1585,1586,1587,1588,1589,1590,1591,1592,1593,1594,1595,1596,1597,1598,1599,1600,1601,1602,1603,1604,1605,1606,1607,1608,1609,1610,1645,1646,1647,1649,1650,1651,1652,1653,1654,1655,1656,1657,1658,1659,1660,1661,1662,1663,1664,1665,1666,1667,1668,1669,1670,1671,1672,1673,1674,1675,1676,1677,1678,1679,1680,1681,1682,1683,1684,1685,1686,1687,1688,1689,1690,1691,1692,1693,1694,1695,1696,1697,1698,1699,1700,1701,1702,1703,1704,1705,1706,1707,1708,1709,1710,1711,1712,1713,1714,1715,1716,1717,1718,1719,1720,1721,1722,1723,1724,1725,1726,1727,1728,1729,1730,1731,1732,1733,1734,1735,1736,1737,1738,1739,1740,1741,1742,1743,1744,1745,1746,1747,1748,1749,1765,1766,1774,1775,1786,1787,1788,1789,1790,1791,1792,1793,1794,1795,1796,1797,1798,1799,1800,1801,1802,1803,1804,1805,1807,1808,1810,1811,1812,1813,1814,1815,1816,1817,1818,1819,1820,1821,1822,1823,1824,1825,1826,1827,1828,1829,1830,1831,1832,1833,1834,1835,1836,1837,1838,1839,1869,1870,1871,1872,1873,1874,1875,1876,1877,1878,1879,1880,1881,1882,1883,1884,1885,1886,1887,1888,1889,1890,1891,1892,1893,1894,1895,1896,1897,1898,1899,1900,1901,1902,1903,1904,1905,1906,1907,1908,1909,1910,1911,1912,1913,1914,1915,1916,1917,1918,1919,1920,1921,1922,1923,1924,1925,1926,1927,1928,1929,1930,1931,1932,1933,1934,1935,1936,1937,1938,1939,1940,1941,1942,1943,1944,1945,1946,1947,1948,1949,1950,1951,1952,1953,1954,1955,1956,1957,1969,1984,1985,1986,1987,1988,1989,1990,1991,1992,1993,1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,2021,2022,2023,2024,2025,2026,2036,2037,2042,2048,2049,2050,2051,2052,2053,2054,2055,2056,2057,2058,2059,2060,2061,2062,2063,2064,2065,2066,2067,2068,2069,2074,2084,2088,2096,2097,2098,2099,2100,2101,2102,2103,2104,2105,2106,2107,2108,2109,2110,2112,2113,2114,2115,2116,2117,2118,2119,2120,2121,2122,2123,2124,2125,2126,2127,2128,2129,2130,2131,2132,2133,2134,2135,2136,2142,2208,2210,2211,2212,2213,2214,2215,2216,2217,2218,2219,2220,8207,64285,64287,64288,64289,64290,64291,64292,64293,64294,64295,64296,64298,64299,64300,64301,64302,64303,64304,64305,64306,64307,64308,64309,64310,64312,64313,64314,64315,64316,64318,64320,64321,64323,64324,64326,64327,64328,64329,64330,64331,64332,64333,64334,64335,64336,64337,64338,64339,64340,64341,64342,64343,64344,64345,64346,64347,64348,64349,64350,64351,64352,64353,64354,64355,64356,64357,64358,64359,64360,64361,64362,64363,64364,64365,64366,64367,64368,64369,64370,64371,64372,64373,64374,64375,64376,64377,64378,64379,64380,64381,64382,64383,64384,64385,64386,64387,64388,64389,64390,64391,64392,64393,64394,64395,64396,64397,64398,64399,64400,64401,64402,64403,64404,64405,64406,64407,64408,64409,64410,64411,64412,64413,64414,64415,64416,64417,64418,64419,64420,64421,64422,64423,64424,64425,64426,64427,64428,64429,64430,64431,64432,64433,64434,64435,64436,64437,64438,64439,64440,64441,64442,64443,64444,64445,64446,64447,64448,64449,64467,64468,64469,64470,64471,64472,64473,64474,64475,64476,64477,64478,64479,64480,64481,64482,64483,64484,64485,64486,64487,64488,64489,64490,64491,64492,64493,64494,64495,64496,64497,64498,64499,64500,64501,64502,64503,64504,64505,64506,64507,64508,64509,64510,64511,64512,64513,64514,64515,64516,64517,64518,64519,64520,64521,64522,64523,64524,64525,64526,64527,64528,64529,64530,64531,64532,64533,64534,64535,64536,64537,64538,64539,64540,64541,64542,64543,64544,64545,64546,64547,64548,64549,64550,64551,64552,64553,64554,64555,64556,64557,64558,64559,64560,64561,64562,64563,64564,64565,64566,64567,64568,64569,64570,64571,64572,64573,64574,64575,64576,64577,64578,64579,64580,64581,64582,64583,64584,64585,64586,64587,64588,64589,64590,64591,64592,64593,64594,64595,64596,64597,64598,64599,64600,64601,64602,64603,64604,64605,64606,64607,64608,64609,64610,64611,64612,64613,64614,64615,64616,64617,64618,64619,64620,64621,64622,64623,64624,64625,64626,64627,64628,64629,64630,64631,64632,64633,64634,64635,64636,64637,64638,64639,64640,64641,64642,64643,64644,64645,64646,64647,64648,64649,64650,64651,64652,64653,64654,64655,64656,64657,64658,64659,64660,64661,64662,64663,64664,64665,64666,64667,64668,64669,64670,64671,64672,64673,64674,64675,64676,64677,64678,64679,64680,64681,64682,64683,64684,64685,64686,64687,64688,64689,64690,64691,64692,64693,64694,64695,64696,64697,64698,64699,64700,64701,64702,64703,64704,64705,64706,64707,64708,64709,64710,64711,64712,64713,64714,64715,64716,64717,64718,64719,64720,64721,64722,64723,64724,64725,64726,64727,64728,64729,64730,64731,64732,64733,64734,64735,64736,64737,64738,64739,64740,64741,64742,64743,64744,64745,64746,64747,64748,64749,64750,64751,64752,64753,64754,64755,64756,64757,64758,64759,64760,64761,64762,64763,64764,64765,64766,64767,64768,64769,64770,64771,64772,64773,64774,64775,64776,64777,64778,64779,64780,64781,64782,64783,64784,64785,64786,64787,64788,64789,64790,64791,64792,64793,64794,64795,64796,64797,64798,64799,64800,64801,64802,64803,64804,64805,64806,64807,64808,64809,64810,64811,64812,64813,64814,64815,64816,64817,64818,64819,64820,64821,64822,64823,64824,64825,64826,64827,64828,64829,64848,64849,64850,64851,64852,64853,64854,64855,64856,64857,64858,64859,64860,64861,64862,64863,64864,64865,64866,64867,64868,64869,64870,64871,64872,64873,64874,64875,64876,64877,64878,64879,64880,64881,64882,64883,64884,64885,64886,64887,64888,64889,64890,64891,64892,64893,64894,64895,64896,64897,64898,64899,64900,64901,64902,64903,64904,64905,64906,64907,64908,64909,64910,64911,64914,64915,64916,64917,64918,64919,64920,64921,64922,64923,64924,64925,64926,64927,64928,64929,64930,64931,64932,64933,64934,64935,64936,64937,64938,64939,64940,64941,64942,64943,64944,64945,64946,64947,64948,64949,64950,64951,64952,64953,64954,64955,64956,64957,64958,64959,64960,64961,64962,64963,64964,64965,64966,64967,65008,65009,65010,65011,65012,65013,65014,65015,65016,65017,65018,65019,65020,65136,65137,65138,65139,65140,65142,65143,65144,65145,65146,65147,65148,65149,65150,65151,65152,65153,65154,65155,65156,65157,65158,65159,65160,65161,65162,65163,65164,65165,65166,65167,65168,65169,65170,65171,65172,65173,65174,65175,65176,65177,65178,65179,65180,65181,65182,65183,65184,65185,65186,65187,65188,65189,65190,65191,65192,65193,65194,65195,65196,65197,65198,65199,65200,65201,65202,65203,65204,65205,65206,65207,65208,65209,65210,65211,65212,65213,65214,65215,65216,65217,65218,65219,65220,65221,65222,65223,65224,65225,65226,65227,65228,65229,65230,65231,65232,65233,65234,65235,65236,65237,65238,65239,65240,65241,65242,65243,65244,65245,65246,65247,65248,65249,65250,65251,65252,65253,65254,65255,65256,65257,65258,65259,65260,65261,65262,65263,65264,65265,65266,65267,65268,65269,65270,65271,65272,65273,65274,65275,65276,67584,67585,67586,67587,67588,67589,67592,67594,67595,67596,67597,67598,67599,67600,67601,67602,67603,67604,67605,67606,67607,67608,67609,67610,67611,67612,67613,67614,67615,67616,67617,67618,67619,67620,67621,67622,67623,67624,67625,67626,67627,67628,67629,67630,67631,67632,67633,67634,67635,67636,67637,67639,67640,67644,67647,67648,67649,67650,67651,67652,67653,67654,67655,67656,67657,67658,67659,67660,67661,67662,67663,67664,67665,67666,67667,67668,67669,67671,67672,67673,67674,67675,67676,67677,67678,67679,67840,67841,67842,67843,67844,67845,67846,67847,67848,67849,67850,67851,67852,67853,67854,67855,67856,67857,67858,67859,67860,67861,67862,67863,67864,67865,67866,67867,67872,67873,67874,67875,67876,67877,67878,67879,67880,67881,67882,67883,67884,67885,67886,67887,67888,67889,67890,67891,67892,67893,67894,67895,67896,67897,67903,67968,67969,67970,67971,67972,67973,67974,67975,67976,67977,67978,67979,67980,67981,67982,67983,67984,67985,67986,67987,67988,67989,67990,67991,67992,67993,67994,67995,67996,67997,67998,67999,68000,68001,68002,68003,68004,68005,68006,68007,68008,68009,68010,68011,68012,68013,68014,68015,68016,68017,68018,68019,68020,68021,68022,68023,68030,68031,68096,68112,68113,68114,68115,68117,68118,68119,68121,68122,68123,68124,68125,68126,68127,68128,68129,68130,68131,68132,68133,68134,68135,68136,68137,68138,68139,68140,68141,68142,68143,68144,68145,68146,68147,68160,68161,68162,68163,68164,68165,68166,68167,68176,68177,68178,68179,68180,68181,68182,68183,68184,68192,68193,68194,68195,68196,68197,68198,68199,68200,68201,68202,68203,68204,68205,68206,68207,68208,68209,68210,68211,68212,68213,68214,68215,68216,68217,68218,68219,68220,68221,68222,68223,68352,68353,68354,68355,68356,68357,68358,68359,68360,68361,68362,68363,68364,68365,68366,68367,68368,68369,68370,68371,68372,68373,68374,68375,68376,68377,68378,68379,68380,68381,68382,68383,68384,68385,68386,68387,68388,68389,68390,68391,68392,68393,68394,68395,68396,68397,68398,68399,68400,68401,68402,68403,68404,68405,68416,68417,68418,68419,68420,68421,68422,68423,68424,68425,68426,68427,68428,68429,68430,68431,68432,68433,68434,68435,68436,68437,68440,68441,68442,68443,68444,68445,68446,68447,68448,68449,68450,68451,68452,68453,68454,68455,68456,68457,68458,68459,68460,68461,68462,68463,68464,68465,68466,68472,68473,68474,68475,68476,68477,68478,68479,68608,68609,68610,68611,68612,68613,68614,68615,68616,68617,68618,68619,68620,68621,68622,68623,68624,68625,68626,68627,68628,68629,68630,68631,68632,68633,68634,68635,68636,68637,68638,68639,68640,68641,68642,68643,68644,68645,68646,68647,68648,68649,68650,68651,68652,68653,68654,68655,68656,68657,68658,68659,68660,68661,68662,68663,68664,68665,68666,68667,68668,68669,68670,68671,68672,68673,68674,68675,68676,68677,68678,68679,68680,126464,126465,126466,126467,126469,126470,126471,126472,126473,126474,126475,126476,126477,126478,126479,126480,126481,126482,126483,126484,126485,126486,126487,126488,126489,126490,126491,126492,126493,126494,126495,126497,126498,126500,126503,126505,126506,126507,126508,126509,126510,126511,126512,126513,126514,126516,126517,126518,126519,126521,126523,126530,126535,126537,126539,126541,126542,126543,126545,126546,126548,126551,126553,126555,126557,126559,126561,126562,126564,126567,126568,126569,126570,126572,126573,126574,126575,126576,126577,126578,126580,126581,126582,126583,126585,126586,126587,126588,126590,126592,126593,126594,126595,126596,126597,126598,126599,126600,126601,126603,126604,126605,126606,126607,126608,126609,126610,126611,126612,126613,126614,126615,126616,126617,126618,126619,126625,126626,126627,126629,126630,126631,126632,126633,126635,126636,126637,126638,126639,126640,126641,126642,126643,126644,126645,126646,126647,126648,126649,126650,126651,1114109];
K.prototype.applyStyles=function(e,d){d=d||this.div;
for(var f in e){e.hasOwnProperty(f)&&(d.style[f]=e[f])
}},K.prototype.formatStyle=function(e,d){return 0===e?0:e+d
},J.prototype=F(K.prototype),J.prototype.constructor=J,I.prototype.move=function(e,d){switch(d=void 0!==d?d:this.lineHeight,e){case"+x":this.left+=d,this.right+=d;
break;
case"-x":this.left-=d,this.right-=d;
break;
case"+y":this.top+=d,this.bottom+=d;
break;
case"-y":this.top-=d,this.bottom-=d
}},I.prototype.overlaps=function(b){return this.left<b.right&&this.right>b.left&&this.top<b.bottom&&this.bottom>b.top
},I.prototype.overlapsAny=function(e){for(var d=0;
d<e.length;
d++){if(this.overlaps(e[d])){return !0
}}return !1
},I.prototype.within=function(b){return this.top>=b.top&&this.bottom<=b.bottom&&this.left>=b.left&&this.right<=b.right
},I.prototype.overlapsOppositeAxis=function(e,d){switch(d){case"+x":return this.left<e.left;
case"-x":return this.right>e.right;
case"+y":return this.top<e.top;
case"-y":return this.bottom>e.bottom
}},I.prototype.intersectPercentage=function(f){var e=Math.max(0,Math.min(this.right,f.right)-Math.max(this.left,f.left)),h=Math.max(0,Math.min(this.bottom,f.bottom)-Math.max(this.top,f.top)),g=e*h;
return g/(this.height*this.width)
},I.prototype.toCSSCompatValues=function(b){return{top:this.top-b.top,bottom:b.bottom-this.bottom,left:this.left-b.left,right:b.right-this.right,height:this.height,width:this.width}
},I.getSimpleBoxPosition=function(g){var f=g.div?g.div.offsetHeight:g.tagName?g.offsetHeight:0,k=g.div?g.div.offsetWidth:g.tagName?g.offsetWidth:0,j=g.div?g.div.offsetTop:g.tagName?g.offsetTop:0;
g=g.div?g.div.getBoundingClientRect():g.tagName?g.getBoundingClientRect():g;
var h={left:g.left,right:g.right,top:g.top||j,height:g.height||f,bottom:g.bottom||j+(g.height||f),width:g.width||k};
return h
},G.StringDecoder=function(){return{decode:function(b){if(!b){return""
}if("string"!=typeof b){throw new Error("Error - expected string data.")
}return decodeURIComponent(encodeURIComponent(b))
}}
},G.convertCueToDOMTree=function(e,d){return e&&d?N(e,d):null
};
var z=0.05,y="sans-serif",x="1.5%";
G.processCues=function(u,t,s){function r(e){for(var d=0;
d<e.length;
d++){if(e[d].hasBeenReset||!e[d].displayState){return !0
}}return !1
}if(!u||!t||!s){return null
}for(;
s.firstChild;
){s.removeChild(s.firstChild)
}var q=u.document.createElement("div");
if(q.style.position="absolute",q.style.left="0",q.style.right="0",q.style.top="0",q.style.bottom="0",q.style.margin=x,s.appendChild(q),r(t)){var p=[],o=I.getSimpleBoxPosition(q),n=Math.round(o.height*z*100)/100,l={font:n+"px "+y};
!function(){for(var e,b,a=0;
a<t.length;
a++){b=t[a],e=new J(u,b,l),q.appendChild(e.div),H(u,e,o,p),b.displayState=e.div,p.push(I.getSimpleBoxPosition(e))
}}()
}else{for(var k=0;
k<t.length;
k++){q.appendChild(t[k].displayState)
}}},G.Parser=function(e,d,f){f||(f=d,d={}),d||(d={}),this.window=e,this.vttjs=d,this.state="INITIAL",this.buffer="",this.decoder=f||new TextDecoder("utf8"),this.regionList=[]
},G.Parser.prototype={reportOrThrowError:function(b){if(!(b instanceof S)){throw b
}this.onparsingerror&&this.onparsingerror(b)
},parse:function(t){function s(){for(var h=p.buffer,g=0;
g<h.length&&"\r"!==h[g]&&"\n"!==h[g];
){++g
}var j=h.substr(0,g);
return"\r"===h[g]&&++g,"\n"===h[g]&&++g,p.buffer=h.substr(g),j
}function r(h){var g=new Q;
if(P(h,function(k,u){switch(k){case"id":g.set(k,u);
break;
case"width":g.percent(k,u);
break;
case"lines":g.integer(k,u);
break;
case"regionanchor":case"viewportanchor":var n=u.split(",");
if(2!==n.length){break
}var l=new Q;
if(l.percent("x",n[0]),l.percent("y",n[1]),!l.has("x")||!l.has("y")){break
}g.set(k+"X",l.get("x")),g.set(k+"Y",l.get("y"));
break;
case"scroll":g.alt(k,u,["up"])
}},/=/,/\s/),g.has("id")){var j=new (p.vttjs.VTTRegion||p.window.VTTRegion);
j.width=g.get("width",100),j.lines=g.get("lines",3),j.regionAnchorX=g.get("regionanchorX",0),j.regionAnchorY=g.get("regionanchorY",100),j.viewportAnchorX=g.get("viewportanchorX",0),j.viewportAnchorY=g.get("viewportanchorY",100),j.scroll=g.get("scroll",""),p.onregion&&p.onregion(j),p.regionList.push({id:g.get("id"),region:j})
}}function q(g){P(g,function(j,h){switch(j){case"Region":r(h)
}},/:/)
}var p=this;
t&&(p.buffer+=p.decoder.decode(t,{stream:!0}));
try{var o;
if("INITIAL"===p.state){if(!/\r\n|\n/.test(p.buffer)){return this
}o=s();
var f=o.match(/^WEBVTT([ \t].*)?$/);
if(!f||!f[0]){throw new S(S.Errors.BadSignature)
}p.state="HEADER"
}for(var e=!1;
p.buffer;
){if(!/\r\n|\n/.test(p.buffer)){return this
}switch(e?e=!1:o=s(),p.state){case"HEADER":/:/.test(o)?q(o):o||(p.state="ID");
continue;
case"NOTE":o||(p.state="ID");
continue;
case"ID":if(/^NOTE($|[ \t])/.test(o)){p.state="NOTE";
break
}if(!o){continue
}if(p.cue=new (p.vttjs.VTTCue||p.window.VTTCue)(0,0,""),p.state="CUE",-1===o.indexOf("-->")){p.cue.id=o;
continue
}case"CUE":try{O(o,p.cue,p.regionList)
}catch(d){p.reportOrThrowError(d),p.cue=null,p.state="BADCUE";
continue
}p.state="CUETEXT";
continue;
case"CUETEXT":var b=-1!==o.indexOf("-->");
if(!o||b&&(e=!0)){p.oncue&&p.oncue(p.cue),p.cue=null,p.state="ID";
continue
}p.cue.text&&(p.cue.text+="\n"),p.cue.text+=o;
continue;
case"BADCUE":o||(p.state="ID");
continue
}}}catch(d){p.reportOrThrowError(d),"CUETEXT"===p.state&&p.cue&&p.oncue&&p.oncue(p.cue),p.cue=null,p.state="INITIAL"===p.state?"BADWEBVTT":"BADCUE"
}return this
},flush:function(){var b=this;
try{if(b.buffer+=b.decoder.decode(),(b.cue||"HEADER"===b.state)&&(b.buffer+="\n\n",b.parse()),"INITIAL"===b.state){throw new S(S.Errors.BadSignature)
}}catch(d){b.reportOrThrowError(d)
}return b.onflush&&b.onflush(),this
}},T.WebVTT=G
}(this,this.vttjs||{});
var swfobject=function(){var aq="undefined",aD="object",ab="Shockwave Flash",X="ShockwaveFlash.ShockwaveFlash",aE="application/x-shockwave-flash",ac="SWFObjectExprInst",ax="onreadystatechange",af=window,aL=document,aB=navigator,aa=false,Z=[aN],aG=[],ag=[],al=[],aJ,ad,ap,at,ak=false,aU=false,aH,an,aI=true,ah=function(){var a=typeof aL.getElementById!=aq&&typeof aL.getElementsByTagName!=aq&&typeof aL.createElement!=aq,f=aB.userAgent.toLowerCase(),d=aB.platform.toLowerCase(),j=d?/win/.test(d):/win/.test(f),l=d?/mac/.test(d):/mac/.test(f),h=/webkit/.test(f)?parseFloat(f.replace(/^.*webkit\/(\d+(\.\d+)?).*$/,"$1")):false,e=!+"\v1",g=[0,0,0],n=null;
if(typeof aB.plugins!=aq&&typeof aB.plugins[ab]==aD){n=aB.plugins[ab].description;
if(n&&!(typeof aB.mimeTypes!=aq&&aB.mimeTypes[aE]&&!aB.mimeTypes[aE].enabledPlugin)){aa=true;
e=false;
n=n.replace(/^.*\s+(\S+\s+\S+$)/,"$1");
g[0]=parseInt(n.replace(/^(.*)\..*$/,"$1"),10);
g[1]=parseInt(n.replace(/^.*\.(.*)\s.*$/,"$1"),10);
g[2]=/[a-zA-Z]/.test(n)?parseInt(n.replace(/^.*[a-zA-Z]+(.*)$/,"$1"),10):0
}}else{if(typeof af.ActiveXObject!=aq){try{var k=new ActiveXObject(X);
if(k){n=k.GetVariable("$version");
if(n){e=true;
n=n.split(" ")[1].split(",");
g=[parseInt(n[0],10),parseInt(n[1],10),parseInt(n[2],10)]
}}}catch(b){}}}return{w3:a,pv:g,wk:h,ie:e,win:j,mac:l}
}(),aK=function(){if(!ah.w3){return
}if((typeof aL.readyState!=aq&&aL.readyState=="complete")||(typeof aL.readyState==aq&&(aL.getElementsByTagName("body")[0]||aL.body))){aP()
}if(!ak){if(typeof aL.addEventListener!=aq){aL.addEventListener("DOMContentLoaded",aP,false)
}if(ah.ie&&ah.win){aL.attachEvent(ax,function(){if(aL.readyState=="complete"){aL.detachEvent(ax,arguments.callee);
aP()
}});
if(af==top){(function(){if(ak){return
}try{aL.documentElement.doScroll("left")
}catch(a){setTimeout(arguments.callee,0);
return
}aP()
})()
}}if(ah.wk){(function(){if(ak){return
}if(!/loaded|complete/.test(aL.readyState)){setTimeout(arguments.callee,0);
return
}aP()
})()
}aC(aP)
}}();
function aP(){if(ak){return
}try{var b=aL.getElementsByTagName("body")[0].appendChild(ar("span"));
b.parentNode.removeChild(b)
}catch(a){return
}ak=true;
var e=Z.length;
for(var d=0;
d<e;
d++){Z[d]()
}}function aj(a){if(ak){a()
}else{Z[Z.length]=a
}}function aC(a){if(typeof af.addEventListener!=aq){af.addEventListener("load",a,false)
}else{if(typeof aL.addEventListener!=aq){aL.addEventListener("load",a,false)
}else{if(typeof af.attachEvent!=aq){aM(af,"onload",a)
}else{if(typeof af.onload=="function"){var b=af.onload;
af.onload=function(){b();
a()
}
}else{af.onload=a
}}}}}function aN(){if(aa){Y()
}else{am()
}}function Y(){var e=aL.getElementsByTagName("body")[0];
var b=ar(aD);
b.setAttribute("type",aE);
var a=e.appendChild(b);
if(a){var d=0;
(function(){if(typeof a.GetVariable!=aq){var f=a.GetVariable("$version");
if(f){f=f.split(" ")[1].split(",");
ah.pv=[parseInt(f[0],10),parseInt(f[1],10),parseInt(f[2],10)]
}}else{if(d<10){d++;
setTimeout(arguments.callee,10);
return
}}e.removeChild(b);
a=null;
am()
})()
}else{am()
}}function am(){var h=aG.length;
if(h>0){for(var j=0;
j<h;
j++){var d=aG[j].id;
var o=aG[j].callbackFn;
var a={success:false,id:d};
if(ah.pv[0]>0){var k=aS(d);
if(k){if(ao(aG[j].swfVersion)&&!(ah.wk&&ah.wk<312)){ay(d,true);
if(o){a.success=true;
a.ref=av(d);
o(a)
}}else{if(aG[j].expressInstall&&au()){var f={};
f.data=aG[j].expressInstall;
f.width=k.getAttribute("width")||"0";
f.height=k.getAttribute("height")||"0";
if(k.getAttribute("class")){f.styleclass=k.getAttribute("class")
}if(k.getAttribute("align")){f.align=k.getAttribute("align")
}var g={};
var e=k.getElementsByTagName("param");
var n=e.length;
for(var l=0;
l<n;
l++){if(e[l].getAttribute("name").toLowerCase()!="movie"){g[e[l].getAttribute("name")]=e[l].getAttribute("value")
}}ae(f,g,d,o)
}else{aF(k);
if(o){o(a)
}}}}}else{ay(d,true);
if(o){var b=av(d);
if(b&&typeof b.SetVariable!=aq){a.success=true;
a.ref=b
}o(a)
}}}}}function av(b){var e=null;
var d=aS(b);
if(d&&d.nodeName=="OBJECT"){if(typeof d.SetVariable!=aq){e=d
}else{var a=d.getElementsByTagName(aD)[0];
if(a){e=a
}}}return e
}function au(){return !aU&&ao("6.0.65")&&(ah.win||ah.mac)&&!(ah.wk&&ah.wk<312)
}function ae(g,e,j,f){aU=true;
ap=f||null;
at={success:false,id:j};
var a=aS(j);
if(a){if(a.nodeName=="OBJECT"){aJ=aO(a);
ad=null
}else{aJ=a;
ad=j
}g.id=ac;
if(typeof g.width==aq||(!/%$/.test(g.width)&&parseInt(g.width,10)<310)){g.width="310"
}if(typeof g.height==aq||(!/%$/.test(g.height)&&parseInt(g.height,10)<137)){g.height="137"
}aL.title=aL.title.slice(0,47)+" - Flash Player Installation";
var b=ah.ie&&ah.win?"ActiveX":"PlugIn",d="MMredirectURL="+af.location.toString().replace(/&/g,"%26")+"&MMplayerType="+b+"&MMdoctitle="+aL.title;
if(typeof e.flashvars!=aq){e.flashvars+="&"+d
}else{e.flashvars=d
}if(ah.ie&&ah.win&&a.readyState!=4){var h=ar("div");
j+="SWFObjectNew";
h.setAttribute("id",j);
a.parentNode.insertBefore(h,a);
a.style.display="none";
(function(){if(a.readyState==4){a.parentNode.removeChild(a)
}else{setTimeout(arguments.callee,10)
}})()
}aA(g,e,j)
}}function aF(a){if(ah.ie&&ah.win&&a.readyState!=4){var b=ar("div");
a.parentNode.insertBefore(b,a);
b.parentNode.replaceChild(aO(a),b);
a.style.display="none";
(function(){if(a.readyState==4){a.parentNode.removeChild(a)
}else{setTimeout(arguments.callee,10)
}})()
}else{a.parentNode.replaceChild(aO(a),a)
}}function aO(b){var e=ar("div");
if(ah.win&&ah.ie){e.innerHTML=b.innerHTML
}else{var f=b.getElementsByTagName(aD)[0];
if(f){var a=f.childNodes;
if(a){var g=a.length;
for(var d=0;
d<g;
d++){if(!(a[d].nodeType==1&&a[d].nodeName=="PARAM")&&!(a[d].nodeType==8)){e.appendChild(a[d].cloneNode(true))
}}}}}return e
}function aA(f,h,d){var e,a=aS(d);
if(ah.wk&&ah.wk<312){return e
}if(a){if(typeof f.id==aq){f.id=d
}if(ah.ie&&ah.win){var g="";
for(var k in f){if(f[k]!=Object.prototype[k]){if(k.toLowerCase()=="data"){h.movie=f[k]
}else{if(k.toLowerCase()=="styleclass"){g+=' class="'+f[k]+'"'
}else{if(k.toLowerCase()!="classid"){g+=" "+k+'="'+f[k]+'"'
}}}}}var j="";
for(var l in h){if(h[l]!=Object.prototype[l]){j+='<param name="'+l+'" value="'+h[l]+'" />'
}}a.outerHTML='<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"'+g+">"+j+"</object>";
ag[ag.length]=f.id;
e=aS(f.id)
}else{var b=ar(aD);
b.setAttribute("type",aE);
for(var n in f){if(f[n]!=Object.prototype[n]){if(n.toLowerCase()=="styleclass"){b.setAttribute("class",f[n])
}else{if(n.toLowerCase()!="classid"){b.setAttribute(n,f[n])
}}}}for(var o in h){if(h[o]!=Object.prototype[o]&&o.toLowerCase()!="movie"){aQ(b,o,h[o])
}}a.parentNode.replaceChild(b,a);
e=b
}}return e
}function aQ(b,e,d){var a=ar("param");
a.setAttribute("name",e);
a.setAttribute("value",d);
b.appendChild(a)
}function aw(a){var b=aS(a);
if(b&&b.nodeName=="OBJECT"){if(ah.ie&&ah.win){b.style.display="none";
(function(){if(b.readyState==4){aT(a)
}else{setTimeout(arguments.callee,10)
}})()
}else{b.parentNode.removeChild(b)
}}}function aT(a){var b=aS(a);
if(b){for(var d in b){if(typeof b[d]=="function"){b[d]=null
}}b.parentNode.removeChild(b)
}}function aS(a){var d=null;
try{d=aL.getElementById(a)
}catch(b){}return d
}function ar(a){return aL.createElement(a)
}function aM(a,d,b){a.attachEvent(d,b);
al[al.length]=[a,d,b]
}function ao(a){var b=ah.pv,d=a.split(".");
d[0]=parseInt(d[0],10);
d[1]=parseInt(d[1],10)||0;
d[2]=parseInt(d[2],10)||0;
return(b[0]>d[0]||(b[0]==d[0]&&b[1]>d[1])||(b[0]==d[0]&&b[1]==d[1]&&b[2]>=d[2]))?true:false
}function az(b,g,a,d){if(ah.ie&&ah.mac){return
}var f=aL.getElementsByTagName("head")[0];
if(!f){return
}var h=(a&&typeof a=="string")?a:"screen";
if(d){aH=null;
an=null
}if(!aH||an!=h){var e=ar("style");
e.setAttribute("type","text/css");
e.setAttribute("media",h);
aH=f.appendChild(e);
if(ah.ie&&ah.win&&typeof aL.styleSheets!=aq&&aL.styleSheets.length>0){aH=aL.styleSheets[aL.styleSheets.length-1]
}an=h
}if(ah.ie&&ah.win){if(aH&&typeof aH.addRule==aD){aH.addRule(b,g)
}}else{if(aH&&typeof aL.createTextNode!=aq){aH.appendChild(aL.createTextNode(b+" {"+g+"}"))
}}}function ay(a,d){if(!aI){return
}var b=d?"visible":"hidden";
if(ak&&aS(a)){aS(a).style.visibility=b
}else{az("#"+a,"visibility:"+b)
}}function ai(b){var a=/[\\\"<>\.;]/;
var d=a.exec(b)!=null;
return d&&typeof encodeURIComponent!=aq?encodeURIComponent(b):b
}var aR=function(){if(ah.ie&&ah.win){window.attachEvent("onunload",function(){var a=al.length;
for(var b=0;
b<a;
b++){al[b][0].detachEvent(al[b][1],al[b][2])
}var e=ag.length;
for(var d=0;
d<e;
d++){aw(ag[d])
}for(var f in ah){ah[f]=null
}ah=null;
for(var g in swfobject){swfobject[g]=null
}swfobject=null
})
}}();
return{registerObject:function(a,f,d,b){if(ah.w3&&a&&f){var e={};
e.id=a;
e.swfVersion=f;
e.expressInstall=d;
e.callbackFn=b;
aG[aG.length]=e;
ay(a,false)
}else{if(b){b({success:false,id:a})
}}},getObjectById:function(a){if(ah.w3){return av(a)
}},embedSWF:function(n,f,j,g,d,a,b,k,h,l){var e={success:false,id:f};
if(ah.w3&&!(ah.wk&&ah.wk<312)&&n&&f&&j&&g&&d){ay(f,false);
aj(function(){j+="";
g+="";
var t={};
if(h&&typeof h===aD){for(var r in h){t[r]=h[r]
}}t.data=n;
t.width=j;
t.height=g;
var q={};
if(k&&typeof k===aD){for(var s in k){q[s]=k[s]
}}if(b&&typeof b===aD){for(var o in b){if(typeof q.flashvars!=aq){q.flashvars+="&"+o+"="+b[o]
}else{q.flashvars=o+"="+b[o]
}}}if(ao(d)){var p=aA(t,q,f);
if(t.id==f){ay(f,true)
}e.success=true;
e.ref=p
}else{if(a&&au()){t.data=a;
ae(t,q,f,l);
return
}else{ay(f,true)
}}if(l){l(e)
}})
}else{if(l){l(e)
}}},switchOffAutoHideShow:function(){aI=false
},ua:ah,getFlashPlayerVersion:function(){return{major:ah.pv[0],minor:ah.pv[1],release:ah.pv[2]}
},hasFlashPlayerVersion:ao,createSWF:function(a,b,d){if(ah.w3){return aA(a,b,d)
}else{return undefined
}},showExpressInstall:function(b,a,e,d){if(ah.w3&&au()){ae(b,a,e,d)
}},removeSWF:function(a){if(ah.w3){aw(a)
}},createCSS:function(b,a,d,e){if(ah.w3){az(b,a,d,e)
}},addDomLoadEvent:aj,addLoadEvent:aC,getQueryParamValue:function(b){var a=aL.location.search||aL.location.hash;
if(a){if(/\?/.test(a)){a=a.split("?")[1]
}if(b==null){return ai(a)
}var d=a.split("&");
for(var e=0;
e<d.length;
e++){if(d[e].substring(0,d[e].indexOf("="))==b){return ai(d[e].substring((d[e].indexOf("=")+1)))
}}}return""
},expressInstallCallback:function(){if(aU){var a=aS(ac);
if(a&&aJ){a.parentNode.replaceChild(aJ,a);
if(ad){ay(ad,true);
if(ah.ie&&ah.win){aJ.style.display="block"
}}if(ap){ap(at)
}}aU=false
}}}
}();
var useSalesforceFeedback=true;
$(document).ready(function(){var b="en, jp, fr, de, it, se, es, nl , dk, br, no, fi";
if(b.indexOf(omtrLocale)>-1){$("#helpful-pod").fadeIn();
$("#helpful-pod").animate({opacity:0.8},1500)
}if($("#feedbackPod").length!=0){var a=$("#feedbackPod").offset().top-parseFloat($("#feedbackPod").css("margin-top").replace(/auto/,12));
$(function(){if(!/android|iphone|ipod/i.test(navigator.userAgent)){var e=$.browser=="msie"&&$.browser.version<7;
if(!e){var f=$("#feedbackPod").offset.left;
$(window).scroll(function(g){var h=$(this).scrollTop();
if(h>=(a-8)){$("#feedbackPod").addClass("feedbackPodFixed")
}else{$("#feedbackPod").removeClass("feedbackPodFixed")
}})
}}})
}try{loadSalesforceFeedback(useSalesforceFeedback)
}catch(d){}});
function showForm(){if(ua.indexOf("msie 6")==-1){$("#helpfulspan").hide();
$("#radioyes").hide();
$("#radiono").hide();
$("#yesspan").hide();
$("#nospan").hide();
$("#helpful").animate({width:"420px",height:"185px"});
$("#helpful").removeClass("collapsed");
$("#helpful").addClass("expanded");
$("#helpful-pod").css("opacity","1");
$("#fold").css("background-image","url(/etc/designs/help/images/fold-gray.png)");
displayTextField()
}else{submitForm()
}}function send_SfdcFeedback(d){try{var b=document.getElementsByTagName("title")[0].innerHTML
}catch(j){var b=""
}var g=$('meta[name="articleGroup"]').attr("content");
var k=window.location.href;
if(d){var l=$("#feedbacktext").val()
}else{var l=""
}var h="";
var f=$("meta[name='Content-Locale']").attr("content");
if($("#radiono").prop("checked")){h="no"
}else{if($("#radioyes").prop("checked")){h="yes"
}}var a={title:b,url:k,articleFamily:g,feedback:l,vote:h,language:f};
$.ajax({type:"POST",url:"/services/salesforce",cache:false,data:a,success:function(e){},error:function(e){}})
}function loadSalesforceFeedback(a){if(typeof a!=="undefined"&&a==true){document.getElementById("submitButton").addEventListener("click",function(){send_SfdcFeedback(true)
});
document.getElementById("noCommentButton").addEventListener("click",function(){send_SfdcFeedback(false)
})
}}adobe.fn.buildTreeList=function(b){if(b.length<1){return
}var a=$(b);
if(a.length<1){return
}a.treeList()
};
(function(){$.widget("jv.treeList",{options:{selectable:true},_create:function(){var a=this,b=$(this.element);
a._initItem(b.find("dl"));
var d=b.find("dt.ui-treeList-open");
a.openNode(d);
b.find("a.treeList").bind("click keypress",function(f){if(f.type=="keypress"&&f.which!="13"){return
}var e=b.find("dt").length,g=b.find("dt.ui-state-default").length;
if(g<e){f.preventDefault();
a.closeNode(b.find("dt"))
}else{f.preventDefault();
a.openNode(b.find("dt"))
}});
b.find("dt a.ui-treeList-toggle").bind("click keypress",function(f){if(f.type=="keypress"&&f.which!="13"){return
}var e=$(f.target).parents("dt");
if(e.hasClass("ui-state-default")){f.preventDefault();
a.openNode(e)
}else{f.preventDefault();
a.closeNode(e)
}})
},destroy:function(){$(this.element+"a.treeList").unbind("click");
$(this.element).find("dl").removeClass("ui-treeList ui-widget ui-widget-content").find("dt").unbind("mouseenter mouseleave").removeClass("ui-treeList-item ui-widget-content ui-state-default ui-state-hover").remove().unbind("click");
$.Widget.prototype.destroy.call(this)
},_initItem:function(a){a.addClass("ui-treeList ui-widget ui-widget-content").find("dt").addClass("ui-treeList-item ui-widget-content ui-state-default").hover(function(){$(this).addClass("ui-state-hover");
return false
},function(){$(this).removeClass("ui-state-hover");
return false
}).wrapInner('<div class="TreeListFloat" />').prepend('<div class="TreeListArrow"><span class="ui-widget ui-widget-content ui-icon ui-icon-triangle-1-e"></span></div>').wrapInner('<div class="LayoutBreakAfter TreeListPad" />').end().find("dd").addClass("TreeListPad").hide().end().find("dt a").addClass("ui-treeList-toggle")
},openNode:function(a){if(a){a.removeClass("ui-state-default").next("dd").show().end().find(".ui-icon-triangle-1-e").removeClass("ui-icon-triangle-1-e").addClass("ui-icon-triangle-1-s");
a.find(".TreeListPreview").hide()
}},closeNode:function(a){if(a){a.addClass("ui-state-default").next("dd").hide().end().find(".ui-icon-triangle-1-s").removeClass("ui-icon-triangle-1-s").addClass("ui-icon-triangle-1-e");
a.find(".TreeListPreview").show()
}}})
})(jQuery);
$(document).ready(function(){$(".accordion-item-title").each(function(){$(this).prepend('<span class="accordion-icon"></span>')
});
$(".accordion-item").click(function(){if(typeof(CQ)==="undefined"){$(this).siblings().children(".accordion-item-content").slideUp();
$(this).siblings().children(".accordion-item-title").children(".accordion-icon").removeClass("opened");
var a=$(this).children(".accordion-item-content");
if($(a).is(":visible")){$(a).slideUp();
$(this).children(".accordion-item-title").children(".accordion-icon").removeClass("opened")
}else{$(a).slideDown();
$(this).children(".accordion-item-title").children(".accordion-icon").addClass("opened")
}}})
});